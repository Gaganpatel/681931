(function(){
	'use strict';
	
	angular.module('tcsAppAngular',[]);	
	
})();