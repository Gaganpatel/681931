(function(){
	'use strict' ;
	
	angular
	.module('MakeMyTrip')
	.controller("homeCtrl",homeCtrl);
	
	homeCtrl.$inject=['$scope','$http','$rootScope','userService'];
	function homeCtrl($scope,$http,$rootScope,userService){
		 toastr.info('Success messages');
			$scope.details=["Bangalore","Mumbai","Chennai","Delhi"];			
		    $scope.variab = true;
			
			$scope.update = function() {
			var i=0;
			console.log($scope.from1 );	
			$scope.toAdresses=["Bangalore","Mumbai","Chennai","Delhi"];	
			$scope.variab = false;
			
			for( i= $scope.toAdresses.length - 1; i >= 0; i--)
				{
					if( $scope.toAdresses[i] == $scope.from1)
						$scope.toAdresses.splice(i,1);
				}			  
			   console.log($scope.toAdresses);
			}
			
		$scope.display=display;

		
		function display(){
				
			$rootScope.from = $scope.from1;
			$rootScope.to = $scope.to;			
			
			var date = $scope.travelDate.toString();
			var travelD = date.substr(4, 11);					
		
			$rootScope.traveldate =	travelD;
			$scope.hideSearchPage = false;
			
			console.log($rootScope.from);
			console.log($rootScope.to);
			console.log($rootScope.traveldate);
			
			window.location="/#/result";		
	    }
	}
	
})();