(function(){
	'use strict';
	angular
	.module('MakeMyTrip',['ui.router'])
	.config(router);
	
	 router.$inject = ['$stateProvider', '$urlRouterProvider'];
	 function router($stateProvider, $urlRouterProvider){
		 
		 $urlRouterProvider.otherwise('/home');
		 
		 $stateProvider
		 .state('home',{
			   url: '/home',
			   controller:'homeCtrl',
			 templateUrl:'./views/home.html'
			  
			
		 })
		 .state('result',{
			   url: '/result',
			   controller:'resultCtrl' ,
			 templateUrl:'./views/result.html' 
			 
		 })
		 
		
		.state('load',{
			    url: '/load',
			    controller:'loadCtrl' ,
			  templateUrl:'./views/load.html' 			 
		  });		 	
		 
	}		 
	
})();