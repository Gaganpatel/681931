(function(){
	'use strict' ;
	
	angular
	.module('MakeMyTrip')
	.controller("resultCtrl",resultCtrl);
	
	resultCtrl.$inject=['$scope','$http', '$filter','$rootScope', 'userService'];
	function resultCtrl($scope, $http, $filter, $rootScope, userService){
		
		var orderBy = $filter('orderBy');
		
		$(".nav a").on("click", function(){
		   $(".nav").find(".active").removeClass("active");
		   $(this).parent().addClass("active");
		});
		
		$scope.noFlights= false;
		console.log($rootScope.from);
		console.log($rootScope.to);
		console.log($rootScope.traveldate);	
		$scope.travDate= $rootScope.traveldate;
		
		$scope.modifyClick = function(){
			window.location="/#/home";
		}		
				
		$http({
				 method: "GET",
				 url: '/getDetails', 			 
				 params: { from: $rootScope.from, to:$rootScope.to }
			  })
			.success(function(data){	
			
			console.log(JSON.stringify(data));
			$scope.flightCount= data.length;
			if(data.length < 1 || data == undefined)				
			{
				$scope.noFlights=true;
			}
			else {
				for (var i in data) {
					if(data[i].Airline == 1)
					   data[i].Airline = "img/logo/Air.jpg";
					else if(data[i].Airline == 2)
					   data[i].Airline = "img/logo/Spice.jpg"
					else if(data[i].Airline == 3)
					   data[i].Airline = "img/logo/Indigo.jpg"
					else
					   data[i].Airline = "img/logo/Jet.png"
				 }
							
					$scope.flightDetails = data;
					
					console.log('flight details');
					console.log($scope.flightDetails);	
				}			
		    })
			.error(function(err){
				 console.log(err);
			});
			
		$scope.order = function(predicate) {
        $scope.predicate = predicate;
        $scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        $scope.flightDetails = orderBy($scope.flightDetails, predicate, $scope.reverse);
		};

		$scope.showDetails= function(flightDetail){
			console.log(flightDetail);
			bootbox.dialog({
				  message: '<div class="row">  ' +
                    '<div class="col-md-12"> ' +  

					'<img style="width:20% ; margin-left:35%;" src="'+ flightDetail.Airline +'"> </img> <br/> <br/> ' +                                        
					
                    '<label class="control-label" style="margin-left:20px;">Departure: </label> ' +                    
                    '<span class="control-label" style="margin-left:20px;"> ' + flightDetail.From + ' </span> ' +                    
                    '<hr/>' +
					
					'<label class="control-label" style="margin-left:20px;">Arrival: </label> ' +                    
                    '<span class="control-label" style="margin-left:20px;"> ' + flightDetail.To + ' </span> ' +                   
                    '<hr/>' +
					
					
					'<label class="control-label" style="margin-left:20px;">Departure time: </label> ' +                    
                    '<span class="control-label" style="margin-left:20px;"> ' + flightDetail.Departure + ' </span> ' +                    
                    '<hr/>' +
					
					'<label class="control-label" style="margin-left:20px;">Arrival time: </label> ' +                    
                    '<span class="control-label" style="margin-left:20px;"> ' + flightDetail.Arrival + ' </span> ' +                  
                    '<hr/>' +
					
					'<label class="control-label" style="margin-left:20px;">Price: </label> ' +                    
                    '<span class="control-label" style="margin-left:20px;"> ' + flightDetail.Price + ' </span> ' +                    
                   		
                    '</div> </div>',
				  title: "Flight Details",
				  buttons: {
					success: {
					  label: "< Back",
					  className: "btn-primary",
					  callback: function() {
						
					  }
					},
					danger: {
					  label: "Continue Booking >",
					  className: "btn-success",					  
					  callback: function() {
						
					  }
					}
				  }
			});
		}
	
 }
	
	
})();