(function(){
	'use strict' ;
	
	angular
	.module('MakeMyTrip')
	.controller("loadCtrl",loadCtrl);
	
	loadCtrl.$inject=['$scope','$http'];
	function loadCtrl($scope,$http){
		
		$(".nav a").on("click", function(){
		   $(".nav").find(".active").removeClass("active");
		   $(this).parent().addClass("active");
		});	
		
		
		$scope.submitted=false;
		
		$scope.load=load;
		$scope.addZero=addZero;
		$scope.details=["Bangalore","Mumbai","Chennai","Delhi"];
		$scope.AirLines=["Air India","Spice Jet","Indigo","Jet Airways"];
		var date1=new Date();
			$scope.travelDate=date1.getFullYear() + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
			$scope.endDate=(date1.getFullYear()+1) + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
			
		$scope.variab = true;
		
		$scope.update = function() {
			var i=0;
			console.log($scope.from1 );	
			$scope.toAdresses=["Bangalore","Mumbai","Chennai","Delhi"];	
			$scope.variab = false;
			
			for( i= $scope.toAdresses.length - 1; i >= 0; i--)
				{
					if( $scope.toAdresses[i] == $scope.from1)
						$scope.toAdresses.splice(i,1);
				}			  
			   console.log($scope.toAdresses);
		   }
		
		function load(){
		
					var data={};
					data['from1']=$scope.from1;
				    data['to']=$scope.to;
				
					var d=$scope.date.toString();
				
					data['date']=d.substr(4, 11);					
					var time=new Date($scope.arrival);
					var h=$scope.addZero(time.getHours());
					var m=$scope.addZero(time.getMinutes());
				    var t= h + ":" + m;
					data['arrival']=t;
					
					var time1=new Date($scope.departure);
					var h1=$scope.addZero(time1.getHours());
					var m1=$scope.addZero(time1.getMinutes());
				    var t1= h1 + ":" + m1;
					
					data['departure']=t1;
					var time2=new Date($scope.duration);
					var h2=$scope.addZero(time2.getHours());
					var m2=$scope.addZero(time2.getMinutes());
				    var t2= h2 + ":" + m2;
					
					data['duration']=t2;
					data['airline']=$scope.airline;
					data['price']=$scope.price;
					console.log(JSON.stringify(data));					
					
					$scope.submitted=true;		
					
					$http({
						method:'POST',
						url:'/Detail',
						data:JSON.stringify(data)
					}).
					success(function (response){				
						console.log(data);											
						
					});	
				  
                   $scope.from1="";
				   $scope.to="";
				   $scope.arrival="";
				   $scope.departure="";
				   $scope.duration="";
				   $scope.airline="";
				   $scope.price="";	
				   $scope.date= "";			   
				   toastr.success('Flight Details loaded successfully!');					
			}
			
	 function addZero(i){
		 if(i < 10){
			 i="0" + i;
			 }
		 return i;		 
	 }
	 
	}
	
})();