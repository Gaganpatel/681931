(function(){
	'use strict' ;
	
	angular
	.module('MakeMyTrip')
	.controller("loginCtrl",loginCtrl);
	
	loginCtrl.$inject=['$scope','$http','$rootScope','$location','$filter'];
	function loginCtrl($scope, $http, $rootScope,$location,$filter){
		
		$('#linkHome').removeClass("active");
		$('#linkLoad').addClass("active");
		$scope.noAdminRights = false;
		
		$scope.loginSubmit= function(){			
			
			var emailLowerCase= $filter('lowercase')($scope.emailId);
			console.log(emailLowerCase);		
			
				$http({
				 method: "GET",
				 url: '/getLoginDetails', 			 
				 params: { emailId: emailLowerCase, pass:$scope.pass }
			     })
				.success(function(data){
					console.log('success');
					console.log(data.length);
				
				if ( data.length > 0)
				{
					toastr.success('Succesfully signed in');	
					$rootScope.count = 1;
					console.log($rootScope.count);
					$location.path( "/load" );
				}
				else{
					$scope.noAdminRights = true ;
					toastr.warning('Please check your login details!');	
				 }				
				})
				.error(function(err){
					console.log('error');
					 console.log(err);
					 toastr.warning('Some problem !');	
				});			
			 
		}
	}
})();