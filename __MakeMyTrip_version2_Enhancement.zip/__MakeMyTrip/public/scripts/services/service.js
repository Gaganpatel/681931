(function(){
	'use strict';
	
	angular.module('MakeMyTrip')
	.factory('userService', userService);	
	
	function userService(){
		var userData;
		var serviceMethods = {
			setUserData : setUserData,
			getUserData : getUserData
		};
		
		return serviceMethods;
		
		function setUserData(user){			
		userData = user;		
	   }
	
		function getUserData(){
			return userData;
		}
    }	
	
})();