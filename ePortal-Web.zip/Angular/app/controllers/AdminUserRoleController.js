﻿dashboardApp.controller('AdminUserRoleController', [
    '$scope', '$state', '$http', '$location', 'getUseIdStatusFactory', 'getUserRoleFactory', 'getLoggedUserIdService', 'getAdminListServiceFactory',
    function ($scope, $state, $http, $location, getUseIdStatusFactory, getUserRoleFact, getLoggedUserId, getAdminListServiceFact) {

        if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalUserRole') == -1)
            return;
        $scope.$parent.ePortalCustommenus = 'User Role';
        $scope.userStatus = 1;
        $scope.saveDisabled = true;
        $scope.tableShow = true;
        $scope.roleId = 3;

        //Side menu toggling 
        var w = $('.side_menu').outerWidth();
        $('.off-canvas-overlay').hide();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');


        getUserRoleFact.getUserRole()
              .then(function (data) {
             $scope.Roles = data.userRole;
              });

        getAdminListServiceFact.getServices()
             .then(function (data) {
                 $scope.adminLi = data.adminList;
             });

     getLoggedUserId.getuserId()
        .then(function (data) {
            $scope.loggedUser = data.loggedUser;
       

        $scope.checkUserId = function () {
            if (typeof $scope.userId == "undefined" || $scope.userId == "") {
                toastr.error("Please Enter User ID");
                return false;
            }
            getUseIdStatusFactory.getUserIdStatus($scope.userId)
               .then(function (data) {
                   if (data.checkUserIdOut == true) {
                       $scope.saveDisabled = false;
                       toastr.success("User ID is Valid");
                   } else {
                       toastr.error("Not a Valid User ID");
                   }
               });
            return false;
        };

            //bind frm table to textbox;
         $scope.takeUserId = function(admUserId) {
             $scope.userId = admUserId;
         };
      
        $scope.SaveUserDetails = function () {
            if (typeof $scope.userId == "undefined" || $scope.userId == "") {
                toastr.error("Please Enter User ID");
                return false;
            }
            getUseIdStatusFactory.getUserIdStatus($scope.userId)
               .then(function (data) {
                   if (data.checkUserIdOut == true) {
                       $http({
                           method: "POST",
                           url: 'api/PostUpdateUserDetais/' + $scope.userId + "/" + $scope.userStatus + "/" + $scope.loggedUser,
                           data:''
                       }).success(function (data) {
                           if (data > 0) {
                               toastr.success("User Details Saved Successfully");
                               $scope.tableUserId = $scope.userId;

                               //Admin Active inactive reload
                               getAdminListServiceFact.getServices()
                                 .then(function (data) {
                                     $scope.adminLi = data.adminList;
                                 });
                               
                           } else {
                               toastr.error("Problem while updating, Please try again.");
                           }
                       }).error(function (e) {
                           $scope.successFlag = 0;
                           toastr.error("User role couldn't be updated due to some error");
                       });
                   } else {
                       toastr.error("Not a Valid User ID");
                   }
               });
          };
        });
     }
]);