﻿dashboardApp
    .controller('HomePageController', [
        '$scope', '$http', '$location', 'homeServiceFactory', 'menuServiceFactory', 'getAdminMenuServiceFactory',
        function ($scope,  $http, $location, homeServiceFact, menuServiceFact, adminMenuServiceFact) {
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalIndex') == -1)
                return;
            $scope.$parent.ePortalCustommenus = 'PTG EM';
            //Side menu toggling 
            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

            if (typeof $scope.menus == 'undefined') $scope.menus = {};

            // External User Admin activities
            adminMenuServiceFact.getServices().
              then(function (data) {
                  $scope.secFilterObj = data.adminMenu;
                  var secFilterObj = JSLINQ($scope.secFilterObj)
                    .Where(function (menu) { return menu.MenuId == 1; });

                  $scope.whoWeareContent = secFilterObj.items[0].Contents[0].ContentDescription;
                  $scope.ourServicesContent = secFilterObj.items[0].Contents[1].ContentDescription;
                  $scope.whatWeDoContent = secFilterObj.items[0].Contents[2].ContentDescription;
                  $scope.whyDoYouNeedContent = secFilterObj.items[0].Contents[3].ContentDescription;
              });

        //Get menu details based on role and menuType
            menuServiceFact
               .getServices("EX",1).
               then(function (data) {

                $scope.menuDetails = data;
                console.log(data);
            });
        
                //Owl courosel
                 $("#owl-demo").owlCarousel({

                     //navigation: true, // Show next and prev buttons
                     singleItem: false,
                     items: 1,
                     itemsScaleUp: false,
                     slideSpeed: 500,
                     paginationSpeed: 700,
                     rewindSpeed: 1000,
                     autoPlay: true,
                     stopOnHover: true,
                     responsive: true,
                     autoHeight: false,
                     dragBeforeAnimFinish: true,
                     mouseDrag: true,
                     touchDrag: true,
                     navigation: false,
                     pagination:false,
                    
                   });
                 var owl = $("#owl-demo").data('owlCarousel');

                 $('.prev').on('click', function (e) {
                     e.stopPropagation();
                     e.preventDefault();
                     owl.prev();
                 });
                 $('.next').on('click', function (e) {
                     e.stopPropagation();
                     e.preventDefault();
                     owl.next();
                 });


            //Dynamic services data
                 var servData = {
                     locations: [
                         {
                             "MenuId": 1,
                             "MenuDescription": "Design & Provisioning",
                             "MenuDetailDescp": "The D&P stream supports environment set-up & and sizing for new applications and projects..."
                         },
                         {
                             "MenuId": 2, "MenuDescription": "Control",
                             "MenuDetailDescp": "The Control stream bundles the 'lock-down' aspects of managing environments..."
                         },
                         {
                             "MenuId": 3, "MenuDescription": "Operation",
                             "MenuDetailDescp": "The OPS stream focuses the daily activities needed to successfully run the environments..."
                         },
                         {
                             "MenuId": 4, "MenuDescription": "Optimization",
                             "MenuDetailDescp": "The Optimization stream collates a set of activities that whilst not critical to the running of environments..."
                         },
                         {
                             "MenuId": 5, "MenuDescription": "Special Services",
                             "MenuDetailDescp": "The Special Services stream combines activities that arise through  specific customer needs..."
                         }
                     ]
                 };

                 $scope.serviceDescription = servData.locations;
                 console.log($scope.serviceDescription);

                 $scope.addServClass = function (index) {
                     if (index == 0)
                         return 'tealback';
                     else if (index == 1)
                         return 'blueback';
                     else if (index == 2)
                         return 'greenback';
                     else if (index == 3)
                         return 'orangeback';
                     else
                         return 'pinkback';
                 };

            //All Images reading from here
            $scope.imageSource1 = 'Angular/img/Client/Antonio.png';
            $scope.imageSource2 = 'Angular/img/Client/abeeyLee.png';
            $scope.imageSource3 = 'Angular/img/Client/Seeman.png';
            $scope.imageSource4 = 'Angular/img/Client/SyedAbbas.png';
            $scope.imageSource6 = 'Angular/img/Client/amith.jpg';
            $scope.imageSource8 = 'Angular/img/Client/Nina.png';
            $scope.imageSource5 = 'Angular/img/Client/Russ.png';
            $scope.imageSource7 = 'Angular/img/Client/thomas.png';
    }
    ]);