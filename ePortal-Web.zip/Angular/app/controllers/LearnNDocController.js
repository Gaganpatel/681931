﻿dashboardApp
    .controller('LearnNDocController', ['$scope', '$http', '$location', 'getKeyWordsService', 'getKSitesService', 'getLoggedUserIdService', 'getScoreCardService', 'getEmpPidServiceFactory', 'getUsersRoleFactory',
function ($scope, $http, $location, getKeyWordsService, getKSitesService, getLoggedUserId, getScoreCard, getEmpPidServiceFact, getUsersRole) {

    if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalLearningCollaboration') == -1)
            return;

        $scope.$parent.ePortalCustommenus = 'Learning and Knowledge Base';
        $scope.keywords = {};
        $scope.keyword = "";
        $scope.selkwords = new Array();
        $scope.docs = [{}];
        $scope.newloc = { "LocPath": "", "LocTitle": "", "KeyWords": "" ,"UserFirstName":"", "UserLastName":""};
        $scope.newsite = {"LocId":"", "LocPath": "", "LocTitle": "" , "CreatedBy":""};
        $scope.imagealex = 'Angular/img/AA_Happy.gif';
        $scope.sortField = 'LocTitle';
        $scope.showDoc = false;
        $scope.labelText = "";
        $scope.labelSiteText = "";
        $scope.isReadOnly = true;
        $scope.rateclicked = false;

      //Side menu toggling 
        var w = $('.side_menu').outerWidth();
        $('.off-canvas-overlay').hide();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');

        //tabs menu 
        $('.learningtab_list > li').on('click', function () {
            $(this).parent().find('.active').removeClass('active')
                .end().find(this).addClass('active');
            $('.tab_contents').find('.active').removeClass('active')
                .end().find('.' + $(this).data('target')).addClass('active');
        });

 getLoggedUserId.getuserId()
 .then(function (data) {
     $scope.loggedUser = data.loggedUser;
     $scope.newsite.CreatedBy = $scope.loggedUser;

        getKSitesService.getKSites().then(function (data) {
            $scope.ksites=data.ksites;
        });
        getKeyWordsService
                .getKeyWords()
                .then(function (data) {
                    $scope.keywords = data.kwords;
                });

           getUsersRole.getUsersRole($scope.loggedUser)
               .then(function (data) {
               if (data.usersRole.length > 0)
                   $scope.chechAdmin = true;
               else
                   $scope.chechAdmin = false;
           });

        $scope.addKeyWord = function (kword) {
            $scope.selkwords.push(kword);
            $scope.keyword = "";
            $scope.getDocs();

            //Check user id and display delete button
            $scope.checkUserName = function (doc) {
                if ($scope.chechAdmin == true) {
                    return true;
                } else {
                        if ($scope.loggedUser == doc)
                            return true;
                        else
                            return false;
                }
            };
        };

     //scoreCard List
        getScoreCard.getScore().then(function (data){
            $scope.scoreCardList = data.scoreCard;
        });

       
        $scope.deleteKnowledge = function (index,locId,locTitle) {
            var docId = locId;
            var docTitle = locTitle;
            bootbox.confirm("Are you sure you want to delete <b>" + docTitle + "</b> Knowledge?", function (result) {
                if (result) {
                    $http({
                        method: "DELETE",
                        url: 'api/DeleteKnowledge/' + locId,
                        contentType: 'application/json; charset=utf-8',
                        data: ''
                    }).success(function () {
                        getKeyWordsService
                                .getKeyWords()
                                .then(function (data) {
                                    $scope.keywords = data.kwords;
                                });
                        $scope.docs.splice(index, 1);
                        $scope.selkwords.splice(index, 1);
                        //Success
                        toastr.success("Knowledge deleted");
                    });
                }
            });
        };

        $scope.deleteSite = function (index) {
            bootbox.confirm("Are you sure you want to delete?", function (result) {
                if (result) {
                    $http({
                        method: "DELETE",
                        url: 'api/DeleteSite/' + $scope.ksites[index].LocId,
                        contentType: 'application/json; charset=utf-8',
                        data: ''
                    }).success(function() {
                        $scope.ksites.splice(index, 1);
                        //Success
                        toastr.success("Site deleted.");
                    });
                }
            });
        };

       $scope.deleteKeyword = function (index) {
           $scope.selkwords.splice(index, 1);
           $scope.getDocs();
            };
       $scope.getDocs = function () {
           $http({
               method: "POST",
               url: 'api/FetchDocs',
               data: $scope.selkwords
           }).success(function(data) {
               $scope.docs = data;
               $scope.showDoc = true;
           });
       };
     
       $scope.SaveSite = function () {
           if ($scope.action == 'A') $scope.addNewSite();
           if ($scope.action == 'E') $scope.editKSite();
       };
       $scope.addNewSite = function () {
           if (typeof ($scope.newsite.LocPath) == 'undefined' || typeof ($scope.newsite.LocTitle) == 'undefined' || $scope.newsite.LocPath == "" || $scope.newsite.LocTitle == "" ) {
               $scope.labelSiteText = "Note: Please fill all details before adding Site";
           } else {
               $http({
                   method: "POST",
                   url: "api/AddNewSite/",
                   data: $scope.newsite
               }).success(function() {
                   getKSitesService.getKSites().then(function(data) {
                       $scope.ksites = data.ksites;
                   });
                   $scope.newsite = null;
                   $scope.labelSiteText = "";
                   //modal close
                   $("#siteModal").modal('hide');

                   toastr.success("Site Added successfully");
               });
           }

       };
       $scope.editSite = function (site) {
           //$scope.newsite = $scope.ksites.filter(function (site) { return site.LocId === index; })[0];
           $scope.newsite = site;
           $scope.action = 'E';
       };

       $scope.editKSite = function () {
           if (typeof ($scope.newsite.LocPath) == 'undefined' || typeof ($scope.newsite.LocTitle) == 'undefined' || $scope.newsite.LocPath == "" || $scope.newsite.LocTitle == "") {
               $scope.labelSiteText = "Note: Please fill all details before adding Site";
           } else {
               $http({
                   method: "POST",
                   url: "api/UpdateSite/",
                   data: $scope.newsite
               }).success(function() {
                   $scope.labelSiteText = "";
                   $scope.newsite = null;
                   //modal close
                   $("#siteModal").modal('hide');
                   //Success
                   toastr.success("Site information Updated successfully.");
               });
           }
       };

    
     //Get menu details based on role and menuType
       getEmpPidServiceFact
           .getServices().
           then(function (data) {
               $scope.empPid = data.empPid[0];
               $scope.newloc.UserFirstName=  data.empPid[1].toUpperCase();
               $scope.newloc.UserLastName=  data.empPid[2].toUpperCase();
           });

       $scope.SaveKnowledge = function () {
           if ($scope.actionKnowledge == 'A') $scope.addNewLink();
           if ($scope.actionKnowledge == 'E') $scope.editKnowledgeBase();
       };

       $scope.editKnowledge = function (loc) {
           //$scope.newsite = $scope.ksites.filter(function (site) { return site.LocId === index; })[0];
           $scope.newloc = loc;
           $scope.actionKnowledge = 'E';
       };

       $scope.addNewLink = function () {
           if (typeof ($scope.newloc.LocPath) == 'undefined' || typeof ($scope.newloc.LocTitle) == 'undefined' || typeof ($scope.newloc.KeyWords) == 'undefined'
               || $scope.newloc.LocPath == "" || $scope.newloc.LocTitle == "" || $scope.newloc.KeyWords=="") {
               $scope.labelText = "Note: Please fill all details before adding knowledge";
           }
           else {
               $http({
                   method: "POST",
                   url: "api/AddNewLink/",
                   data: $scope.newloc
               }).success(function() {
                   getKeyWordsService
                       .getKeyWords()
                       .then(function(data) {
                           $scope.keywords = data.kwords;
                       });
                   $scope.docs.push($scope.newloc);
                   $scope.newloc = null;
                   $scope.labelText = "";
                   //modal close
                   $("#docModal").modal('hide');
                   //Success
                   toastr.success("New Knowledge Saved successfully.");
               });
           }

       };

     //edit knowledge
       $scope.editKnowledgeBase = function () {
           if (typeof ($scope.newloc.LocPath) == 'undefined' || typeof ($scope.newloc.LocTitle) == 'undefined' || typeof ($scope.newloc.KeyWords) == 'undefined'
               || $scope.newloc.LocPath == "" || $scope.newloc.LocTitle == "" || $scope.newloc.KeyWords == "") {
               $scope.labelText = "Note: Please fill all details before adding knowledge";
           } else {
               $http({
                   method: "POST",
                   url: "api/UpdateKnowledge/",
                   data: $scope.newloc
               }).success(function () {
                   $scope.labelText = "";
                   $scope.newloc = null;
                   //modal close
                   $("#docModal").modal('hide');
                   //Success
                   toastr.success("Knowledge information Updated successfully.");
                   getKeyWordsService
                                .getKeyWords()
                                .then(function (data) {
                                    $scope.keywords = data.kwords;
                                });
               });
           }
       };

     //Rating related code

     $scope.RateDocumentButton = function(locId) {
         $scope.docIdforRating = locId;
         $scope.rateclicked = true;
     };

       $scope.Finalrating = 1;
       if (typeof ($scope.onRatingSelected) == 'undefined')
           $scope.onRatingSelected = new Array();
       $scope.rating = 1;
       $scope.rateFunction = function (rating) {
           $scope.updateRating(rating);
       };

       $scope.updateRating = function (rating) {
           $scope.Finalrating = rating;
           var docIdR = $scope.docIdforRating; // DocId
           var rate = rating;
           var userId = $scope.loggedUser;

           $http({
               method: "POST",
               url: 'api/PostRatingForDocument/' + docIdR + '/' + rate + '/' + userId,
               contentType: 'application/json; charset=utf-8',
               data: ''
           }).success(function (data) {
               //$scope.docs = data;
           });
       };

       $scope.closeRating = function () {
           toastr.success("Thanks for rating the Knowledge");
           $scope.getDocs();
           $scope.Finalrating = 1;
           $scope.rating = 1;
           $scope.rateclicked = false;
       };

 });

}])


.controller('WelcomeController', ['$scope', '$http', '$location', 'getNotesFactory', 'getKeyWordsService', 'getKSitesService', 'getLoggedUserIdService',
function ($scope, $http, $location, getNotesFactory, getKeyWordsService, getKSitesService, getLoggedUserId) {
    $scope.$parent.ePortalCustommenus = 'Home';
    $scope.keywords = {};
    $scope.keyword = "";
    $scope.selkwords = new Array();
    $scope.docs = [{}];
    $scope.newloc = { "LocPath": "", "LocTitle": "", "KeyWords": "" };
    $scope.newsite = { "LocId": "", "LocPath": "", "LocTitle": "" };
    $scope.imagealex = 'Angular/img/AA_Happy.gif';
    $scope.sortField = 'LocTitle';
    $scope.showDoc = false;
    $scope.labelText = "";
    $scope.labelSiteText = "";
    $scope.isReadOnly = true;

    $scope.notes = "";



    getNotesFactory.getNotes()
        .then(function (data) {
            $scope.notes = data.note.replace(/\r/g, "<br>");
            $scope.noteNews = data.note.replace(/\r/g, "\n");
        });

    $scope.checking = function () {
        $scope.notesData = { Note: $scope.noteNews.replace(/\n/g, " NL ") };
        $http({
            method: "POST",
            url: 'api/PostNotes/',
            data: JSON.stringify($scope.notesData)
         }).success(function (data) {
            $scope.successFlag = 1;
            toastr.success("Notes Updated");
        }).error(function (e) {
            $scope.successFlag = 0;
            toastr.error("Notes could not be updated due to some error");
        });

    };

    //Side menu toggling 
    var w = $('.side_menu').outerWidth();
    $('.off-canvas-overlay').hide();
    $('.side_menu').animate({
        left: '-' + w + 'px'
    }, 200).toggleClass('active');

    //tabs menu 
    $('.learningtab_list > li').on('click', function () {
        $(this).parent().find('.active').removeClass('active')
            .end().find(this).addClass('active');
        $('.tab_contents').find('.active').removeClass('active')
            .end().find('.' + $(this).data('target')).addClass('active');
    });


    getLoggedUserId.getuserId()
    .then(function (data) {
        $scope.loggedUser = data.loggedUser;

        getKSitesService.getKSites().then(function (data) {
            $scope.ksites = data.ksites;
        });
        getKeyWordsService
                .getKeyWords()
                .then(function (data) {
                    $scope.keywords = data.kwords;
                });

        $scope.addKeyWord = function (kword) {
            $scope.selkwords.push(kword);
            $scope.keyword = "";
            $scope.getDocs();

            //Check user id and display delete button
            $scope.checkUserName = function (doc) {
                if ($scope.loggedUser == doc)
                    return true;
                else
                    return false;
            };
        };


        $scope.deleteKnowledge = function (locId, locTitle) {
            var docId = locId;
            var docTitle = locTitle;
            bootbox.confirm("Are you sure you want to delete <b>" + docTitle + "</b> Knowledge?", function (result) {
                if (result) {
                    $http({
                        method: "DELETE",
                        url: 'api/DeleteKnowledge/' + locId,
                        contentType: 'application/json; charset=utf-8',
                        data: ''
                    }).success(function () {
                        getKeyWordsService
                                .getKeyWords()
                                .then(function (data) {
                                    $scope.keywords = data.kwords;
                                });
                        $scope.docs.splice(index, 1);
                        //Success
                        toastr.success("Knowledge deleted");
                    });
                }
            });
        };

        $scope.deleteSite = function (index) {
            bootbox.confirm("Are you sure you want to delete?", function (result) {
                if (result) {
                    $http({
                        method: "DELETE",
                        url: 'api/DeleteSite/' + $scope.ksites[index].LocId,
                        contentType: 'application/json; charset=utf-8',
                        data: ''
                    }).success(function () {
                        $scope.ksites.splice(index, 1);
                        //Success
                        toastr.success("Site deleted.");
                    });
                }
            });
        };

        $scope.deleteKeyword = function (index) {
            $scope.selkwords.splice(index, 1);
            $scope.getDocs();
        };
        $scope.getDocs = function () {
            $http({
                method: "POST",
                url: 'api/FetchDocs',
                data: $scope.selkwords
            }).success(function (data) {
                $scope.docs = data;
                $scope.showDoc = true;
            });
        };

        $scope.SaveSite = function () {
            if ($scope.action == 'A') $scope.addNewSite();
            if ($scope.action == 'E') $scope.editKSite();
        };
        $scope.addNewSite = function () {
            if (typeof ($scope.newsite.LocPath) == 'undefined' || typeof ($scope.newsite.LocTitle) == 'undefined' || $scope.newsite.LocPath == "" || $scope.newsite.LocTitle == "") {
                $scope.labelSiteText = "Note: Please fill all details before adding Site";
            } else {
                $http({
                    method: "POST",
                    url: "api/AddNewSite/",
                    data: $scope.newsite
                }).success(function () {
                    getKSitesService.getKSites().then(function (data) {
                        $scope.ksites = data.ksites;
                    });
                    $scope.newsite = null;
                    $scope.labelSiteText = "";
                    //modal close
                    $("#siteModal").modal('hide');

                    toastr.success("Site Added successfully");
                });
            }

        };
        $scope.editSite = function (site) {
            //$scope.newsite = $scope.ksites.filter(function (site) { return site.LocId === index; })[0];
            $scope.newsite = site;
            $scope.action = 'E';
        };

        $scope.editKSite = function () {
            if (typeof ($scope.newsite.LocPath) == 'undefined' || typeof ($scope.newsite.LocTitle) == 'undefined' || $scope.newsite.LocPath == "" || $scope.newsite.LocTitle == "") {
                $scope.labelSiteText = "Note: Please fill all details before adding Site";
            } else {
                $http({
                    method: "POST",
                    url: "api/UpdateSite/",
                    data: $scope.newsite
                }).success(function () {
                    $scope.labelSiteText = "";
                    //modal close
                    $("#siteModal").modal('hide');
                    //Success
                    toastr.success("Site information Updated successfully.");
                });
            }
        };
        $scope.addNewLink = function () {

            if (typeof ($scope.newloc.LocPath) == 'undefined' || typeof ($scope.newloc.LocTitle) == 'undefined' || typeof ($scope.newloc.KeyWords) == 'undefined'
                || $scope.newloc.LocPath == "" || $scope.newloc.LocTitle == "" || $scope.newloc.KeyWords == "") {
                $scope.labelText = "Note: Please fill all details before adding knowledge";
            }
            else {
                $http({
                    method: "POST",
                    url: "api/AddNewLink/",
                    data: $scope.newloc
                }).success(function () {
                    getKeyWordsService
                        .getKeyWords()
                        .then(function (data) {
                            $scope.keywords = data.kwords;
                        });
                    $scope.docs.push($scope.newloc);
                    $scope.newloc = null;
                    $scope.labelText = "";
                    //modal close
                    $("#docModal").modal('hide');
                    //Success
                    toastr.success("New Knowledge Saved Successfully.");
                });
            }

        };

        //Rating related code

        $scope.RateDocumentButton = function (locId) {
            $scope.docIdforRating = locId;
        };

        $scope.Finalrating = 1;
        if (typeof ($scope.onRatingSelected) == 'undefined')
            $scope.onRatingSelected = new Array();
        $scope.rating = 1;
        $scope.rateFunction = function (rating) {
            $scope.updateRating(rating);
        };

        $scope.updateRating = function (rating) {
            $scope.Finalrating = rating;
            var docIdR = $scope.docIdforRating; // DocId
            var rate = rating;
            var userId = $scope.loggedUser;

            $http({
                method: "POST",
                url: 'api/PostRatingForDocument/' + docIdR + '/' + rate + '/' + userId,
                contentType: 'application/json; charset=utf-8',
                data: ''
            }).success(function (data) {
                //$scope.docs = data;
            });
        };

        $scope.closeRating = function () {
            toastr.success("Thanks for rating the Knowledge");
            $scope.getDocs();
            $scope.Finalrating = 1;
            $scope.rating = 1;
        };

        $scope.disableClick = function(e) {
            e.preventDefault();
            e.stopPropagation();
        };

    });
}])

.directive('starRating',
	function () {
	    return {
	        restrict: 'A',
	        template: '<ul class="rating">'
					 + '	<li ng-repeat="star in stars" ng-class="star" ng-click="toggle($index)">'
					 + '\u2605'
					 + '</li>'
					 + '</ul>',
	        scope: {
	            ratingValue: '=',
	            max: '=',
	            onRatingSelected: '&'
	        },
	        link: function (scope, elem, attrs) {
	            var updateStars = function () {
	                scope.stars = [];
	                for (var i = 0; i < scope.max; i++) {
	                        scope.stars.push({
	                            filled: i < scope.ratingValue
	                        });
	                }
	            };

	            scope.toggle = function (index) {
	                scope.ratingValue = index + 1;
	                scope.onRatingSelected({
	                    rating: index + 1
	                });
	            };

	            scope.$watch('ratingValue',
					function (oldVal, newVal) {
					    if (newVal) {
					        updateStars();
					    }
					}
				);
	        }
	    };
	}
)
.directive('starRating1',
	function () {
	    return {
	        restrict: 'A',
	        template: '<ul class="rating">'
					 + '	<li ng-repeat="star in stars" ng-class="star">'
					 + '\u2605'
					 + '</li>'
					 + '</ul>',
	        scope: {
	            ratingValue: '=',
	            max: '=',
	            onRatingSelected: '&',
	            rateclicked: '='
	        },
	        link: function (scope, elem, attrs) {
	            var updateStars = function () {
	                scope.stars = [];
	                for (var i = 0; i < scope.max; i++) {
	                    if (!scope.rateclicked) {
	                        if (scope.ratingValue - i >= 1) {
	                            scope.stars.push({
	                                filled: i < scope.ratingValue
	                            });
	                        }
	                        else if (scope.ratingValue - i < 1 && scope.ratingValue - i > 0) {
	                            scope.stars.push({
	                                halffilled: i < scope.ratingValue
	                            });
	                        }
	                        else {
	                            scope.stars.push({
	                                filled: i < scope.ratingValue
	                            });
	                        }
	                    }
	                    else {
	                        scope.stars.push({
	                            filled: i < scope.ratingValue
	                        });
	                    }
	                }
	            };

	            scope.toggle = function (index) {
	                scope.ratingValue = index + 1;
	                scope.onRatingSelected({
	                    rating: index + 1
	                });
	            };

	            scope.$watch('ratingValue',
					function (oldVal, newVal) {
					    if (newVal) {
					        updateStars();
					    }
					}
				);
	        }
	    };
	}
);