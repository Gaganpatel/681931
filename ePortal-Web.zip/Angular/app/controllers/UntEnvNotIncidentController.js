﻿dashboardApp
    .controller('UntEnvNotIncidentController', [
        '$scope', '$location', '$http', 'UntInitiateIncidentServiceFactory', 'UntPostIncidentServiceFactory',
        function ($scope, $location, $http, untInitiateIncidentServiceFact, untPostIncidentServiceFact
        ) {
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalCommunication') == -1)
                return;
            $scope.Statusradio = 'Warning';
            $scope.dataLoaded = false;
            untInitiateIncidentServiceFact.getServices()
             .then(function (data) {
                 $scope.Incident = new Array();
                 $scope.Incident = data.IncidentObjectResponse[0];
                 $scope.showUpdateDt = false;
                $scope.Incident.CommunicationTypeId = $scope.$parent.Incident.CommunicationTypeId;
                $scope.Incident.CommunicationTypeDesc = $scope.$parent.Incident.CommunicationTypeDesc;
                clearInfoValidation($scope.UntEnvNotIncident);
                 //if (data.IncidentObjectResponse[1] == null )
                 //    toastr.warning("Incidents cannot be created now.");
                 //else {
                 //    $scope.Impacts = angular.copy(data.IncidentObjectResponse[1]);
                     
                 //}
                 $scope.dataLoaded = true;
                 
             });

            var st = 'begin';
            console.log(st);

            $scope.clearForm = function () {
                untInitiateIncidentServiceFact.getServices()
                    .then(function (data) {
                        $scope.Incident = new Array();
                        var incData = data.IncidentObjectResponse[0];
                        $scope.Incident = incData;
                        $scope.Incident.CommunicationTypeId = $scope.$parent.Incident.CommunicationTypeId;
                        $scope.Incident.CommunicationTypeDesc = $scope.$parent.Incident.CommunicationTypeDesc;
                        clearInfoValidation($scope.UntEnvNotIncident);
                    });
            };

            $scope.changeStatus = function () {
            $scope.Incident.Status = $scope.Statusradio;
                if ($scope.Statusradio == 'Issue Resolved') {
                    $scope.Incident.ExpiryDate = $scope.Incident.ResExpiryDate;
                } else
                    $scope.Incident.ExpiryDate = $scope.Incident.ActualExpiryDate;
            };

            // Code to save data in Publish mode. Ready to be send to queue
            $scope.PublishBtn_Click = function (incident) {
                var t = 'Publish';
                $scope.dataLoaded = false;
                incident.saveMode = true;
                incident.ValidIncident = true;
                incident.errorFields = '';
                if (incident.Type == 'undefined')
                    $scope.Incident.Type = 'Information';
                ValidateBeforeSave($scope, incident);
                if (incident.ValidIncident) {
                    untPostIncidentServiceFact.getServices(incident)
                        .then(function (data) {
                            $scope.Incident = data.IncidentObjectResponse;
                            $scope.dataLoaded = true;
                            if (data.IncidentObjectResponse.IncidentId == -1) {
                                toastr.warning("Incident with the name " + $scope.Incident.IncidentId + " already exists. So it cannot be Saved.");
                            }
                            else if (data.IncidentObjectResponse.SendEmail == true && data.IncidentObjectResponse.SendUnt == true) {
                                toastr.success("Incident Published and emailed Successfully.");
                            } else if (data.IncidentObjectResponse.SendEmail == true && data.IncidentObjectResponse.SendUnt == false) {
                                toastr.success("Incident emailed Successfully.");
                            } else {
                            toastr.success("Incident Published Successfully.");
                        }
                        $scope.clearForm();
                            
                        });
                        

                } else {
                    $scope.dataLoaded = true;
                    toastr.warning("Please enter " + incident.errorFields.replace(/^,|,$/g, '') + " .");
                }

            };

            //*** For date  Picker
            $scope.today = function () {
                $scope.dt = new Date();
            };
            $scope.today();

            $scope.clear = function () {
                $scope.dt = null;
            };

            // Disable weekend selection
            $scope.disabled = function (date, mode) {
                return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
            };

            $scope.toggleMin = function () {
                $scope.minDate = $scope.minDate ? null : new Date();
            };
            $scope.toggleMin();

            $scope.open = function ($event) {
                $scope.Incident.NextDate = $scope.dt;
                $event.preventDefault();
                $event.stopPropagation();

                $scope.opened = true;
            };

            $scope.dateOptions = {
                formatYear: 'yy',
                startingDay: 1
            };
            //*** For date  Picker


        }

    ]);

function clearInfoValidation(sendForm) {
    sendForm.IncidentDescription.$invalid = false;
    sendForm.IncidentDescription.$pristine = true;
    sendForm.ImpactedAreas.$invalid = false;
    sendForm.ImpactedAreas.$pristine = true;

    sendForm.BusinessArea.$invalid = false;
    sendForm.BusinessArea.$pristine = true;
    sendForm.ActionsTaken.$invalid = false;
    sendForm.ActionsTaken.$pristine = true;
    sendForm.ResolutionETA.$invalid = false;
    sendForm.ResolutionETA.$pristine = true;
    sendForm.Comments.$invalid = false;
    sendForm.Comments.$pristine = true;
    sendForm.IncidentManager.$invalid = false;
    sendForm.IncidentManager.$pristine = true;
    sendForm.PTGSupportContacts.$invalid = false;
    sendForm.PTGSupportContacts.$pristine = true;
    sendForm.Recipients.$invalid = false;
    sendForm.Recipients.$pristine = true;
}

function ValidateBeforeSave($scope, incidentReq) {
    
    if (incidentReq.Status == null) {
        incidentReq.Status = $scope.Statusradio;
    }

    if (incidentReq.saveMode) {
        //if (incidentReq.IncidentName == null) {
        //    $scope.UntEnvNotIncident.IncidentName.$invalid = true;
        //    $scope.UntEnvNotIncident.IncidentName.$pristine = false;
        //    $scope.Incident.ValidIncident = false;
        //    $scope.Incident.errorFields = 'Incident Label';
        //}
        if (incidentReq.IncidentDescription == null) {
            $scope.UntEnvNotIncident.IncidentDescription.$invalid = true;
            $scope.UntEnvNotIncident.IncidentDescription.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Incident Description';
        }

        //if (incidentReq.ImpactId == null || incidentReq.ImpactId == 0) {
        //    $scope.UntEnvNotIncident.ImpactId.$invalid = true;
        //    $scope.UntEnvNotIncident.ImpactId.$pristine = false;
        //    $scope.Incident.ValidIncident = false;
        //    $scope.Incident.errorFields += ',Impact';
        //}
        if (incidentReq.ImpactedAreas == null) {
            $scope.UntEnvNotIncident.ImpactedAreas.$invalid = true;
            $scope.UntEnvNotIncident.ImpactedAreas.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Impacted Areas';
        }
        if (incidentReq.BusinessArea == null) {
            $scope.UntEnvNotIncident.BusinessArea.$invalid = true;
            $scope.UntEnvNotIncident.BusinessArea.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Business Area';
        }
        if (incidentReq.ActionsTaken == null) {
            $scope.UntEnvNotIncident.ActionsTaken.$invalid = true;
            $scope.UntEnvNotIncident.ActionsTaken.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Actions Taken';
        }
        if (incidentReq.ResolutionETA == null) {
            $scope.UntEnvNotIncident.ResolutionETA.$invalid = true;
            $scope.UntEnvNotIncident.ResolutionETA.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',ETA for Resolution';
        }


        if (incidentReq.Comments == null ) {
            $scope.UntEnvNotIncident.Comments.$invalid = true;
            $scope.UntEnvNotIncident.Comments.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Comments';
        }

        if (incidentReq.IncidentManager == null) {
            $scope.UntEnvNotIncident.IncidentManager.$invalid = true;
            $scope.UntEnvNotIncident.IncidentManager.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Incident Manager';
        }
        if (incidentReq.PTGSupportContacts == null) {
            $scope.UntEnvNotIncident.PTGSupportContacts.$invalid = true;
            $scope.UntEnvNotIncident.PTGSupportContacts.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',PTG Support Contacts';
        }
        if (incidentReq.Recipients == null) {
            $scope.UntEnvNotIncident.Recipients.$invalid = true;
            $scope.UntEnvNotIncident.Recipients.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Recipients';
        }
        if (incidentReq.SendEmail == null) {
            $scope.UntEnvNotIncident.SendEmail.$invalid = true;
            $scope.UntEnvNotIncident.SendEmail.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Send Email';
        }
        if (incidentReq.SendUnt == null) {
            $scope.UntEnvNotIncident.SendUnt.$invalid = true;
            $scope.UntEnvNotIncident.SendUnt.$pristine = false;
            $scope.Incident.ValidIncident = false;
            $scope.Incident.errorFields += ',Send Unt';
        }

    } else {
        if (incidentReq.IncidentDescription == null) {
            $scope.UntEnvNotIncident.IncidentDescription.$invalid = true;
            $scope.UntEnvNotIncident.IncidentDescription.$pristine = false;
            $scope.Incident.ValidIncident = false;

        }
    }
}