﻿dashboardApp
    .controller('UntIncidentController', [
        '$scope', '$location', '$http','UntInitiateIncidentServiceFactory',
        function ($scope, $location, $http, untInitiateIncidentServiceFact
        ) {
            //var loc = $location.search('welcome');
            //if ($rootScope.selectedPage == 'welcome')
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalCommunication') == -1)
                return;
            
            $scope.dataLoaded = false;
            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

           
            $('#myTab a').click(function (e) {
                e.preventDefault();
                $(this).tab('show');
            });
            // Assigning BreadCrums
            $scope.$parent.ePortalCustommenus = 'Communication';


            

            //$scope.Incident = new Array();
           // $scope.CommunicationTypeId = 0;
            untInitiateIncidentServiceFact.getServices().then(function(data) {
                $scope.CommunicationType = data.IncidentObjectResponse[1];
                $scope.CommunicationTypeId = data.IncidentObjectResponse[1][0].rowId;
                $scope.Template = "";
                $scope.Incident = new Array();
                $scope.Incident = data.IncidentObjectResponse[0];
                $scope.Incident.rowId = data.IncidentObjectResponse[1][0].rowId;
                $scope.Incident.CommunicationTypeId = data.IncidentObjectResponse[1][0].CommunicationTypeId;
                $scope.Incident.CommunicationTypeDesc = data.IncidentObjectResponse[1][0].CommunicationTypeDesc;
                $scope.Incident.CommunicationTypeSrc = data.IncidentObjectResponse[1][0].CommunicationTypeSrc;
                $scope.dataLoaded = true;
            });
            //$scope.CommunicationType = CommunicationTypeTable.CommunicationTypes;
            $scope.setCommunicationTypeView = (function(index) {

                var ch = 'comm type';
                //$scope.CommunicationTypeId = $scope.CommunicationType[index].CommunicationTypeId;
                $scope.CommunicationTypeDesc = $scope.CommunicationType[index].CommunicationTypeDesc;
                $scope.Template = $scope.CommunicationType[index].CommunicationTypeSrc;
                if ($scope.Template.trim() == '')
                    $scope.Template = 'undefined';
                $scope.Incident.rowId = $scope.CommunicationType[index].rowId;
                $scope.Incident.CommunicationTypeId = $scope.CommunicationType[index].CommunicationTypeId;
                $scope.Incident.CommunicationTypeDesc = $scope.CommunicationType[index].CommunicationTypeDesc;
                $scope.Incident.CommunicationTypeSrc = $scope.CommunicationType[index].CommunicationTypeSrc;
                //$scope.CommunicationType.CommunicationTypeId
                //$scope.CommunicationTypeDesc = CommunicationTypeTable.CommunicationTypes[index].CommunicationTypeDesc;
                //$scope.Template = CommunicationTypeTable.CommunicationTypes[index].CommunicationTypeSrc;
                $scope.slide = true;
                $scope.dataLoaded = true;
            });

            

        }
    ]);


var CommunicationTypeTable = {
    CommunicationTypes: [
        {
            'CommunicationTypeId': 0,
            'CommunicationTypeDesc': 'Select Communication Type',
            'CommunicationTypeSrc': ''
        },
        {
            'CommunicationTypeId': 1,
            'CommunicationTypeDesc': 'Environment Incident Notifications',
            'CommunicationTypeSrc': 'Angular/app/views/internaluser/UNToolUser/UntEnvNotIncident.html'
        },
        {
            'CommunicationTypeId': 2,
            'CommunicationTypeDesc': 'Planned Downtime Notifications',
            'CommunicationTypeSrc': 'Angular/app/views/internaluser/UNToolUser/UntPlannedDowntime.html'
            //'CommunicationTypeSrc': 'Angular/app/views/internaluser/newjoiner/WIP.html'
        }
    ]};


