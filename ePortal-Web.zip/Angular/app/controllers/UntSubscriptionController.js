﻿dashboardApp
    .controller('UntSubscriptionController', [
        '$scope', '$http', '$location', '$timeout', '$filter',
        'InitiateSubscriptionServiceFactory', 'PostSubscriptionServiceFactory',
function ($scope, $http, $location, $timeout, $filter
    , initiateSubscriptionServiceFact , postSubscriptionServiceFact 
    ) {

    if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalSubscription') == -1)
        return;


    var w = $('.side_menu').outerWidth();
    $('.off-canvas-overlay').hide();
    $('.side_menu').animate({
        left: '-' + w + 'px'
    }, 200).toggleClass('active');


    $('#myTab a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
    // Assigning BreadCrums
    $scope.$parent.ePortalCustommenus = 'Subscription';

    $scope.loadingFteAllocatedResources = false;
    var st = 'subscription';

    $scope.dataLoaded = false;
  
    initiateSubscriptionServiceFact.getServices()
               .then(function (data) {
                   $scope.SubscriptionMapping = new Array();
                   $scope.Subscriptions = data.SubscriptionObjectResponse[0];
                   $scope.SubscriptionMapping = data.SubscriptionObjectResponse[1];
                   $scope.dataLoaded = true;

               });

    $scope.setSubscription = function (subscribeItem) {
        $scope.selSubscription = subscribeItem.SubscriptionId;
        $scope.dataLoaded = true;
    };



    $scope.addSubscription = function (item, index) {
        var t = 'subscription';
        $scope.dataLoaded = false;
        if ($scope.SubscriptionMapping == null)
            $scope.SubscriptionMapping = new Array();
        if (item.SubscriptionId == 0 || item.SubscriptionId == null) {
            postSubscriptionServiceFact.
                getServices(item, false).
                then(function (data) {
                    t = 'added';
                    //temporary commented enable it
                    
                    if (data.subscriptionObjectResponse.SubscriptionId != null) {
                                                  
                        item.SubscriptionId = data.subscriptionObjectResponse.SubscriptionId;
                        item.logDate = data.subscriptionObjectResponse.logDate;
                        item.CommunicationTypeDesc = data.subscriptionObjectResponse.CommunicationTypeDesc;
                        if ($scope.SubscriptionMapping == null)
                            $scope.SubscriptionMapping = new Array();


                        $scope.SubscriptionMapping.push(item);
                    }
                    $scope.dataLoaded = true;
                });
        } else {
            $scope.SubscriptionMapping.push(item);
            $scope.dataLoaded = true;
        }
    };





    $scope.removeSubscription = function (item, index) {
        var t = 'Remove subscription';
        $scope.dataLoaded = false;
        bootbox.confirm("Do you really want to delete Subscription for " + item.EnvironmentApp + "?", function (result) {
            if (result) {
                postSubscriptionServiceFact.
                    getServices(item, true).
                    then(function (data) {
                        t = 'deleted';
                        //$scope.SubscriptionMapping.splice($scope.SubscriptionMapping.indexOf(item), 1);
                        $scope.SubscriptionMapping[index].SubscriptionId = null;
                        $scope.SubscriptionMapping.splice(index, 1);
                        $scope.dataLoaded = true;
                    });
            }
        });
    };




}
    ])

.filter('nlToArray', function () {
    var t = 'filter';
    return function(text) {
        return text.split('\n');
    };
});


