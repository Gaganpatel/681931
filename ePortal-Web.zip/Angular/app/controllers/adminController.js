﻿dashboardApp.
controller('AdminController', [
    '$scope', '$location' ,'$http', 'menuServiceFactory', 'getAdminMenuServiceFactory', 'getProjServiceFactory', 'getFaqSectionListServiceFactory', 'getFaqQuestionAnswerServiceFactory', '$rootScope',
    function ($scope,$location, $http, menuServiceFact, adminMenuServiceFact, getProjServiceFact, getFaqSectionListServiceFact, getFaqQuestionAnswerServiceFact, $rootScope) {
        if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalAdmin') == -1)
            return;
        // Assigning BreadCrums
        $scope.$parent.ePortalCustommenus='Admin';

        //Get menu details based on role and menuType
        menuServiceFact
           .getServices("IN", 10).
           then(function (data) {
               //console.log(data);
           });

        var w = $('.side_menu').outerWidth();
        $('.off-canvas-overlay').hide();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');

        $('#myTab a').click(function (e) {
            e.preventDefault();
            $(this).tab('show');
        });

        //tabs menu 
        $('.admintab_list > li').on('click', function () {
            $(this).parent().find('.active').removeClass('active')
                 .end().find(this).addClass('active');
            $('.tab_contents').find('.active').removeClass('active')
                .end().find('.' + $(this).data('target')).addClass('active');
        });

        $scope.secContenObj = {};

        // External User Admin activities
        adminMenuServiceFact.getServices().
          then(function (data) {
              $scope.secFilterObj = data.adminMenu;
              var secFilterObj = JSLINQ($scope.secFilterObj)
                .Where(function (menu) { return menu.MenuId < 6; });
            $scope.menuOptions = secFilterObj.items;
        });

        //Menu select change operation
        $scope.menuChnage = function (index) {
            $scope.MenuId = $scope.menuOptions[index].MenuId; //Assigning menuid to scope
            $scope.textExternalCont = null;
            $scope.secIndex = '';
        };

       // JSLinq used for section select change
        $scope.secChange = function (index,secIndex) {
            var secFilterObj = JSLINQ($scope.menuOptions[index].Contents)
                .Where(function (section) { return section.SectionId == secIndex; });

            $scope.sectionId = secIndex;  //Assigning menuid to scope

            if (secFilterObj != 'undifined') {
                $scope.secContent = secFilterObj.items[0].ContentDescription;
                $scope.textExternalCont = $scope.secContent;
                $scope.contentId = secFilterObj.items[0].ContentId;
                $scope.contentTitle = secFilterObj.items[0].ContentTitle;
                $scope.contentFooter = secFilterObj.items[0].ContentFooter;
            }
        };

        //Call the WebAPI method to post the budget plan details & redirect to the MPP mapping page on successfull promise on completion//Start//
        $scope.saveSectContent = function (secId, txtExternal) {
            if (typeof secId != 'undefined') {
            $scope.secContenObj.sectionId = secId;
            $scope.secContenObj.ContentDescription = txtExternal;
            $scope.secContenObj.contentTitle = $scope.contentTitle;
            $scope.secContenObj.contentFooter = $scope.contentFooter;
            $scope.secContenObj.contentId = $scope.contentId;
            $scope.secContenObj.menuId = $scope.MenuId;
            
            $http({
                method: "POST",
                url: 'api/PostSectionContent/',
                data: $scope.secContenObj
            }).success(function (data) {
                //Success
                toastr.success("External user content saved successfully.");
            }).error(function (e) {
                //Error
                toastr.error("Error found.");
            });
            } else {
                toastr.info("Please select section.");
            }
        };

        $scope.flag1 = false;

        //External User checkbox
        $scope.addLinkDivExternal = function () {
            if ($scope.flag1 == false)
                $scope.flag1 = true;
            else {
                $scope.flag1 = false;
            }
        };

        $scope.linkArrayRowExter = new Array();

        //Add row toadd link internal
        $scope.addProjectExternal = function () {

            $scope.linkArrayRowExter.push({ "linkDescriptionExt": $scope.linkDescriptionExt, "linkExt": $scope.linkExt, "linkOrderExt": $scope.linkOrderExt });

            $scope.linkDescriptionExt = '';
            $scope.linkExt = '';
            $scope.linkOrderExt = '';
        };

//-----------------------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------Internal user admin work------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------

        $scope.secFilterObjInternal = {};
        $scope.txtSectionInternal = true; // Disable enable text area;
        $scope.linkArrayRow = new Array();
        $scope.secFilterObjInternalFinalArray = {};
        $scope.secFilterObjInternalFinalArrayFAQ = {};

        //Get projects from DB
        getProjServiceFact
           .getServices().
           then(function (data) {
               $scope.projects = data.proj;
           });

        // External User Admin activities
        adminMenuServiceFact.getServices().
          then(function (data) {
              $scope.secFilterObjInternal = data.adminMenu;
              var secFilterObjInternal = JSLINQ($scope.secFilterObjInternal)
                .Where(function (menu) { return menu.MenuId > 5; });
              $scope.menuOptionsInternal = secFilterObjInternal.items;
          });

        // External User Admin activities
        getFaqSectionListServiceFact.getServices().
          then(function (data) {
              $scope.menuOptionsInternalFAQ = data.FAQlistResult;
          });
      
        //Menu select change operation
        $scope.menuChnageInternal = function (indexInt) {
            $scope.secIndexInternal = '';
            $scope.showIntrContentDiv = false;
            //Enable addrow and save method
            $scope.addRowbtn = true;
            $scope.saveRowbtn = true;

           if (indexInt == 3) {
                $scope.showSectionDropdown = false;
                $scope.showAddlinksDiv = false;

                //enable dropdown FAQ-Section
                $scope.showSectionDropdownFAQ = true;
                $scope.showAddlinksDivFAQ = true;
            } else {
                //disable dropdown FAQ-Section
                $scope.showSectionDropdownFAQ = false;
                $scope.showAddlinksDivFAQ = false;
                //enable dropdown normal-Section
                $scope.showSectionDropdown = true;
                $scope.showAddlinksDiv = true;

                $scope.secContentInternal = null;
                $scope.MenuIdInternal = $scope.menuOptionsInternal[indexInt].MenuId; //Assigning menuid to scope
                $scope.txtSectionInternal = false;

            }
        };
        
        // JSLinq used for section select change Internal user
        $scope.secChangeInternal = function (indexI, secIndexI, projectId) {

            if (secIndexI == 16) {
                $scope.showAddlinksDiv = false;
                $scope.showIntrContentDiv = true;

                var secFilterObjInternalInt = JSLINQ($scope.menuOptionsInternal[indexI].Contents)
                    .Where(function(section) { return section.SectionId == secIndexI; });

                $scope.secContentInternal = secFilterObjInternalInt.items[0].ContentDescription;
                $scope.textInternalCont = $scope.secContentInternal;

                $scope.contentIdInt = secFilterObjInternalInt.items[0].ContentId;
                $scope.contentTitleInt = secFilterObjInternalInt.items[0].ContentTitle;
                $scope.contentFooterInt = secFilterObjInternalInt.items[0].ContentFooter;
                $scope.contentProjId = projectId;
                $scope.sectionId = secIndexI;
                
            } else {

                $scope.showAddlinksDiv = true;
                $scope.showIntrContentDiv = false;

                //Enable addrow and save method
                $scope.addRowbtn = false;
                $scope.saveRowbtn = false;

                var secFilterObjInternal = JSLINQ($scope.menuOptionsInternal[indexI].Contents)
                    .Where(function(section) { return section.SectionId == secIndexI; });

                //Filter for Projects - section
                var secLinkInternalProj = JSLINQ(secFilterObjInternal.items[0].ListLinks)
                    .Where(function(project) { return project.ProjectId == projectId; });

                //Binding links to UI
                $scope.linkArrayRow = secLinkInternalProj.items;

                $scope.sectionId = secIndexI; //Assigning menuid to scope

                if (secFilterObjInternal != 'undifined')

                $scope.secContentInternal = secFilterObjInternal.items[0].ContentDescription;
                $scope.textInternalCont = $scope.secContentInternal;
                $scope.contentIdInt = secFilterObjInternal.items[0].ContentId;
                $scope.contentTitleInt = secFilterObjInternal.items[0].ContentTitle;
                $scope.contentFooterInt = secFilterObjInternal.items[0].ContentFooter;
                $scope.contentProjId = projectId;
                
            }

        };

        //Add link section
        $scope.flag = true;
        $scope.addRowbtn = true;
        $scope.saveRowbtn = true;
        $scope.showIntrContentDiv = false;

        //---------------------------------------------//
        //********************************************//
        //Internal User checkbox
        $scope.addLinkDiv = function () {
            if ($scope.flag == true)
                $scope.flag = false;
            else {
                $scope.flag = true;
            }
        };

      $scope.tdforAddLink = false;

    //Add row toadd link internal
        $scope.addProject = function (projId) {
            $scope.tdforAddLink = true;
            if (typeof $scope.linkDescription != 'undefined' && $scope.linkDescription != "" && $scope.link != "")
            {$scope.linkArrayRow.push({ "LinkDescription": $scope.linkDescription, "Link": $scope.link, "ProjectId": projId });}
            $scope.linkDescription = '';
            $scope.link = '';
         
        };
        //Add row toadd link internal
        $scope.savefinalProject = function (indexMenuI,secIndexInt, projectIdIn) {
            if (typeof secIndexInt != 'undefined' && secIndexInt != '') {
                //call add link function again...
                $scope.tdforAddLink = false;
                if (typeof $scope.linkDescription != 'undefined' && $scope.linkDescription != "" && $scope.link != "") {
                    $scope.linkArrayRow.push({ "LinkDescription": $scope.linkDescription, "Link": $scope.link, "ProjectId": projectIdIn });
                }
                $scope.linkDescription = '';
                $scope.link = '';


                $scope.secFilterObjInternalFinalArray.SectionId = secIndexInt;
                $scope.secFilterObjInternalFinalArray.SubMenuID = projectIdIn;
                $scope.secFilterObjInternalFinalArray.ContentId = $scope.contentIdInt;
                //keynotes CEO
                $scope.secFilterObjInternalFinalArray.ContentDescription = $scope.textInternalCont;
                $scope.secFilterObjInternalFinalArray.ContentTitle = $scope.contentTitleInt;
                $scope.secFilterObjInternalFinalArray.ContentFoot = $scope.contentFooterInt;
                $scope.secFilterObjInternalFinalArray.ListLinks = $scope.linkArrayRow;

                $http({
                    method: "POST",
                    url: 'api/PostSectionContentInternal/',
                    data: $scope.secFilterObjInternalFinalArray
                }).success(function(data) {
                    //Success
                    //Rebinding the link list to array after deleting
                    adminMenuServiceFact.getServices().
                        then(function(data) {
                            $scope.secFilterObjInternal = data.adminMenu;
                            var secFilterObjInternal1 = JSLINQ($scope.secFilterObjInternal)
                                .Where(function(menu) { return menu.MenuId > 5; });
                            $scope.menuOptionsInternal1 = secFilterObjInternal1.items;

                            var secFilterObjInternal = JSLINQ($scope.menuOptionsInternal1[indexMenuI].Contents)
                                .Where(function(section) { return section.SectionId == secIndexInt; });

                            //Filter for Projects - section
                            var secLinkInternalProj1 = JSLINQ(secFilterObjInternal.items[0].ListLinks)
                                .Where(function(project) { return project.ProjectId == projectIdIn; });

                            //Binding links to UI
                            $scope.linkArrayRow = secLinkInternalProj1.items;

                            if ($scope.showIntrContentDiv == true)
                                $scope.showAddlinksDiv = false;
                            else
                                $scope.showAddlinksDiv = true;
                        });
                    toastr.success("Internal user content saved successfully.");

                }).error(function(e) {
                    //Error
                    toastr.error("Error found.");
                });
            } else {
                toastr.warning("Please select Section before saving");
            }

        };

 //******************************************************//
//****************FAQ's section**********************//

        $scope.showSectionDropdown = true;
        $scope.showAddlinksDiv = true;

        // JSLinq used for section select change Internal user
        $scope.secChangeInternalFAQ = function (secIndexI, projectId) {

            //Enable addrow and save method
            $scope.addRowbtn = false;
            $scope.saveRowbtn = false;

            // Internal User Admin activities
            getFaqQuestionAnswerServiceFact.getServices(projectId).
              then(function (data) {
                  $scope.menuOptionsInternalFAQQuestAns = data.FaqQestAnswResult;

                  var secFilterObjInternalFAQ = JSLINQ($scope.menuOptionsInternalFAQQuestAns)
                 .Where(function (section) { return section.FaqSectionId == secIndexI; });

                  //Binding links to UI
                  $scope.linkArrayRowFAQs = secFilterObjInternalFAQ.items[0].FaqList;
                  $scope.showAddlinksDivFAQ = true;
                  //Add row toadd link internal
              });
        };

        $scope.tdforAddLinkFAQ = false;
        $scope.addProjectFAQ = function (projId,secId) {
            $scope.tdforAddLinkFAQ = true;
            if (typeof $scope.FaqQuestion != 'undefined' && $scope.FaqQuestion != "" && $scope.FaqAnswer != "")
                $scope.linkArrayRowFAQs.push({ "FaqQuestion": $scope.FaqQuestion, "FaqAnswer": $scope.FaqAnswer, "ProjectId": projId, "FaqSectionId": secId, "FaqId": 0 });
            $scope.FaqQuestion = '';
            $scope.FaqAnswer = '';

        };

        //FAQ Save Method
        //Add row toadd link internal
        $scope.savefinalProjectFAQ = function (secIndexIntFaq, projectIdIn) {

            $scope.tdforAddLinkFAQ = false;
            if (typeof $scope.FaqQuestion != 'undefined' && $scope.FaqQuestion != "" && $scope.FaqAnswer != "")
                $scope.linkArrayRowFAQs.push({ "FaqQuestion": $scope.FaqQuestion, "FaqAnswer": $scope.FaqAnswer, "ProjectId": projectIdIn, "FaqSectionId": secIndexIntFaq , "FaqId" :0});
            $scope.FaqQuestion = '';
            $scope.FaqAnswer = '';

            $scope.secFilterObjInternalFinalArrayFAQ.faqlist = $scope.linkArrayRowFAQs;

            $http({
                method: "POST",
                url: 'api/PostFaqDetails/',
                contentType: 'application/json; charset=utf-8',
                data: $scope.secFilterObjInternalFinalArrayFAQ.faqlist
            }).success(function (data) {
                //Success
                // Internal User Admin activities
                getFaqQuestionAnswerServiceFact.getServices(projectIdIn).
                  then(function (data) {
                      $scope.menuOptionsInternalFAQQuestAns = data.FaqQestAnswResult;

                      var secFilterObjInternalFaq = JSLINQ($scope.menuOptionsInternalFAQQuestAns)
                     .Where(function (section) { return section.FaqSectionId == secIndexIntFaq; });

                      //Binding links to UI
                      $scope.linkArrayRowFAQs = secFilterObjInternalFaq.items[0].FaqList;

                      $scope.showAddlinksDivFAQ = true;
                      //Add row toadd link internal
                  });
                toastr.success("Internal user FAQ content saved successfully.");
            }).error(function (e) {
                //Error
                toastr.error("Error found.");
            });

        };

        //Delete FAQ's ----------------------------------------------------------
        $scope.DeleteFAQ = function (index, projectId) {

            bootbox.confirm("Are you you want to delete?", function (result) {
            if (result) {
                // deleting from array
                var x = $scope.linkArrayRowFAQs[index];
                if (typeof x.FaqId == 'undefined') {
                    $scope.tdforAddLinkFAQ = false;
                    if (typeof $scope.FaqQuestion != 'undefined' && $scope.FaqQuestion != "" && $scope.FaqAnswer != "")
                        $scope.linkArrayRowFAQs.push({ "FaqQuestion": $scope.FaqQuestion, "FaqAnswer": $scope.FaqAnswer, "ProjectId": projectId });
                    $scope.FaqQuestion = '';
                    $scope.FaqAnswer = '';

                    $scope.linkArrayRowFAQs.splice(index);
                } else {
                    $scope.secIndexFAQ = x.FaqSectionId;

                    $http({
                        method: "POST",
                        url: 'api/PostFaqDelete/' + x.FaqId,
                        contentType: 'application/json; charset=utf-8',
                        data: ''
                    }).success(function (data) {
                        //Success
                        // Internal User Admin activities
                        getFaqQuestionAnswerServiceFact.getServices(projectId).
                            then(function (data) {
                                $scope.menuOptionsInternalFAQQuestAns = data.FaqQestAnswResult;

                                var secFilterObjInternalFaq = JSLINQ($scope.menuOptionsInternalFAQQuestAns)
                                    .Where(function (section) { return section.FaqSectionId == $scope.secIndexFAQ; });

                                //Binding links to UI
                                $scope.linkArrayRowFAQs = secFilterObjInternalFaq.items[0].FaqList;

                                $scope.showAddlinksDivFAQ = true;
                                toastr.success("FAQ Deleted");
                            });
                    }).error(function (e) {

                        //Error
                        toastr.error("Error found..");
                    });
                }
                }
            });
        };

      
//*******************************************************************************************************************//

        //Delete Link's ----------------------------------------------------------
        $scope.DeleteLink = function (index, indexMen, secIndexId, projectId) {

            bootbox.confirm("Are you sure you want to delete?", function (result) {
                if (result) {
                    // deleting from array
                    var x = $scope.linkArrayRow[index];
                    if (typeof x.LinkId == 'undefined') {
                        //call add link function again...
                        $scope.tdforAddLink = false;
                        if (typeof $scope.linkDescription != 'undefined' && $scope.linkDescription != "" && $scope.link != "")
                        { $scope.linkArrayRow.push({ "LinkDescription": $scope.linkDescription, "Link": $scope.link, "ProjectId": projectId }); }
                        $scope.linkDescription = '';
                        $scope.link = '';

                        $scope.linkArrayRow.splice(index);

                    } else {
                        $scope.secIndexFAQ = x.LinkId;

                        $http({
                            method: "POST",
                            url: 'api/PostLinkDelete/' + x.LinkId,
                            contentType: 'application/json; charset=utf-8',
                            data: ''
                        }).success(function (data) {
                            //Success
                            // External User Admin activities
                            //Rebinding the link list to array after deleting
                            adminMenuServiceFact.getServices().
                              then(function (data) {
                                  $scope.secFilterObjInternal = data.adminMenu;
                                  var secFilterObjInternal1 = JSLINQ($scope.secFilterObjInternal)
                                    .Where(function (menu) { return menu.MenuId > 5; });
                                  $scope.menuOptionsInternal1 = secFilterObjInternal1.items;

                                  var secFilterObjInternal = JSLINQ($scope.menuOptionsInternal1[indexMen].Contents)
                                      .Where(function (section) { return section.SectionId == secIndexId; });

                                  //Filter for Projects - section
                                  var secLinkInternalProj1 = JSLINQ(secFilterObjInternal.items[0].ListLinks)
                                     .Where(function (project) { return project.ProjectId == projectId; });

                                  //Binding links to UI
                                  $scope.linkArrayRow = secLinkInternalProj1.items;
                                  $scope.showAddlinksDiv = true;
                              });
                            toastr.success("Link Deleted");

                        }).error(function (e) {
                            //Error
                            toastr.error("Error found.");
                        });
                    }
                }
            });
        };
    }
]);