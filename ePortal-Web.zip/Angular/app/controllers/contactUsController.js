﻿dashboardApp.controller('ContactUsController', [
    '$scope', '$location', '$http', 'menuServiceFactory', function ($scope, $location, $http, menuServiceFact) {
        if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalContact') == -1)
            return;
        //Side menu toggling 
        var w = $('.side_menu').outerWidth();
        $('.off-canvas-overlay').hide();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');
        $scope.$parent.ePortalCustommenus = 'Contact Us';
        //Get menu details based on role and menuType
        menuServiceFact
           .getServices("EX", 5).
           then(function (data) {
               console.log(data);
           });

        var data = {
            locations: [
                { "MenuId": 1, "MenuDescription": "PB APAC", "Menuhref": "#tab_a" },
                { "MenuId": 2, "MenuDescription": "FX", "Menuhref": "#tab_b" },
                { "MenuId": 3, "MenuDescription": "TM", "Menuhref": "#tab_c" },
                { "MenuId": 4, "MenuDescription": "FID", "Menuhref": "#tab_d" }
            ]
        };

        $scope.menus = data.locations;
        console.log($scope.menus);

        if (typeof $scope.prodLine == 'undefined') $scope.prodLine = new Array();
        $scope.activeProjectIndex = 0;

       $scope.onClickTab = function (projectIndex) {
            $scope.activeProjectIndex = projectIndex;
            console.log(projectIndex);
       };

       $scope.addClass = function (index) {
           var index = index % 5;

           if (index == 0)
               return 'redback';
           else if (index == 1)
               return 'greenback';
           else if (index == 2)
               return 'blueback';
           else if (index == 3)
               return 'orangeback';
           else
               return 'pinkback';
       };

        var prodDetails = {
            "myOptions": [
                {
                   "rfc": "TRADE_FLOW_F2B_RM_GBL",
                    "inc": "TRADE_FLOW_F2B_RM_GBL",
                    "jira": "EM eTools",
                    "dl": "DD IT IB TT TM Environments"
                },
                {
                    "rfc": "TRADE_FLOW_TC5_GBL",
                    "inc": "TRADE_FLOW_F99H_RM_GBL",
                    "jira": "UNITY",
                    "dl": "DD IT IB TT TM Environments"
                },
                {
                   "rfc": "TRADE_FLOW_F2B_RM_GBL",
                    "inc": "TRADE_FLOW_F2B_RM_GBL",
                    "jira": "EM eTools",
                    "dl": "DD IT IB TT TM Environments"
                },
                {
                    "rfc": "TRADE_FLOW_TC5_GBL",
                    "inc": "TRADE_FLOW_F99H_RM_GBL",
                    "jira": "TJA",
                    "dl": "DD IT IB TT TM Environments"
                }
            ]
        };

        $scope.menuDescription = prodDetails;
        var i = 0;
        angular.forEach($scope.menuDescription.myOptions, function(val) {
            $scope.prodLine.push(val);
            i++;
        });
        
        $('#myTab a').click(function(e) {
            e.preventDefault();
            $(this).tab('show');
        });

        //tracker used in UI to check active project
        $scope.isActiveTab = function (index) {
            return index == $scope.activeProjectIndex;
        };

    }
]);



