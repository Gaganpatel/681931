dashboardApp.controller('ServicesPageController', [
        '$scope', '$location', '$state', 'menuServiceFactory', 'getAdminMenuServiceFactory', function ($scope, $location, $state, menuServiceFact, adminMenuServiceFact) {
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalServices') == -1)
                return;
            slideToggleAction();
            $scope.$parent.ePortalCustommenus = 'Services';
            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("EX", 2).
                then(function(data) {
                   console.log(data);
                });

            $("#owl-demo").owlCarousel({
                //navigation: true, // Show next and prev buttons
                singleItem: false,
                items: 7,
                itemsScaleUp: false,
                slideSpeed: 500,
                paginationSpeed: 500,
                rewindSpeed: 1000,
                autoPlay: true,
                stopOnHover: true,
                responsive: true,
                autoHeight: false,
                pagination: false,
                dragBeforeAnimFinish: true,
                mouseDrag: true,
                touchDrag: true,
            });

            var owl = $("#owl-demo").data('owlCarousel');

            $('.prev').on('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                owl.prev();
            });
            $('.next').on('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                owl.next();
            });

            // External User Admin activities Servise
            adminMenuServiceFact.getServices().
              then(function (data) {
                  $scope.secFilterObj = data.adminMenu;
                  var secFilterObj = JSLINQ($scope.secFilterObj)
                    .Where(function (menu) { return menu.MenuId == 2; });

                  $scope.servDescription = secFilterObj.items[0].Contents;
              });

            $scope.addClass = function(index) {
                var index = index % 5;
                if (index == 0)
                    return 'redback font';
                else if (index == 1)
                    return 'greenback';
                else if (index == 2)
                    return 'blueback';
                else if (index == 3)
                    return 'orangeback';
                else
                    return 'pinkback';
            };

            $scope.addRef = function(index) {
                if (index == 0)
                    $state.go("ssetupSer");
                else if (index == 1)
                    $state.go("scontrolSer");
                else if (index == 2)
                    $state.go("soperateSer");
                else
                    $state.go("saddonSer");
            };

            //Images our clients
            $scope.imageSource1 = 'Angular/img/PTG/Brady_Dougan.bmp';
            $scope.imageSource2 = 'Angular/img/PTG/Laura_Barrowman.bmp';
            $scope.imageSource3 = 'Angular/img/PTG/David_Mathers.bmp';

        }
    ])
    .controller('HeirarchyPageController', [
        '$scope', 'webKeyServiceFactory', 'menuServiceFactory', function($scope, webKeyServiceFac, menuServiceFact) {

            slideToggleAction();
            $scope.$parent.ePortalCustommenus = 'eTools';
            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("EX", 4).
                then(function(data) {
                    console.log(data);
                });

          /************** LightBox *********************/
            $(function() {
                $('[data-rel="lightbox"]').lightbox();
            });

            //get the services from the services factory
            webKeyServiceFac
                .getServices().
                then(function(data) {
                    $scope.eInvLink = data.links[0];
                    $scope.eAllocLink = data.links[1];
                    console.log(data);
                });

            //Open eInv link in other tab
            $scope.makeeInvUrl = function() {
                window.open($scope.eInvLink);
            };

            //Open eInv link in other tab
            $scope.makeeAlloc = function() {
                window.open($scope.eAllocLink);
            };

        }
    ])
    .controller('aboutUsController', [
        '$scope', 'menuServiceFactory', function($scope, menuServiceFact) {

            slideToggleAction();
            $scope.$parent.ePortalCustommenus = 'Meet the Team';
            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("EX", 3).
                then(function(data) {
                    console.log(data);
                });

            $("#org").jOrgChart({
                chartElement: '#chart',
                dragAndDrop: false
            });

            /************** LightBox *********************/
            $(function () {
                $('[data-rel="lightbox"]').lightbox();
            });

            /* Photos */
            $scope.imageSource6 = 'Angular/img/Client/amith.jpg';
            $scope.imageSource1 = 'Angular/img/Client/Antonio.png';
            $scope.imageSource2 = 'Angular/img/Client/abeeyLee.png';
            $scope.imageSource3 = 'Angular/img/Client/Seeman.png';
            $scope.imageSource4 = 'Angular/img/Client/SyedAbbas.png';
            $scope.imageSource5 = 'Angular/img/Client/Russ.png';
            $scope.imageSource7 = 'Angular/img/Client/thomas.png';
            $scope.imageSource8 = 'Angular/img/Client/Nina.png';

        }
    ])
    .controller('CrtlServiceDesign', [
        '$scope', function($scope) {
            $scope.page = '1';

            slideToggleAction();
        }
    ])
    .controller('CrtlServiceControl', [
        '$scope', function($scope) {
            $scope.page = '1';

            $scope.addClass = function() {
                alert('hi');
            };

            slideToggleAction();

        }
    ])
    .controller('CrtlServiceOperation', [
        '$scope', function($scope) {
            $scope.page = '1';

            slideToggleAction();
        }
    ])
    .controller('CrtlServiceOptimiz', [
        '$scope', function($scope) {
            $scope.page = '1';

            slideToggleAction();
        }
    ])
    .controller('CrtlServiceSpecial', [
        '$scope', function($scope) {
            $scope.page = '1';

            slideToggleAction();
        }
    ])
    .controller('WIPController', [
        '$scope', function ($scope) {
            $scope.$parent.ePortalCustommenus = '';
            slideToggleAction();
        }
    ])
   .controller('LayOutController', function ($scope, $location) {
       $scope.isActive = function (path) {

           slideToggleAction();

           var locationPath = $location.path().split('/')[$location.path().split('/').length - 1];
           var referencePath = path.split('/')[path.split('/').length - 1];

           var locPathContS = locationPath.charAt(0).toString();
           var refPathContS = referencePath.charAt(0).toString();

           if ((locPathContS=="s") && (refPathContS =="s")) {
               return $location.path();
           } else {
               return $location.path() === path;
           }
    };
   });

function slideToggleAction() {
    
    //Side menu toggling 
    var w = $('.side_menu').outerWidth();
    $('.off-canvas-overlay').hide();
    $('.side_menu').animate({
        left: '-' + w + 'px'
    }, 200).toggleClass('active');

}