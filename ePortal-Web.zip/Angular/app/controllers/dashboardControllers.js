﻿dashboardApp
    .controller('DashboardController', [
        '$scope', '$http', '$location', '$filter', 'menuServiceFactory', 'getPreferences', 'getRfcTicketByGroupServiceFactory', 'getJiraDataServiceFactory', 'getJiraDataServiceFactoryReporter', 'getIncDetailsServiceFactory', 'webKeyServiceExtFactory',
        function ($scope, $http, $location, $filter, menuServiceFact, getPreferences, getRfcTicketByGroupServiceFact, getJiraDataServiceFac, getJiraDataServiceFactoryReporter, getIncDetailsServiceFact, webKeyServiceExtFact) {
            //if ($rootScope.selectedPage == 'welcome')
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalDashboard') == -1)
                return;

            $scope.WorkList = {};
            $scope.getWorkList = new Array();
            $scope.WorkTypes = new Array();
            $scope.assignees = new Array();
            $scope.reporters = new Array();
            $scope.status = new Array();
            $scope.priorities = new Array();
            $scope.$parent.ePortalCustommenus = 'WorkList';
            var gridPreferences = "";

            webKeyServiceExtFact.getWebKey()
               .then(function (data) {
                   $scope.webKeys = data.AppKeyWebConfig;
               });


            getPreferences.getUserPreferences()
                .then(function (data) {
                   gridPreferences = data.preferences;

        });

            var x = 0;

            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

            //tabs menu 
            $('.tab_list > li').on('click', function () {
                $(this).parent().find('.active').removeClass('active')
                    .end().find(this).addClass('active');
                $('.tab_contents').find('.active').removeClass('active')
                    .end().find('.' + $(this).data('target')).addClass('active');
                $scope.charttype = $(this)[0].innerText;
                if ($scope.charttype.indexOf("JIRA") > -1 && (typeof ($scope.tablejiraitems) != 'undefined')) {
                    if ($scope.tablejiraitems.length != $scope.tblJIRADetail.total) {
                        //Loading icon -- spinner
                        $scope.dataLoaded = false;
                        getJiraDataServiceFac
                            .getServices(50, 1).
                            then(function (data) {
                                setJiraData($scope, data);
                                $scope.dataLoaded = true;
                            });
                    }
                }
            });

            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("IN", 6).
                then(function (data) {
                    console.log(data);

                    //pagination code starts here
                    //$scope.totalincitems = $scope.tableincitems.length;
                    //$scope.inccurrentPage = 1;
                    if (typeof (data.incData) == 'undefined')
                        //INC list empty
                        $scope.noINCList = true;

                    else if (data.incData.length == 0)
                        $scope.noINCList = true;
                    else {
                        $scope.tblINCData1 = data.incData;
                        var finalINCData = [];
                        $scope.noINCList = false;
                        finalINCData = JSLINQ($scope.tblINCData1).Select(function (item) { return item; })
                            .SelectMany(function (outRec) {

                                return {
                                    '_01_INC Number': outRec.numberField,
                                    '_02_Short Description': outRec.short_descriptionField,
                                    '_03_Requested By': outRec.caller_idnameField,
                                    '_04_Change State': outRec.stateField,
                                    '_05_Priority': outRec.priorityField,
                                    '_06_Approval': "",
                                    '_07_Assigned To': outRec.assigned_tonameField,
                                    '_08_Assignment Group': outRec.assignment_groupnameField,
                                    '_09_Start_Date': outRec.sys_created_onField,
                                    '_10_End_Date': outRec.sys_updated_onField,
                                    '_11_Requester Group': outRec.u_owning_groupnameField
                                };
                            });

                        $scope.tblINCData1 = finalINCData.items;
                        $scope.tableincitems = $scope.tblINCData1;
                        $scope.incconfig = tbcINCConfig;
                        $scope.inccurrentPage = 1;
                        $scope.tableincitems.displayactualdata = getINCDataAfterFilter($scope);
                    }



                });

            var isLoggedIn = 0;
            if ($scope.$parent.isLoggedIn) isLoggedIn = 1;
            var jiraResult = getJiraDataServiceFac
                .getServices(10);

            var jiraResultReporter = getJiraDataServiceFactoryReporter
                .getServices(10);


            var rfcResult = getRfcTicketByGroupServiceFact
                .getServices();

            var incResult = getIncDetailsServiceFact
                .getServices();


            //Loading icon -- spinner
            $scope.dataLoaded = false;

            //If RFC list is empty
            $scope.noRFCList = false;

            //DUmmy values
            $scope.closedRfcItems = 10;
            $scope.closedIncItems = 10;


            $scope.totalItems = 0;
            $scope.closedJiraItems = 0;

            $scope.totalincitems = 0;
            $scope.closedIncItems = 0;
            //Get menu details based on role and menuType
            jiraResult.then(function (data) {
                if (typeof (data.jiraDetails) == 'undefined')
                    //JIRA list empty
                    $scope.noINCList = true;
                else if (data.jiraDetails.total == 0) {
                    //JIRA list empty
                    $scope.noJIRAList = true;


                } else
                    setJiraData($scope, data);
                console.log('Jira');
            });

            jiraResultReporter.then(function (data) {
                if (typeof (data.jiraDetails) == 'undefined')
                    //JIRA list empty
                    $scope.noINCList = true;
                else if (data.jiraDetails.total == 0) {
                    //JIRA list empty
                    $scope.noJIRAList = true;


                } else
                    setJiraData($scope, data);
                console.log('Jira');
            });

            incResult.then(function (data) {


                if (typeof (data.incData) == 'undefined')
                    //INC list empty
                    $scope.noINCList = true;

                else if (data.incData.length == 0)
                    $scope.noINCList = true;
                else {
                    $scope.tblINCData1 = data.incData;
                    var finalINCData = [];
                    nM$scope.noINCList = false;

                    finalINCData = JSLINQ($scope.tblINCData1).Select(function (item) { return item; })
                        .SelectMany(function (outRec) {
                            //outRec.stateField = outRec.stateField.replace(1, 'Opened').replace(2, 'In Progress').replace(3, 'Pending').replace(4, 'Resolved').replace(5, 'Closed');
                            outRec.stateField = outRec.stateField.replace(1, 'New').replace(2, 'Acknowledged').replace(3, 'In Progress').replace(4, 'Pending').replace(5, 'Transferred').replace(6, 'Resolved').replace(7, 'Closed').replace(8, 'Cancelled');
                        outRec.priorityField = outRec.priorityField.replace(1, 'Critical').replace(2, 'High').replace(3, 'Medium').replace(4, 'Low').replace(5, '_').replace(6, '_');
                            return {
                                '_01_INC Number': outRec.numberField,
                                '_02_Short Description': outRec.short_descriptionField,
                                '_03_Requested By': outRec.caller_idnameField,
                                '_04_Change State': outRec.stateField,
                                '_05_Priority': outRec.priorityField,
                                '_06_Approval': "",
                                '_07_Assigned To': outRec.assigned_tonameField,
                                '_08_Assignment Group': outRec.assignment_groupnameField,
                                '_09_Start_Date': outRec.sys_created_onField,
                                '_10_End_Date': outRec.sys_updated_onField,
                                '_11_Requester Group': outRec.u_owning_groupnameField
                            };
                        });

                    $scope.tblINCData1 = finalINCData.items;
                    $scope.tableincitems = $scope.tblINCData1;
                    $scope.totalincitems = $scope.tableincitems.length;
                    $scope.incconfig = tbcINCConfig;
                    $scope.inccurrentPage = 1;
                    $scope.tableincitems.displayactualdata = getINCDataAfterFilter($scope);

                }

                console.log('INC');
            });

            //Get menu details based on role and menuType
            rfcResult.then(function (data) {
                $scope.tblRFCData1 = data.rfcData;

                if (data.rfcData.length == 0) {
                    //RFC list empty
                    $scope.noRFCList = true;

                }
                console.log('RFC');
                var finalRFCData = [];

                finalRFCData = JSLINQ($scope.tblRFCData1).Select(function (item) { return item; })
                    .SelectMany(function (item1) {


                        //format start and end dates
                        var from = item1.start_date.toString().split("T");
                        from = from[0].split("-");
                        var convertedStartDate = from[2] + "/" + from[1] + "/" + from[0];

                        var from1 = item1.end_date.toString().split("T");
                        from1 = from1[0].split("-");
                        var convertedEndDate = from1[2] + "/" + from1[1] + "/" + from1[0];

                        return {
                            '_01_RFC Number': item1.number,
                            '_02_Short Description': item1.short_description,
                            '_03_Requested By': item1.requested_by,
                            '_04_Change State': item1.u_change_state,
                            //'_05_priority': item1.priority,
                            '_06_Approval': item1.approval,
                            '_07_Assigned To': item1.assigned_to,
                            '_08_Assignment Group': item1.assignment_group,
                            '_09_Start_Date': convertedStartDate,
                            '_10_End_Date': convertedEndDate,
                            '_11_Requester Group': item1.u_requester_group
                        };
                    });

                $scope.tblRFCData1 = finalRFCData.items;
                $scope.tablerfcitems = $scope.tblRFCData1;
                $scope.rfcconfig = tbcRFCConfig;

                //pagination code starts here
                $scope.totalrfcitems = $scope.tablerfcitems.length;
                $scope.rfccurrentPage = 1;
                $scope.tablerfcitems.displayactualdata = getRFCDataAfterFilter($scope);
            });

            //Date based on month for RFC graph end
            $scope.oneAtATime = true;
            $scope.tableType = 'unseen';

            //As of now hide the div for INC
            $scope.hideIncDiv = false;

            $scope.pageChanged = function (pageno) {
                $scope.currentPage = pageno;
                $scope.tablejiraitems.displayactualdata = getDataAfterFilter($scope);
            };

            $scope.pageINCChanged = function (incpageno) {
                $scope.inccurrentPage = incpageno;
                $scope.tableincitems.displayactualdata = getINCDataAfterFilter($scope);
            };

            $scope.pagerfcChanged = function (incpageno) {
                $scope.rfccurrentPage = incpageno;
                $scope.tablerfcitems.displayactualdata = getRFCDataAfterFilter($scope);
            };

            $scope.sort = {
                column: '_01_key',
                descending: false
            };

            $scope.selectedCls = function (column) {
                return column == $scope.sort.column && 'sort-' + $scope.sort.descending;
            };

            $scope.changeSorting = function (column) {
                var sort = $scope.sort;
                if (sort.column == column) {
                    sort.descending = !sort.descending;
                } else {
                    sort.column = column;
                    sort.descending = false;
                }

                var jiradata = $scope.tablejiraitems;
                var data = '';
                if (sort.descending) {
                    data = JSLINQ(jiradata)
                        .OrderByDescending(function (jData) {

                            if (sort.column == '_01_key') {

                                return jData._01_key;
                            }
                            if (sort.column == '_02_summary') {

                                return jData._02_summary;
                            }
                            if (sort.column == '_03_status') {

                                return jData._03_status;
                            }
                            if (sort.column == '_04_priority') {

                                return jData._04_priority;
                            }
                            if (sort.column == '_05_issuetype') {

                                return jData._05_issuetype;
                            }
                            if (sort.column == '_06_reporter') {

                                return jData._06_reporter;
                            }
                        });
                } else {
                    data = JSLINQ(jiradata)
                        .OrderBy(function (jData) {

                            if (sort.column == '_01_key') {

                                return jData._01_key;
                            }
                            if (sort.column == '_02_summary') {

                                return jData._02_summary;
                            }
                            if (sort.column == '_03_status') {

                                return jData._03_status;
                            }
                            if (sort.column == '_04_priority') {

                                return jData._04_priority;
                            }
                            if (sort.column == '_05_issuetype') {

                                return jData._05_issuetype;
                            }
                            if (sort.column == '_06_reporter') {

                                return jData._06_reporter;
                            }

                        });
                }

                $scope.tablejiraitems = data.items;
                $scope.tablejiraitems.displayactualdata = getDataAfterFilter($scope);

            };


            //Load charts
            loadTagCloud1();
            loadGrid();
            function loadGrid() {
                angular.element(document).ready(function () {
                    $("#grid").kendoGrid({
                        toolbar: [{ name: "excel" }, { name: "pdf" }],
                        excel: {
                            fileName: "WorkList.xlsx",
                            allPages: true,
                            title: "Export to Excel"
                        },
                        pdf: {
                            fileName: "WorkList.pdf",
                            allPages: true,
                            title: "Export to PDF",
                        },
                        dataSource: {
                            type: "json",
                            data: $scope.getWorkList,
                            schema: {
                                model: {
                                    fields: {
                                        WorkType: { type: "string" },
                                        ID: { type: "string" },
                                        DueDate: { type: "date" },
                                        AssignedTo: { type: "string" },
                                        RaisedBy: { type: "string" },
                                        Status: { type: "string" },
                                        Criticality: { type: "string" },
                                    }
                                }
                            },
                            pageSize: 15
                        },
                        height: 700,
                        sortable: true,
                        reorderable: true,
                        columnReorder: function (e) { saveGridState(); },
                        resizable: true,
                        pageable: true,
                        filterable: true,
                        columns: (gridPreferences != "") ? JSON.parse(gridPreferences) : [
                            {
                                field: "WorkType",
                                title: "Work Type",
                                filterable: {
                                    ui: workTypeFilter
                                }
                            },
                            {
                                field: "ID",
                                title: "ID",
                                template: "#if(ID.indexOf('EMTLS') != -1){#<a href='" + $scope.jiraURL + "#=ID#' target='_blank'>#=ID#</a>#} else if(ID.indexOf('RFC') != -1){#<a href='" + $scope.rfcURL + "' target='_blank'>#=ID#</a>#} else if(ID.indexOf('INC') != -1){#<a href='" + $scope.incURL + "#=ID#' target='_blank'>#=ID#</a>#}#"
                            },
                            {
                                field: "DueDate",
                                title: "Due Date",
                                format: "{0:MM/dd/yyyy}",
                                filterable: {
                                    ui: "datepicker"
                                }
                            },
                            {
                                field: "AssignedTo",
                                title: "Assigned To",
                                filterable: {
                                    ui: assigneeFilter
                                }
                            },
                            {
                                field: "RaisedBy",
                                title: "Raised By",
                                filterable: {
                                    ui: reporterFilter
                                }
                            },
                            {
                                field: "Status",
                                title: "Status",
                                filterable: {
                                    ui: statusFilter
                                }
                            },
                            {
                                field: "Criticality",
                                title: "Criticality",
                                filterable: {
                                    ui: priorityFilter
                                }
                            }


                        ]

                    });
                });


                function saveGridState() {
                        $scope.GridState = { GdState: kendo.stringify($("#grid").data("kendoGrid").columns) };
                        $http({
                            method: "POST",
                            url: 'api/UpdateGridState/',
                            data: JSON.stringify($scope.GridState)
                        }).success(function (data) {
                                $scope.successFlag = 1;
                        }).error(function (e) {
                            $scope.successFlag = 0;
                        });

                }

                function workTypeFilter(element) {
                    element.kendoDropDownList({
                        dataSource: $scope.WorkTypes,
                        optionLabel: "--Select Value--"
                    });
                }

                function assigneeFilter(element) {
                    element.kendoDropDownList({
                        dataSource: $scope.assignees,
                        optionLabel: "--Select Value--"
                    });
                }

                function reporterFilter(element) {
                    element.kendoDropDownList({
                        dataSource: $scope.reporters,
                        optionLabel: "--Select Value--"
                    });
                }

                function statusFilter(element) {
                    element.kendoDropDownList({
                        dataSource: $scope.status,
                        optionLabel: "--Select Value--"
                    });
                }

                function priorityFilter(element) {
                    element.kendoDropDownList({
                        dataSource: $scope.priorities,
                        optionLabel: "--Select Value--"
                    });
                }

            }
            $scope.loadingTxt = "Jira items";
            $scope.noteFlag = false;

            jiraResult.then(function (data1) {

                console.log('Jira done');

                jiraResultReporter.then(function (data2) {
                    $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'DueDate');
                    $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'Status', true);

                    function onlyUnique(value, index, self) {
                        return self.indexOf(value) === index;
                    }

                    $scope.WorkTypes = $scope.WorkTypes.filter(onlyUnique);
                    $scope.assignees = $scope.assignees.filter(onlyUnique);
                    $scope.reporters = $scope.reporters.filter(onlyUnique);
                    $scope.status = $scope.status.filter(onlyUnique);
                    $scope.priorities = $scope.priorities.filter(onlyUnique);
              

                    $scope.jiraURL = $scope.webKeys[3];
                    $scope.rfcURL = $scope.webKeys[4];
                    $scope.incURL = $scope.webKeys[5];

                    loadGrid();

                    console.log('Jira Reporter done');
                    $scope.loadingTxt = "INC items";
                    incResult.then(function (dataInc) {
                        console.log('Inc done');
                        var t = 'Inc';
                        if (!$scope.noINCList) {
                            for (var i = 0; i < $scope.tableincitems.displayactualdata.length; i++) {
                                $scope.WorkList.WorkType = "Incident";
                                $scope.WorkList.ID = $scope.tableincitems.displayactualdata[i]["_01_INC Number"];
                                $scope.WorkList.DueDate = $scope.tableincitems.displayactualdata[i]["_10_End_Date"];
                                $scope.WorkList.RaisedBy = $scope.tableincitems.displayactualdata[i]["_03_Requested By"];
                                $scope.WorkList.AssignedTo = $scope.tableincitems.displayactualdata[i]["_07_Assigned To"];
                                $scope.WorkList.Status = $scope.tableincitems.displayactualdata[i]["_04_Change State"];
                                $scope.WorkList.Criticality = $scope.tableincitems.displayactualdata[i]["_05_Priority"];


                                $scope.getWorkList.push($scope.WorkList);
                                $scope.WorkTypes.push($scope.WorkList.WorkType);
                                $scope.assignees.push($scope.WorkList.AssignedTo);
                                $scope.reporters.push($scope.WorkList.RaisedBy);
                                $scope.status.push($scope.WorkList.Status);
                                $scope.priorities.push($scope.WorkList.Criticality);
                                $scope.WorkList = {};

                            }
                            $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'DueDate', true);
                            $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'Status', true);

                      
                            $scope.WorkTypes = $scope.WorkTypes.filter(onlyUnique);
                            $scope.assignees = $scope.assignees.filter(onlyUnique);
                            $scope.reporters = $scope.reporters.filter(onlyUnique);
                            $scope.status = $scope.status.filter(onlyUnique);
                            $scope.priorities = $scope.priorities.filter(onlyUnique);
                       


                            $('#grid').data().kendoGrid.destroy();
                            $('#grid').empty();
                            loadGrid();


                        }
                        $scope.loadingTxt = "RFC items";
                        rfcResult.then(function (data) {
                            console.log('rfc done');

                            $scope.tblRFCData1 = data.rfcData;

                            if (data.rfcData.length == 0) {
                                //RFC list empty
                                $scope.noRFCList = true;
                            }
                            console.log('RFC');
                            var finalRFCData = [];

                            finalRFCData = JSLINQ($scope.tblRFCData1).Select(function (item) { return item; })
                                .SelectMany(function (item1) {

                                    //format start and end dates
                                    var from = item1.start_date.toString().split("T");
                                    from = from[0].split("-");
                                    var convertedStartDate = from[2] + "/" + from[1] + "/" + from[0];

                                    var from1 = item1.end_date.toString().split("T");
                                    from1 = from1[0].split("-");
                                    var convertedEndDate = from1[2] + "/" + from1[1] + "/" + from1[0];

                                    return {
                                        '_01_RFC Number': item1.number,
                                        '_02_Short Description': item1.short_description,
                                        '_03_Requested By': item1.requested_by,
                                        '_04_Change State': item1.u_change_state,
                                        //'_05_priority': item1.priority,
                                        '_06_Approval': item1.approval,
                                        '_07_Assigned To': item1.assigned_to,
                                        '_08_Assignment Group': item1.assignment_group,
                                        '_09_Start_Date': convertedStartDate,
                                        '_10_End_Date': convertedEndDate,
                                        '_11_Requester Group': item1.u_requester_group
                                    };
                                });

                            $scope.tblRFCData1 = finalRFCData.items;
                            $scope.tablerfcitems = $scope.tblRFCData1;
                            $scope.rfcconfig = tbcRFCConfig;
                            $scope.totalrfcitems = $scope.tablerfcitems.length;
                            $scope.rfccurrentPage = 1;
                            $scope.tablerfcitems.displayactualdata = getRFCDataAfterFilter($scope);

                            for (var i = 0; i < $scope.tablerfcitems.displayactualdata.length; i++) {
                                $scope.WorkList.WorkType = "Change";
                                $scope.WorkList.ID = $scope.tablerfcitems.displayactualdata[i]["_01_RFC Number"];
                                $scope.WorkList.DueDate = $scope.tablerfcitems.displayactualdata[i]["_10_End_Date"];
                                $scope.WorkList.RaisedBy = $scope.tablerfcitems.displayactualdata[i]["_03_Requested By"];
                                $scope.WorkList.AssignedTo = $scope.tablerfcitems.displayactualdata[i]["_07_Assigned To"];
                                $scope.WorkList.Status = $scope.tablerfcitems.displayactualdata[i]["_06_Approval"];
                                $scope.WorkList.Criticality = "Not Available";


                                $scope.getWorkList.push($scope.WorkList);
                                $scope.WorkTypes.push($scope.WorkList.WorkType);
                                $scope.assignees.push($scope.WorkList.AssignedTo);
                                $scope.reporters.push($scope.WorkList.RaisedBy);
                                $scope.status.push($scope.WorkList.Status);
                                $scope.priorities.push($scope.WorkList.Criticality);
                                $scope.WorkList = {};

                            }

                            $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'DueDate');
                            $scope.getWorkList = $filter('orderBy')($scope.getWorkList, 'Status', true);

                      
                            $scope.WorkTypes = $scope.WorkTypes.filter(onlyUnique);
                            $scope.assignees = $scope.assignees.filter(onlyUnique);
                            $scope.reporters = $scope.reporters.filter(onlyUnique);
                            $scope.status = $scope.status.filter(onlyUnique);
                            $scope.priorities = $scope.priorities.filter(onlyUnique);
                      

                            $('#grid').data().kendoGrid.destroy();
                            $('#grid').empty();
                            loadGrid();

                            if ($scope.totalrfcitems == 0 || $scope.totalItems == 0 || $scope.totalincitems == 0) {
                                $scope.noteFlag = true;
                            }

                            $scope.dataLoaded = true;
                        });
                    });
                });

            });
        }
    ])
    .controller('tagCloudController', [
        '$scope', function ($scope) {
            loadTagCloud1();
        }
    ])
    .controller('toggleSideMenuButton', [
        '$scope', function ($scope) {
            $scope.ProgramDashboardDiv = false;
            toggleSideMenu();
        }
    ])
    .controller('ClientController', [
        '$scope', function ($scope) {
            $scope.$parent.ePortalCustommenus = 'Our Clients';
            $('#myTab a').click(function (e) {
                e.preventDefault();
                $(this).tab('show');
            });

            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

        }
    ])
     .controller('OrgHirerchyController', [
        '$scope', function ($scope) {
            $scope.$parent.ePortalCustommenus = 'Organizational Heirarchy';
            $('#myTab a').click(function (e) {
                e.preventDefault();
                $(this).tab('show');
            });

            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

            $("#org").jOrgChart({
                chartElement: '#chart',
                dragAndDrop: false
            });

        }
     ])
    .controller('LegalEntityController', [
        '$scope', '$rootScope', 'getHealthCheckSummaryServiceFactory', 'PostHealthCheckSummaryServiceFactory', function ($scope, $rootScope, getHealthCheckSummaryServiceFact, PostHealthCheckSummaryServiceFact) {
            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

            $scope.$parent.ePortalCustommenus = 'Program Dashboards > Legal Entity';
            getHealthCheckSummaryServiceFact.getServices().
                then(function (data) {
                    console.log(data);


                    var healthCheckBullets = data.healthCheckSummary[0].HealthCheckDetails.split('\n');
                    $scope.healthCheckSummary = data.healthCheckSummary[0];
                    $scope.healthCheckSummary.healthCheckList = healthCheckBullets;


                });

            $scope.SaveHealthCheckSummary = function (healthCheckSummary) {
                var t = 'healthCheckSummary';


                //  ValidateBeforeSave($scope, incident);
                // if (incident.ValidIncident) {
                PostHealthCheckSummaryServiceFact.getServices(healthCheckSummary).
                    then(function (data) {
                        console.log(data);
                        var healthCheckBullets = data.healthCheckSummary[0].HealthCheckDetails.split('\n');
                        $scope.healthCheckSummary = data.healthCheckSummary[0];
                        $scope.healthCheckSummary.healthCheckList = healthCheckBullets;
                    });
            };
        }
    ]);




function toggleSideMenu() {
    //Navigation Menu
    $('.toggle-button').on('click', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var w = $('.side_menu').outerWidth();
        var action = $('.side_menu').hasClass('active');
        if (action) {
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

        } else {
            $('.side_menu').animate({
                left: 0
            }, 400).toggleClass('active');
            $('.off-canvas-overlay').show();
        }
    });

    $('.off-canvas-overlay').on('click', function (e) {
        e.stopPropagation();
        e.preventDefault();
        $('.off-canvas-overlay').hide();
        var w = $('.side_menu').outerWidth();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');
    });
}


function loadTagCloud1() {
    if (!$('#myCanvas').tagcanvas({
        textFont: 'Impact,"Arial Black",sans-serif',
        textColour: null,
        textHeight: 22,
        outlineColour: 'black',
        reverse: true,
        depth: 0.8,
        maxSpeed: 0.05
    })) {
        // TagCanvas failed to load
        $('#myCanvasContainer').hide();
    }
}

function opendashboard() {
    $.ajax({
        url: "/Home/InternalHome/",
        success: function () {
            $('.off-canvas-overlay').click();
        }
    });
}

function getRFCDataAfterFilter($scope) {
    $scope.tablerfcitems.displayactualdata = new Array();
    var actualIndex = 0;
    var startIndex = ($scope.rfccurrentPage - 1) * 9;
    for (var x = startIndex; x < $scope.tablerfcitems.length; x++) {
        $scope.tablerfcitems.displayactualdata.push($scope.tablerfcitems[x]);
        actualIndex++;
        //if (actualIndex == 9) break;
    }
    return $scope.tablerfcitems.displayactualdata;
}

function getINCDataAfterFilter($scope) {
    $scope.tableincitems.displayactualdata = new Array();
    var actualIndex = 0;
    var startIndex = ($scope.inccurrentPage - 1) * 10;
    for (var x = startIndex; x < $scope.tableincitems.length; x++) {
        $scope.tableincitems.displayactualdata.push($scope.tableincitems[x]);
        actualIndex++;
        if (actualIndex == 10) break;
    }
    return $scope.tableincitems.displayactualdata;
}

function getDataAfterFilter($scope) {
    $scope.tablejiraitems.displayactualdata = new Array();
    var actualIndex = 0;
    var startIndex = ($scope.currentPage - 1) * 10;

    for (var x = startIndex; x < $scope.tablejiraitems.length; x++) {
        $scope.tablejiraitems.displayactualdata.push($scope.tablejiraitems[x]);
        actualIndex++;
        if (actualIndex == 10) break;
    }
    return $scope.tablejiraitems.displayactualdata;
}

function setJiraData($scope, data) {
    $scope.tblJIRADetail = data.jiraDetails;
    var finalJirAdata = [];
    finalJirAdata = JSLINQ($scope.tblJIRADetail.issues).Select(function (item) { return item; })
        .SelectMany(function (item1) {

            return { '_02_summary': item1.fields.summary, '_01_key': item1.key, '_03_status': item1.fields.status.name, '_04_priority': item1.fields.priority.name, '_05_issuetype': item1.fields.issuetype.name, '_06_reporter': item1.fields.reporter.displayName, '_07_assignee': item1.fields.assignee.displayName, '_08_duedate': item1.fields.duedate };
        });

    $scope.tablejiraitems = finalJirAdata.items;
    $scope.config = tbcConfig;
    //count of closed items chart
    $scope.closedJiraItems = JSLINQ($scope.tblJIRADetail.issues)
                          .Where(function (item) { return item.fields.status.name == 'Closed' || item.fields.status.name == 'Resolved'; })
                          .Count();
    //pagination code starts here
    $scope.totalItems = $scope.tblJIRADetail.total;
    $scope.currentPage = 1;
    $scope.tablejiraitems.displayactualdata = getDataAfterFilter($scope);



    for (var i = 0; i < $scope.tablejiraitems.displayactualdata.length; i++) {
        $scope.WorkList.WorkType = "Task";
        $scope.WorkList.ID = $scope.tablejiraitems.displayactualdata[i]._01_key;
        if ($scope.tablejiraitems.displayactualdata[i]._08_duedate == null) {
            $scope.WorkList.DueDate = "Not Set";
        } else {
            var start = new Date($scope.tablejiraitems.displayactualdata[i]._08_duedate);
            $scope.WorkList.DueDate = start;
        }
        $scope.WorkList.RaisedBy = $scope.tablejiraitems.displayactualdata[i]._06_reporter;
        $scope.WorkList.AssignedTo = $scope.tablejiraitems.displayactualdata[i]._07_assignee;
        $scope.WorkList.Status = $scope.tablejiraitems.displayactualdata[i]._03_status;
        $scope.WorkList.Criticality = $scope.tablejiraitems.displayactualdata[i]._04_priority;
        if (i % 2 == 0) {
            $scope.WorkList.Handover = "New";

        } else {
            $scope.WorkList.Handover = "Yes";
        }
        $scope.getWorkList.push($scope.WorkList);
        $scope.WorkTypes.push($scope.WorkList.WorkType);
        $scope.assignees.push($scope.WorkList.AssignedTo);
        $scope.reporters.push($scope.WorkList.RaisedBy);
        $scope.status.push($scope.WorkList.Status);
        $scope.priorities.push($scope.WorkList.Criticality);
        $scope.WorkList = {};
    }

}

tblData = [
          { "_01_key": "EMTLS-432", "_02_summary": "Cost Validation Report", "_04_issuetype": "Enhancement", "_03_status": "In Progress", "_05_reporter": "Kate Pilcher" },
          { "_01_key": "EMTLS-64", "_02_summary": "Include JIRA Stats/Data to the report for all departments", "_04_issuetype": "Task", "_03_status": "Open", "_05_reporter": "Kate Pilcher" },
          { "_01_key": "EMTLS-134", "_02_summary": "When the HTML for the reports is sent to email the bottom is cut off", "_04_issuetype": "Bug", "_03_status": "Open", "Reporter": "Nina Middleweek" },
          { "_01_key": "EMTLS-99", "_02_summary": "Fix eIS so costs are zero when data is no longer in CT reports.", "_04_issuetype": "BOW", "_03_status": "Open", "Reporter": "Nina Middleweek" },
          { "_01_key": "EMTLS-93", "_02_summary": "Perform weekly CATI sync", "_04_issuetype": "BOW", "_03_status": "Open", "Reporter": "Nina Middleweek" },
          { "_01_key": "EMTLS-63", "_02_summary": "Advanced add FX reports", "_04_issuetype": "BOW", "_03_status": "Open", "Reporter": "Mike Qineng Ding" },
          { "_01_key": "EMTLS-60", "_02_summary": "Add reports for FID", "_04_issuetype": "BOW", "_03_status": "Open", "Reporter": "Mike Qineng Ding" }
];

tbcConfig = {
    sortable: false,
    editable: {
        "_01_key": {
            "type": "link",
            "linkUrl": "https://unity.apps.csintra.net/jira/i#browse/"
        },
        "_02_summary": false,
        "_03_status": false,
        "_04_priority": false,
        "_05_issuetype": false,
        "_06_reporter": false,
    }
};

tbcINCConfig = {
    sortable: true,
    editable: {
        "_01_INC Number": false,
        "_02_Short Description": false,
        "_03_Requested By": false,
        "_04_Change State": false,
        "_05_Priority": false,
        "_06_Approval": false,
        "_07_Assigned To": false,
        "_08_Assignment Group": false,
        "_09_Start_Date": false,
        "_10_End_Date": false,
        "_11_Requester__Group": false
    }

};

var tblRFCData = [
    { "short_description": "Please install Oracle client 11.2.0.3", "description": "Please install Oracle client 11.2.0.3 in /app/isolv/oracle_11_2_0_3/ directory on NYS06A-0064", "cmdb_ci": "", "requested_by": "M758787", "u_change_state": "Closed", "u_work_activity": "Software Install", "u_impacted_region": "", "approval": "Approved", "assigned_to": "M758787", "assignment_group": "DERIV_IT_MONITOR_GBL", "sys_created_on": "2014-05-07T14:50:48Z", "start_date": "2014-05-07T14:49:24Z", "end_date": "2014-05-11T22:59:35Z", "priority": "(7)", "u_requester_group": "DERIV_IT_MONITOR_GBL", "number": "RFC0140735" },
    { "short_description": "Please install gcc compiler at server vlnl43a-5101.eu.hedani.net.\r\nThanks", "description": "Please install gcc compiler @ vlnl43a-5101.eu.hedani.net.\r\nThanks", "cmdb_ci": "", "requested_by": "G919351", "u_change_state": "Closed", "u_work_activity": "Software Install", "u_impacted_region": "", "approval": "cancelled", "assigned_to": "G919351", "assignment_group": "DERIV_IT_MONITOR_GBL", "sys_created_on": "2014-01-07T05:39:05Z", "start_date": "2014-01-10T05:40:22Z", "end_date": "2014-01-24T05:40:25Z", "priority": "(4)", "u_requester_group": "DERIV_IT_MONITOR_GBL", "number": "RFC0035188" },
    { "short_description": "Please copy all tables and indexes owned by users FORMULA and PTG_AEB from PLN05300 to QLN05300.", "description": "Please copy all tables and indexes owned by users FORMULA and PTG_AEB from PLN05300 to QLN05300.", "cmdb_ci": "1009150578", "requested_by": "M758787", "u_change_state": "Closed", "u_work_activity": "Clone", "u_impacted_region": "", "approval": "Approved", "assigned_to": "M758787", "assignment_group": "DERIV_IT_MONITOR_GBL", "sys_created_on": "2014-02-04T17:57:06Z", "start_date": "2014-02-09T00:00:00Z", "end_date": "2014-02-15T23:59:00Z", "priority": "(7)", "u_requester_group": "DERIV_IT_MONITOR_GBL", "number": "RFC0065384" },
    { "short_description": "Bring DB DITMO_Dev GPRI12D11005\\DNYEQDRV01\\ ", "description": "Bring DB DITMO_Dev GPRI12D11005\\DNYEQDRV01\\ ", "cmdb_ci": "ICTO-12209", "requested_by": "M702331", "u_change_state": "Closed", "u_work_activity": "Cluster Configuration", "u_impacted_region": "", "approval": "cancelled", "assigned_to": "M702331", "assignment_group": "DERIV_IT_MONITOR_GBL", "sys_created_on": "2014-06-12T08:30:57Z", "start_date": "2014-06-12T08:30:36Z", "end_date": "2014-06-13T08:30:40Z", "priority": "(7)", "u_requester_group": "DERIV_IT_MONITOR_GBL", "number": "RFC0165705" },
    { "short_description": "Please decom the DSGSHR02 database ", "description": "Please decom the DSGSHR02 database ", "cmdb_ci": "1009148428", "requested_by": "M758787", "u_change_state": "Closed", "u_work_activity": "Decommission", "u_impacted_region": "", "approval": "Approved", "assigned_to": "M758787", "assignment_group": "DERIV_IT_MONITOR_GBL", "sys_created_on": "2014-01-03T14:09:08Z", "start_date": "2014-01-20T09:08:14Z", "end_date": "2014-02-28T17:08:26Z", "priority": "(4)", "u_requester_group": "DERIV_IT_MONITOR_GBL", "number": "RFC0034366" }
];

angular.forEach(tblRFCData, function (val) {
    delete val.description;
    delete val.cmdb_ci;
    delete val.u_work_activity;
    delete val.u_impacted_region;
    delete val.sys_created_on;
});

tbcRFCConfig = {
    sortable: false,
    editable: {
        "_01_RFC Number": {
            "type": "link",
            "linkUrl": "http://cssnow.service-now.com/navpage.do"
        },
        "_02_Short Description": false,
        "_03_Requested By": false,
        "_04_Change State": false,
        //"_05_priority": false,
        "_06_Approval": false,
        "_07_Assigned To": false,
        "_08_Assignment Group": false,
        "_09_Start_Date": false,
        "_10_End_Date": false,
        "_11_Requester Group": false
    }
};

function GetMonthName(monthNumber) {
    var months = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
    return months[monthNumber - 1];
}

