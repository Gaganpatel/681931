﻿dashboardApp
    .controller('helpController', [
        '$scope', '$location', 'getFaqQuestionAnswerServiceFactory', 'getProjServiceFactory',  function ($scope, $location, faqQuestionAnswerServiceFact, getProjServiceFact) {
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalHelp') == -1)
                return;
            $scope.$parent.ePortalCustommenus = 'Help';
            // Assigning BreadCrums
            $scope.$parent.ePortalCustommenus = new Array();
            $scope.$parent.ePortalCustommenus.push('Help');

            $scope.oneAtATime = true;
            $scope.projId = 1;

        faqQuestionAnswerServiceFact
          .getServices($scope.projId)   
          .then(function (data) {
              $scope.faqslist = data.FaqQestAnswResult;
          });

            //Get projects from DB
            getProjServiceFact
               .getServices().
               then(function (data) {
                   $scope.projects = data.proj;
               });

        $scope.getFaqList = function(prjid) {
            faqQuestionAnswerServiceFact
            .getServices(prjid)
            .then(function (data) {
                $scope.faqslist = data.FaqQestAnswResult;
                $scope.answerShowDiv = false;
            });
        };

        var w = $('.side_menu').outerWidth();
        $('.off-canvas-overlay').hide();
        $('.side_menu').animate({
            left: '-' + w + 'px'
        }, 200).toggleClass('active');

        $scope.showFAQs = function () {
            $('#FAQaccordion').css('display', 'block');
        };

        $('#myTab a').click(function (e) {
            e.preventDefault();
            $(this).tab('show');
        });

            //Shw respective answer
        $scope.answerShowDiv = true;
            //Open first accordian
            $scope.faqAccordianfirst = true;

            //Show answers based on question selected...
        $scope.shwAnswer = function (index) {
            $scope.FaqAnswer = $scope.faqslist[0].FaqList[index].FaqAnswer;
            $scope.answerShowDiv = true;
        };
        }
    ])
    .controller('internalLayoutController', [
        '$scope', 'menuServiceFactory', 'getAdminMenuServiceFactory', function ($scope, menuServiceFact, adminMenuServiceFact) {

            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("IN", 9).
                then(function (data) {
                    console.log(data);
                });

            // External User Admin activities -- Key Notes 
            adminMenuServiceFact.getServices().
              then(function (data) {
                  $scope.secFilterObj = data.adminMenu;
                  var secFilterObj = JSLINQ($scope.secFilterObj)
                    .Where(function (menu) { return menu.MenuId == 6; });

                  var secFilterObj1 = JSLINQ(secFilterObj.items[0].Contents)
                    .Where(function (section) { return section.SectionId == 16; });

                  $scope.CEOContentDetails = secFilterObj1.items[0].ContentDescription;
            });
        }
    ])

    //Image service
    .controller('sideMenuController', [
       '$scope', '$rootScope', 'getEmpPidServiceFactory', 'menuIsExternalServiceFactory', 'menuIsAdminServiceFactory', function ($scope, $rootScope, getEmpPidServiceFact, getMenuIsExternalServiceFact, getMenuIsAdminServiceFact) {
            $scope.ProgramDashboardDiv = false;
           var action = $('.side_sub_menu').hasClass('active');
           if (action) {
               var w = $('.side_sub_menu').outerWidth();
               $('.off-canvas-overlay').hide();
               $('.side_sub_menu').animate({
                   left: '-' + w + 'px'
               }, 200).toggleClass('active');
           }

                getMenuIsExternalServiceFact
                    .getServices().
                    then(function (data) {
                        $rootScope.isExternal = data.isExternal;
                        if (data.isExternal)
                            $scope.menuSidebar = menuSideExternalbar;
                        else
                            $scope.menuSidebar = menuSidebar;

                        if (!data.isExternal) {
                            getMenuIsAdminServiceFact
                                .getServices().
                                then(function (data) {
                                    if(data.isAdmin)
                                        $scope.menuSidebar = menuAdminSidebar;
                            });
                        }
                    
                    });

           
         //Get menu details based on role and menuType
           getEmpPidServiceFact
               .getServices().
               then(function (data) {
                   $scope.empPid = data.empPid[0];
                   $scope.empfirstname = data.empPid[1].toUpperCase();
                   $scope.empLastName= data.empPid[2].toUpperCase();
                   $scope.empEmailId = data.empPid[3];
                   $scope.empPidImage = "https://my.csintra.net//NASApp/MyNPortal/PhotoServlet?command=viewPhoto&action=load&cn=" + $scope.empPid;
             });
       }
    ])



 //Image service
    .controller('internalLayoutBreadCrum', [
       '$scope', '$rootScope', function($scope, $rootScope) {
        }
    ])
.directive('showOnRowHover',

function () {
    return {
        link: function (scope, element, attrs) {

            element.closest('tr').bind('mouseenter', function () {
                element.show();
            });
            element.closest('tr').bind('mouseleave', function () {
                element.hide();

                var contextmenu = element.find('#contextmenu');
                contextmenu.click();

                element.parent().removeClass('open');

            });

        }
    };
});


menuSidebar = {
    "links": [
        {

            "image": "fa fa-home",
            "active": true,
            "link": "#",
            "text": "Home",
            "bBorder": 0,
            "uiSref": "home",
            "imageIcon": ""
            },
            {
                "image": "fa fa-pencil-square-o",
                     "active": false,
                     "link": "#",
                     "text": "Work List",
                     "mLeft": 23,
                     "uiSref": "dashboard",
                     "imageIcon": ""
                     
        },


         {
             "text": "Program Dashboards",
             "image": "fa fa-list",
             "imageIcon": "fa fa-caret-down",
             "sub": [
                 {
                     "active": true,
                     "link": "#",
                     "text": "Legal Entity",
                     "uiSref": "legalEntity"
                 },
                 {
                     "active": false,
                     "link": "#",
                     "text": "Dodd Frank",
                     "uiSref": "workinprog"
                     
                 }
             ]
         },
         {
             "active": false,
             "link": "#",
             "text": "Learning & Knowledge Base",
             "image": "fa fa-book",
             "bBorder": 0,
             "uiSref": "learning",
             "imageIcon": ""
             

         },
          {
              "image": "fa fa-play-circle",
              "active": false,
              "link": "#",
              "text": "Automated Actions",
              "mLeft": 23,
              "uiSref": "workinprog",
              "imageIcon": ""
              


          },
          {

              "active": false,
              "link": "#",
              "text": "Reporting",
              "image": "fa fa-bar-chart-o",
              "bBorder": 0,
              "uiSref": "workinprog",
              "imageIcon": ""
              

          },
           {
               "image": "fa fa-wrench",
               "text": "eTools",
               "mLeft": 23,
               "imageIcon": "fa fa-caret-down",
               "sub": [
                   {
                       "active": true,
                       "link": "#/ePortalHeirarchy",
                       "text": "Introduction to the Tools",
                       "uiSref": "heirarchy",
                       "target": "_self"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/IS/Content/EnvInvSys/Catis.aspx",
                       "text": "eInventory",
                       "uiSref": "",
                       "target": "_blank"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/EAllocations/home",
                       "text": "eAllocation",
                       "uiSref": "",
                       "target": "_blank"
                       
                   }
               ]
           },
            {

                "text": "About Us",
                "image": "fa fa-users",
                "bBorder": 0,
                "imageIcon": "fa fa-caret-down",
                "sub": [
                    {
                        "active": true,
                        "link": "#",
                        "text": "PTG EM",
                        "uiSref": "index"
                        
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Meet The Team",
                        "uiSref": "about"
                        
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Services",
                        "uiSref": "services"
                        
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Clients",
                        "uiSref": "client"
                        
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Contact Us",
                        "uiSref": "contact"
                        
                    }
                ]
            },
          {
              "image": "fa fa-child",
              "active": false,
              "link": "#",
              "text": "Help",
              "mLeft": 23,
              "uiSref": "workinprog",
              "imageIcon": ""
              

          },
            {
                "image": "fa fa-ticket",
                "active": false,
                "link": "#",
                "text": "Communication",
                "mLeft": 23,
                "uiSref": "Communication",
                "imageIcon": ""
                
            }
            //{
            //    "image": "fa fa-certificate",
            //    "active": false,
            //    "link": "#",
            //    "text": "Subscription",
            //    "mLeft": 23,
            //    "uiSref": "Subscription",
            //    "imageIcon": ""

            //}
    ]
};



menuSideExternalbar = {
    "links": [
        {

            "image": "fa fa-home",
            "active": true,
            "link": "#",
            "text": "Home",
            "uiSref": "home"
            
        },

         {
             "text": "Program Dashboards",
             "image": "fa fa-list",
             "sub": [
                 {
                     "active": true,
                     "link": "#",
                     "text": "Legal Entity",
                     "uiSref": "legalEntity"
                 },
                 {
                     "active": false,
                     "link": "#",
                     "text": "Dodd Frank",
                     "uiSref": "workinprog"
                 }
             ]
         },
          {
              "active": false,
              "link": "#",
              "text": "Automated Actions",
              "image": "fa fa-book",
              "uiSref": "workinprog"
          },
          {
              "active": false,
              "link": "#",
              "text": "Reporting",
              "image": "fa fa-bar-chart-o",
              "bBorder": 0,
              "uiSref": "workinprog"

          },
           {
               "image": "fa fa-wrench",
               "text": "eTools",
               "mLeft": 23,
               "imageIcon": "fa fa-caret-down",
               "sub": [
                   {
                       "active": true,
                       "link": "#/ePortalHeirarchy",
                       "text": "Introduction to the Tools",
                       "uiSref": "heirarchy",
                       "target": "_self"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/IS/Content/EnvInvSys/Catis.aspx",
                       "text": "eInventory",
                       "uiSref": "",
                       "target": "_blank"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/EAllocations/home",
                       "text": "eAllocation",
                       "uiSref": "",
                       "target": "_blank"

                   }
               ]
           },
            {
                "text": "About Us",
                "image": "fa fa-h-square",
                "bBorder": 0,
                "sub": [
                    {
                        "active": true,
                        "link": "#",
                        "text": "PTG EM",
                        "uiSref": "index"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Meet The Team",
                        "uiSref": "about"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Services",
                        "uiSref": "services"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Clients",
                        "uiSref": "client"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Contact Us",
                        "uiSref": "contact"
                       
                    }
                ]
            },

          {
              "image": "fa fa-child",
              "active": false,
              "link": "#",
              "text": "Help",
              "mLeft": 23,
              "uiSref": "workinprog"
              
          }
            //{
            //    "image": "fa fa-certificate",
            //    "active": false,
            //    "link": "#",
            //    "text": "Subscription",
            //    "mLeft": 23,
            //    "uiSref": "Subscription",
            //    "imageIcon": ""

            //}
    ]
};

menuAdminSidebar = {
    "links": [
        {

            "image": "fa fa-home",
            "active": true,
            "link": "#",
            "text": "Home",
            "bBorder": 0,
            "uiSref": "home",
            "imageIcon": ""
            
        },
            {
                "image": "fa fa-pencil-square-o",
                "active": false,
                "link": "#",
                "text": "Work List",
                "mLeft": 23,
                "uiSref": "dashboard",
                "imageIcon": ""
                
            },


         {
             "text": "Program Dashboards",
             "image": "fa fa-list",
             "imageIcon": "fa fa-caret-down",
             "sub": [
                 {
                     "active": true,
                     "link": "#",
                     "text": "Legal Entity",
                     "uiSref": "legalEntity"
                 },
                 {
                     "active": false,
                     "link": "#",
                     "text": "Dodd Frank",
                     "uiSref": "workinprog"
                 }
             ]
         },
         {
             "active": false,
             "link": "#",
             "text": "Learning & Knowledge Base",
             "image": "fa fa-book",
             "bBorder": 0,
             "uiSref": "learning",
             "imageIcon": ""
         },
          {
              "image": "fa fa-play-circle",
              "active": false,
              "link": "#",
              "text": "Automated Actions",
              "mLeft": 23,
              "uiSref": "workinprog",
              "imageIcon": ""
          },
          {

              "active": false,
              "link": "#",
              "text": "Reporting",
              "image": "fa fa-bar-chart-o",
              "bBorder": 0,
              "uiSref": "workinprog",
              "imageIcon": ""
          },
           {
               "image": "fa fa-wrench",
               "text": "eTools",
               "mLeft": 23,
               "imageIcon": "fa fa-caret-down",
               "sub": [
                   {
                       "active": true,
                       "link": "#/ePortalHeirarchy",
                       "text": "Introduction to the Tools",
                       "uiSref": "heirarchy",
                       "target": "_self"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/IS/Content/EnvInvSys/Catis.aspx",
                       "text": "eInventory",
                       "uiSref": "",
                       "target": "_blank"
                   },
                   {
                       "active": false,
                       "link": "https://etools.app.hedani.net/EAllocations/home",
                       "text": "eAllocation",
                       "uiSref": "",
                       "target": "_blank"

                   }
               ]
           },
            {

                "text": "About Us",
                "image": "fa fa-users",
                "bBorder": 0,
                "imageIcon": "fa fa-caret-down",
                "sub": [
                    {
                        "active": true,
                        "link": "#",
                        "text": "PTG EM",
                        "uiSref": "index"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Meet The Team",
                        "uiSref": "about"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Services",
                        "uiSref": "services"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Clients",
                        "uiSref": "client"
                    },
                    {
                        "active": false,
                        "link": "#",
                        "text": "Contact Us",
                        "uiSref": "contact"
                    }
                ]
            },
          {
              "image": "fa fa-laptop",
              "active": false,
              "link": "#",
              "text": "Admin",
              "bBorder": 0,
              "mLeft": 23,
              "uiSref": "userRole",
              "imageIcon": ""
          },
          {
              "image": "fa fa-child",
              "active": false,
              "link": "#",
              "text": "Help",
              "mLeft": 23,
              "uiSref": "workinprog",
              "imageIcon": ""

          },
            {
                "image": "fa fa-ticket",
                "active": false,
                "link": "#",
                "text": "Communication",
                "mLeft": 23,
                "uiSref": "Communication",
                "imageIcon": ""
            }
            //{
            //    "image": "fa fa-certificate",
            //    "active": false,
            //    "link": "#",
            //    "text": "Subscription",
            //    "mLeft": 23,
            //    "uiSref": "Subscription",
            //    "imageIcon": ""

            //}
    ]
};

