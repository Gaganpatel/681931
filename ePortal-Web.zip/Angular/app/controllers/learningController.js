﻿dashboardApp
    .controller('learningController', [
        '$scope', '$http', '$location', '$timeout', '$upload', 'menuServiceFactory', 'getProjServiceFactory', 'getSectionServiceFactory', 'getUploadServiceFactory', 'getDocmentServiceFactory', 'getLinkServiceFactory', '$rootScope',
        function ($scope, $http, $location, $timeout, $upload, menuServiceFact, getProjServiceFact, getSectionServiceFact, getUploadServiceFact, getDocmentServiceFact, getLinkServiceFact, $rootScope) {
            //if ($location.path().indexOf('/welcome') >= 0 || $location.path().indexOf('/services') == -1)
            //    return;
            // Assigning BreadCrums
            $scope.$parent.ePortalCustommenus = new Array();
            $scope.$parent.ePortalCustommenus.push('Learning & Collaboration');

            //Get menu details based on role and menuType
            menuServiceFact
                .getServices("IN", 7).
                then(function(data) {
                    //console.log(data);
                });

            $scope.oneAtATime = true;
            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

            //tabs menu 

            $('.learningtab_list > li').on('click', function() {
                $(this).parent().find('.active').removeClass('active')
                    .end().find(this).addClass('active');
                $('.tab_contents').find('.active').removeClass('active')
                    .end().find('.' + $(this).data('target')).addClass('active');
            });


            //Get projects from DB
            getProjServiceFact
                .getServices().
                then(function(data) {
                    $scope.projects = data.proj;
                });

            //Get projects from DB
            getSectionServiceFact
                .getServices().
                then(function (data) {
                    //selecting except two sections 
                    var temp = JSLINQ(data.sec)
                        .Where(function (item) { return item.SectionId != 27 && item.SectionId != 28; });

                    $scope.sections = temp.items;
                });

            //Setting dropdown value to one..
            $scope.projId = 1;

            //get Documents --- First drop down value
            getDocmentServiceFact
                .getServices($scope.projId).
                then(function(data) {
                    $scope.urlSetDoc = data.docResult;
                });
            //get Links --- First drop down value
            getLinkServiceFact
                .getServices($scope.projId).
                then(function(data) {
                    $scope.urlSetLinks = data.linksResult;
                });

            //Links from services on project dropdown change
            $scope.getDocumentList = function(projId) {
                //get Documents for rest based on project selection 
                getDocmentServiceFact
                    .getServices(projId).
                    then(function(data) {
                        $scope.urlSetDoc = data.docResult;
                    });
                //get Links rest based on project selection
                getLinkServiceFact
                    .getServices(projId).
                    then(function(data) {
                        $scope.urlSetLinks = data.linksResult;
                    });
            };

            $scope.FileName = '';

            //upload to temp table
            $scope.onFileSelect = function($files) {
                //$files: an array of files selected, each file has name, size, and type.
                for (var i = 0; i < $files.length; i++) {
                    var $file = $files[i];
                    $scope.FileName = $file.name;

                    (function(index) {
                        $scope.upload[index] = $upload.upload({
                            url: "./api/File/upload", // webapi url
                            method: "POST",
                            data: { fileUploadObj: $scope.fileUploadObj },
                            file: $file
                        }).progress(function(evt) {
                            // get upload percentage
                            console.log('percent: ' + parseInt(100.0 * evt.loaded / evt.total));
                        }).success(function(data, status, headers, config) {
                            // file is uploaded successfully
                            // toastr.success("File upload successfull.");
                            console.log(data);
                        }).error(function(data, status, headers, config) {
                            toastr.error("Error in file upload. Please check your file.");
                            console.log(data);
                        });
                    })(i);
                }
            };

            //upload and save to DB
            $scope.uploadDoc = function() {
                var fileDescription = $scope.file_Desc;
                var file = $scope.FileName;

                var obj = [{ "FileName": file, "FileDescription": fileDescription, "ProjectId": $scope.projId, "SectionId": $scope.sectionIdDropdown }];
                if (typeof fileDescription != "undefined" && file != "") {
                    $http({
                        method: "POST",
                        url: 'api/PostSaveFileDetails',
                        data: obj[0]
                    }).success(function(data) {
                        if (data > 0) {
                            $scope.file_Desc = '';

                            //get Documents for rest based on project selection 
                            getDocmentServiceFact
                                .getServices($scope.projId).
                                then(function(result) {
                                    $scope.urlSetDoc = result.docResult;
                                });
                            //get Links rest based on project selection
                            getLinkServiceFact
                                .getServices($scope.projId).
                                then(function(result) {
                                    $scope.urlSetLinks = result.linksResult;
                                });
                            toastr.success("File uploaded successfully.");
                        } else {
                            toastr.error("Error in upload.");
                        }
                    }).error(function(e) {
                        toastr.warning("Error in Upload.Please try again");
                    });
                } else {
                    toastr.warning("Please select file to upload/ Enter file description");
                }
            };

            $scope.abortUpload = function(index) {
                $scope.upload[index].abort();
            };
        }
    ]);