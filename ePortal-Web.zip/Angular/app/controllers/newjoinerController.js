﻿dashboardApp
    .controller('newjoinerController', [
        '$scope',  '$http', '$location', '$upload', 'menuServiceFactory', 'getProjServiceFactory', 'getDocmentServiceFactory', 'getLinkServiceFactory', 'getSectionServiceFactory',
        function ($scope, $http, $location, $upload, menuServiceFact, getProjServiceFact, getDocmentServiceFact, getLinkServiceFact, getSectionServiceFact) {
            if ($location.path().indexOf('/ePortalHome') >= 0 || $location.path().indexOf('/ePortalGuide') == -1)
                return;
            // Assigning BreadCrums
            $scope.$parent.ePortalCustommenus = new Array();
            $scope.$parent.ePortalCustommenus.push('Joiners Guide');

            //Get menu details based on role and menuType
            menuServiceFact
               .getServices("IN",8).
               then(function (data) {
                  console.log(data);
               });

            var w = $('.side_menu').outerWidth();
            $('.off-canvas-overlay').hide();
            $('.side_menu').animate({
                left: '-' + w + 'px'
            }, 200).toggleClass('active');

       $('#myTab a').click(function(e) {
            e.preventDefault();
            $(this).tab('show');
        });


      //Get projects from DB
        getProjServiceFact
            .getServices().
            then(function (data) {
                $scope.projects = data.proj;
            });

        $scope.projId = 1;
            //get Documents
        getDocmentServiceFact
                .getServices($scope.projId).
                then(function (data) {
                    $scope.urlSetDoc = data.docResult;
                });
            //get Links
        getLinkServiceFact
              .getServices($scope.projId).
              then(function (data) {
                  $scope.urlSetLinks = data.linksResult;
              });

            //Get sections from DB
        getSectionServiceFact
            .getServices().
            then(function (data) {
                //selecting ly two sections 
                var temp = JSLINQ(data.sec)
                    .Where(function (item) { return item.SectionId == 27 || item.SectionId == 28; });
                $scope.sections = temp.items;
            });

            //Links from services on project dropdown change
        $scope.getDocumentListProj = function (projId) {
            //get Documents
            getDocmentServiceFact
                    .getServices(projId).
                    then(function (data) {
                        $scope.urlSetDoc = data.docResult;
                    });
            //get Links
            getLinkServiceFact
                  .getServices(projId).
                  then(function (data) {
                      $scope.urlSetLinks = data.linksResult;
                  });
        };

        $scope.videoStream = false;

        $scope.onclickVideo = function() {
            var myPlayer = videojs("example_video");
            myPlayer.play();
            $scope.videoStream = true;
        };

       /* UPLOAD**/
       //upload to temp table
        $scope.onFileSelect = function ($files) {
            //$files: an array of files selected, each file has name, size, and type.
            for (var i = 0; i < $files.length; i++) {
                var $file = $files[i];
                $scope.FileName = $file.name;

                (function (index) {
                    $scope.upload[index] = $upload.upload({
                        url: "./api/File/upload", // webapi url
                        method: "POST",
                        //data: { fileUploadObj: $scope.fileUploadObj },
                        file: $file
                    }).progress(function (evt) {
                        // get upload percentage
                        console.log('percent: ' + parseInt(100.0 * evt.loaded / evt.total));
                    }).success(function (data, status, headers, config) {
                        // file is uploaded successfully
                        // toastr.success("file upload successfull.");
                        console.log(data);
                    }).error(function (data, status, headers, config) {
                        toastr.error("Error in file upload.Please check your file.");
                        console.log(data);
                    });
                })(i);
            }
        };

            //upload and save to DB
        $scope.uploadDoc = function () {
            var fileDescription = $scope.file_Desc;
            var file = $scope.FileName;

            var obj = [{ "FileName": file, "FileDescription": fileDescription, "ProjectId": $scope.projId, "SectionId": $scope.sectionIdDropdown }];
            if (typeof fileDescription != "undefined" && file != "") {
                $http({
                    method: "POST",
                    url: 'api/PostSaveFileDetails',
                    data: obj[0]
                }).success(function (data) {
                    if (data > 0) {
                       $scope.file_Desc = '';

                        //get Documents for rest based on project selection 
                        getDocmentServiceFact
                            .getServices($scope.projId).
                            then(function (result) {
                                $scope.urlSetDoc = result.docResult;
                            });
                        //get Links rest based on project selection
                        getLinkServiceFact
                            .getServices($scope.projId).
                            then(function (result) {
                                $scope.urlSetLinks = result.linksResult;
                            });
                        toastr.success("File uploaded successfully.");
                    } else {
                        toastr.error("Error in upload..");
                    }
                }).error(function (e) {
                    toastr.warning("Error in save.Please check your inputs");
                });
            } else {
                toastr.warning("Please select file to upload/Enter file title");
            }
        };
     }
]);