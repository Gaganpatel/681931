var app = angular.module('ePortalApp', ['ui.router', 'ngAnimate','homeApp']);

app.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.when("/resources", "/resources/list");
    $urlRouterProvider.otherwise("/ExternalUser/index");

    // Now set up the states
    angular.forEach(urlData, function(value, key) {
        obj = {
            url: value.url,
            templateUrl: value.templateUrl,
        };
        if ('' != value.controller) {
            obj.controller = value.controller;
        }
        $stateProvider.state(value.state, obj);
    });
});

urlData = [
    {
        'state': 'index',
        'url': '/ExternalUser/index',
        'templateUrl': 'Angular/app/views/ExternalUser/index.html',
        'controller':'HomePageController'   
    },
    {
        'state': 'services',
        'url': '/ExternalUser/services',
        'templateUrl': 'Angular/app/views/ExternalUser/services.html',
        'controller': 'ServicesPageController'
    },
    {
        'state': 'about',
        'url': '/ExternalUser/about',
        'templateUrl': 'Angular/app/views/ExternalUser/about_us.html',
        'controller': 'aboutUsController'
    },
     {
         'state': 'heirarchy',
         'url': '/ExternalUser/heirarchy',
         'templateUrl': 'Angular/app/views/ExternalUser/heirarchy.html',
         'controller': 'HeirarchyPageController'
     },
   {
        'state': 'contact',
        'url': '/ExternalUser/contact',
        'templateUrl': 'Angular/app/views/ExternalUser/contact_us.html',
        'controller': 'ContactUsController'
    },
    {
        'state': 'sdesign',
        'url': '/ExternalUser/sdesign',
        'templateUrl': 'Angular/app/views/ExternalUser/s-design.html',
        'controller': 'CrtlServiceDesign'
    },
    {
        'state': 'scontrol',
        'url': '/ExternalUser/scontrol',
        'templateUrl': 'Angular/app/views/ExternalUser/s-control.html',
        'controller': 'CrtlServiceControl'
    },
    {
        'state': 'soperation',
        'url': '/ExternalUser/soperation',
        'templateUrl': 'Angular/app/views/ExternalUser/s-operation.html',
        'controller': 'CrtlServiceOperation'
    },
    {
        'state': 'soptimization',
        'url': '/ExternalUser/soptimization',
        'templateUrl': 'Angular/app/views/ExternalUser/s-optimization.html',
        'controller': 'CrtlServiceOptimiz'
    },
    {
        'state': 'sspecialserv',
        'url': '/ExternalUser/sspecialserv',
        'templateUrl': 'Angular/app/views/ExternalUser/s-specialserv.html',
        'controller': 'CrtlServiceSpecial'
    }
];
