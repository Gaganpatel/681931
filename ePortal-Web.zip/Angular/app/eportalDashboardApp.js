﻿
var dashboardApp = angular.module('ePortalDashboardApp', ['ngRoute', 'ngSanitize', 'ui.router', 'ngGrid', 'ui.bootstrap', 'ui.sortable', 'angularFileUpload', 'kendo.directives']);

dashboardApp.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.when("/dashboard", "/ePortalDashboard");
    $urlRouterProvider.otherwise("/ePortalHome");
    
    angular.forEach(urlData, function(value, key) {
        obj = {
            url: value.url,
            templateUrl: value.templateUrl,
        };
        if ('' != value.controller) {
            obj.controller = value.controller;
        }
        $stateProvider.state(value.state, obj);
    });
});

dashboardApp.run(function ($rootScope) {
    $rootScope.ePortalCustommenus = new Array();
    $rootScope.isLoggedIn = false;
    $rootScope.isExternal = false;
    

});

urlData = [
        {
            'state': 'home',
            'url': '/ePortalHome',
            'templateUrl': 'Angular/app/views/internaluser/dashboard/welcome.html',
            'controller': 'WelcomeController'
        },
        {
            'state': 'dashboard',
            'url': '/ePortalDashboard',
            'templateUrl': 'Angular/app/views/internaluser/dashboard/index.html',
            'controller': 'DashboardController'
        },
        ,
        {
            'state': 'legalEntity',
            'url': '/ePortalLegalEntity',
            'templateUrl': 'Angular/app/views/internaluser/dashboard/legal_entity.html',
            'controller': 'LegalEntityController'
        },
        {
            'state': 'data',
            'url': '/ePortalData',
            'templateUrl': 'Angular/app/views/internaluser/dashboard/responsive_table.html',
            'controller': 'DataController'
        },
        {
            'state': 'settings',
            'url': '/ePortalSettings',
            'templateUrl': 'js/app/views/dashboard/settings.html',
            'controller': 'SettingsController'
        },
        {
            'state': 'admin',
            'url': '/ePortalAdmin',
            'templateUrl': 'Angular/app/views/internaluser/admin/admin.html',
            'controller': 'AdminController'
        },
        {
            'state': 'learning',
            'url': '/ePortalLearningCollaboration',
            'templateUrl': 'Angular/app/views/internaluser/learningCollaboration/LearnNDoc.html',
            'controller': 'LearnNDocController'
        },
        {
            'state': 'guide',
            'url': '/ePortalGuide',
            'templateUrl': 'Angular/app/views/internaluser/newjoiner/guide.html',
            'controller': 'newjoinerController'
        },
        {
            'state': 'help',
            'url': '/ePortalHelp',
            'templateUrl': 'Angular/app/views/internaluser/admin/help.html',
            'controller': 'helpController'
        },
        {
            'state': 'Communication',
            'url': '/ePortalCommunication',
            'templateUrl': 'Angular/app/views/internaluser/UNToolUser/UntCreateIncident.html',
            'controller': 'UntIncidentController'
        },
        {
            'state': 'Subscription',
            'url': '/ePortalSubscription',
            'templateUrl': 'Angular/app/views/internaluser/UNToolUser/Subscription.html',
            'controller': 'UntSubscriptionController'
        },
        
        //External User
        {
            'state': 'about',
            'url': '/ePortalAbout',
            'templateUrl': 'Angular/app/views/ExternalUser/about_us.html',
            'controller': 'aboutUsController'
        },
        {
            'state': 'index',
            'url': '/ePortalIndex',
            'templateUrl': 'Angular/app/views/ExternalUser/index.html',
            'controller': 'HomePageController'
        },
        {
            'state': 'services',
            'url': '/ePortalServices',
            'templateUrl': 'Angular/app/views/ExternalUser/services.html',
            'controller': 'ServicesPageController'
        },
        {
            'state': 'client',
            'url': '/ePortalClients',
            'templateUrl': 'Angular/app/views/ExternalUser/client.html',
            'controller': 'ClientController'
        },
         {
             'state': 'heirarchy',
             'url': '/ePortalHeirarchy',
             'templateUrl': 'Angular/app/views/ExternalUser/heirarchy.html',
             'controller': 'HeirarchyPageController'
         },
        {
            'state': 'contact',
            'url': '/ePortalContact',
            'templateUrl': 'Angular/app/views/ExternalUser/contact_us.html',
            'controller': 'ContactUsController'
        },
        {
            'state': 'ssetupSer',
            'url': '/ePortalSetUpServices',
            'templateUrl': 'Angular/app/views/ExternalUser/s-setupServ.html',
            'controller': 'CrtlServiceDesign'
        },
        {
            'state': 'scontrolSer',
            'url': '/ePortalControlServices',
            'templateUrl': 'Angular/app/views/ExternalUser/s-controlServ.html',
            'controller': 'CrtlServiceControl'
        },
        {
            'state': 'soperateSer',
            'url': '/ePortalOperateServices',
            'templateUrl': 'Angular/app/views/ExternalUser/s-operateServ.html',
            'controller': 'CrtlServiceOperation'
        },
        {
            'state': 'saddonSer',
            'url': '/ePortalAddOnServices',
            'templateUrl': 'Angular/app/views/ExternalUser/s-addonServ.html',
            'controller': 'CrtlServiceOptimiz'
        },
        ,
        {
            'state': 'orgChart',
            'url': '/ePortalOrganizationChart',
            'templateUrl': 'Angular/app/views/ExternalUser/OrgChart.html',
            'controller': 'OrgHirerchyController'
        },
        {
            'state': 'userRole',
            'url': '/ePortalUserRole',
            'templateUrl': 'Angular/app/views/internaluser/admin/UserRole.html',
            'controller': 'AdminUserRoleController'
        },
        //Dummy Page for WIP pages
        {
            'state': 'workinprog',
            'url': '/ePortalWIP',
            'templateUrl': 'Angular/app/views/internaluser/newjoiner/WIP.html',
            'controller': 'WIPController'
        }
];

