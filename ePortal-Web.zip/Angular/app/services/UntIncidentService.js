﻿
/// <reference path="../views/UNToolUser/UntCreateIncident.html" />
/// <reference path="../views/internaluser/UNToolUser/UntEnvNotIncident.html" />
/// <reference path="../views/internaluser/UNToolUser/UntPlannedDowntime.html" />

/// <reference path="../../../Scripts/bootbox.min.js" />

////factories are defined here...

dashboardApp.factory('UntInitiateIncidentServiceFactory', [
    '$q', '$http', '$log', function($q, $http, $log) {
        return {
            getServices: function() {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: 'api/GetUntIncident1/'
                }).success(function (data) {
                    console.log(data);
                    deferred.resolve({
                        IncidentObjectResponse: eval(data)
                    });
                }).error(function(msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
                return deferred.promise;
            }
        };
    }
])


.factory('UntPostIncidentServiceFactory', [
    '$q', '$http', '$log', function ($q, $http, $log) {

        return {
            getServices: function (incidentObject) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: 'api/PostUntIncident/',
                    data:  incidentObject
                }).success(function (data) {
                    console.log(data);
                    deferred.resolve({
                        IncidentObjectResponse: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
                return deferred.promise;
            }
        };
    }
])
