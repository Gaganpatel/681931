﻿/// <reference path="../../../Scripts/bootbox.min.js" />
/// <reference path="../views/internaluser/UNToolUser/Subscription.html" />

////factories are defined here...

dashboardApp.factory('InitiateSubscriptionServiceFactory', [
    '$q', '$http', '$log', function ($q, $http, $log) {
        return {
            getServices: function () {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: 'api/GetSubscriptions/'
                }).success(function (data) {
                    console.log(data);
                    deferred.resolve({
                        SubscriptionObjectResponse: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
                return deferred.promise;
            }
        };
    }
])

.factory('PostSubscriptionServiceFactory', [
    '$q', '$http', '$log', function ($q, $http, $log) {

        return {
            getServices: function (subscriptionObject, isDelete) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: 'api/PostSubscription/' + isDelete,
                    data: subscriptionObject
                }).success(function (data) {
                    console.log(data);
                    deferred.resolve({
                        subscriptionObjectResponse: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
                return deferred.promise;
            }
        };
    }
])