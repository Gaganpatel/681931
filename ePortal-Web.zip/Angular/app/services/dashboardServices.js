﻿/// <reference path="../views/internaluser/learningCollaboration/learningAlt.html" />
/// <reference path="../../../Scripts/bootbox.min.js" />

////factories are defined here...

dashboardApp.factory('menuIsExternalServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetIsExternal/')
                  .success(function (data) {
                      //console.log(data);
                      deferred.resolve({
                          isExternal: eval(data)
                      });
                  }).error(function (msg, code) {
                      deferred.reject(msg);
                      $log.error(msg, code);
                  });
            return deferred.promise;
        }
    };
}])
.factory('menuIsAdminServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetIsAdmin/')
                  .success(function (data) {
                      //console.log(data);
                      deferred.resolve({
                          isAdmin: eval(data)
                      });
                  }).error(function (msg, code) {
                      deferred.reject(msg);
                      $log.error(msg, code);
                  });
            return deferred.promise;
        }
    };
}])

    .factory('menuServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (menuType, menuId) {
            var deferred = $q.defer();
            $http.get('api/GetMenuDetails/' + menuType + '/' + menuId)
                  .success(function (data) {
                      //console.log(data);
                      deferred.resolve({
                          locations: eval(data)
                      });
                  }).error(function (msg, code) {
                      deferred.reject(msg);
                      $log.error(msg, code);
                  });
            return deferred.promise;
        }
    };
    }])

    //Get Logged User Name
.factory('getLoggedUserIdService', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getuserId: function () {
            var deferred = $q.defer();
            $http.get('api/GetLoggedUserName/')
                .success(function (data) {
                    deferred.resolve({
                        loggedUser: data[0]
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//Keywords
.factory('getKeyWordsService', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getKeyWords: function () {
            var deferred = $q.defer();
            $http.get('api/GetKeyWords/')
                .success(function (data) {
                    deferred.resolve({
                        kwords: data
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//ScoreCards
.factory('getScoreCardService', ['$q', '$http', function ($q, $http) {
    return {
        getScore: function () {
            var deferred = $q.defer();
            $http.get('api/GetScoreCard/')
                .success(function (data) {
                    deferred.resolve({
                        scoreCard: data
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                });
            return deferred.promise;
        }
    };
}])
    //KnowledgeSites
.factory('getKSitesService', ['$q', '$http', function ($q, $http) {
    return {
        getKSites: function () {
            var deferred = $q.defer();
            $http.get('api/GetKnowledgeSites/')
                .success(function (data) {
                    deferred.resolve({
                        ksites: data
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                });
            return deferred.promise;
        }
    };
}])

//Project service - learning and collabration
.factory('getProjServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetProjectList/')
                .success(function (data) {
                    deferred.resolve({
                        proj: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//Notes service - FYI - <Notes/Awareness>
.factory('getNotesFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getNotes: function () {
            var deferred = $q.defer();
            $http.get('api/GetNotes/')
                .success(function (data) {
                    deferred.resolve({
                        note: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])


//Preferences service - Get preferences
.factory('getPreferences', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getUserPreferences: function () {
            var deferred = $q.defer();
            $http.get('api/GetPreferences/')
                .success(function (data) {
                    deferred.resolve({
                        preferences: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//SECTION service - upload documents
.factory('getSectionServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetSectionList/')
                .success(function (data) {
                    deferred.resolve({
                        sec: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//Upload document to DB
.factory('getUploadServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (projid, path, secid, fileDesc) {
            var deferred = $q.defer();
            $http.get('api/GetUploadDocuments/' + projid + '/' + path + '/' + secid + '/' + fileDesc)
                .success(function (data) {
                    deferred.resolve({
                        result: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getAdminMenuServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetAdminMenuSet/')
                .success(function (data) {
                    deferred.resolve({
                        adminMenu: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//Learning & collaboration section for links and docs

//admin menu service - upload documents
.factory('getDocmentServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (projId) {
            var deferred = $q.defer();
            $http.get('api/GetDocListByPrj/' + projId)
                .success(function (data) {
                    deferred.resolve({
                        docResult: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getLinkServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (projId) {
            var deferred = $q.defer();
            $http.get('api/GetLinkListByPrj/' + projId)
                .success(function (data) {
                    deferred.resolve({
                        linksResult: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getFaqSectionListServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetFaqSectionList/')
                .success(function (data) {
                    deferred.resolve({
                        FAQlistResult: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getFaqQuestionAnswerServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (projId) {
            var deferred = $q.defer();
            $http.get('api/GetFaqSectionDetailsByPrj/' + projId)
                .success(function (data) {
                    deferred.resolve({
                        FaqQestAnswResult: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

    //Get all admin list - portal
.factory('getAdminListServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetAdminListPortal/')
                .success(function (data) {
                    deferred.resolve({
                        adminList: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])


.factory('getIncDetailsServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        
            getServices: function () {
                var deferred = $q.defer();
                $http.get('api/GetINCDetails/')
                    .success(function (data) {
                        deferred.resolve({
                            incData: eval(data)
                        });
                    }).error(function (msg, code) {
                        deferred.reject(msg);
                        $log.error(msg, code);
                    });
                return deferred.promise;
            }
    };
}])
//admin menu service - upload documents
.factory('getRfcTicketByGroupServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetTicketByGroup/')
                .success(function (data) {
                    deferred.resolve({
                        rfcData: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getEmpPidServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetEmpPidDetails/')
                .success(function (data) {
                    deferred.resolve({
                        empPid: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])
// web config appkey setting values
.factory('webKeyServiceExtFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
        return {
            getWebKey: function () {
                var deferred = $q.defer();
                $http.get('api/GetWebAppKeyvalue/')
                    .success(function (data) {
                        deferred.resolve({
                            AppKeyWebConfig: eval(data)
                        });
                    }).error(function (msg, code) {
                        deferred.reject(msg);
                        $log.error(msg, code);
                    });
                return deferred.promise;
            }
        };
}])

// User Id  status
.factory('getUseIdStatusFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getUserIdStatus: function (userId) {
            var deferred = $q.defer();
            $http.get('api/GetUserIdStatus/' + userId)
                .success(function (data) {
                    deferred.resolve({
                        checkUserIdOut: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

    // User Id  status
.factory('getUserRoleFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getUserRole: function (userId) {
            var deferred = $q.defer();
            $http.get('api/GetUserRole/')
                .success(function (data) {
                    deferred.resolve({
                        userRole: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])


    // User Id  status
.factory('getUsersRoleFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getUsersRole: function (userId) {
            var deferred = $q.defer();
            $http.get('api/GetUsersRoleDetails/' + userId)
                .success(function (data) {
                    deferred.resolve({
                        usersRole: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//services for JIRA

.factory('getJiraDataServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {

    return {
        getServices: function (totalRecReqd) {
            var deferred = $q.defer();
           
            $http.get('api/GetJiraAuthorisation/' + totalRecReqd)
                                .success(function (data) {
                                    
                                    var url = data[0];
                                    $http.get(url,
                                               {
                                                   headers:
                                                        {
                                                            Authorization: 'Basic ' ,
                                                            dataType: 'json',
                                                            "Content-Type": "application/json"
                                                        }
                                               }).success(function (resultTable) {
                                                   deferred.resolve({
                                                       jiraDetails: eval(resultTable)
                                                   });
                                               }).error(function (msg, code) {
                                                   $log.error(msg, code);                                                                                                    
                                               });
                                }).error(function (msg, code) {
                                    $log.error(msg, code);
                                });
            
            return deferred.promise;
        }
    };
}])


.factory('getJiraDataServiceFactoryReporter', ['$q', '$http', '$log', function ($q, $http, $log) {

    return {
        getServices: function (totalRecReqd) {
            var deferred = $q.defer();
           
            $http.get('api/GetJiraAuthorisationReporter/' + totalRecReqd)
                                .success(function (data) {
                                    
                                    var url = data[0];
                                    $http.get(url,
                                               {
                                                   headers:
                                                        {
                                                            Authorization: 'Basic ' ,
                                                            dataType: 'json',
                                                            "Content-Type": "application/json"
                                                        }
                                               }).success(function (resultTable) {
                                                   deferred.resolve({
                                                       jiraDetails: eval(resultTable)
                                                   });
                                               }).error(function (msg, code) {
                                                   $log.error(msg, code);                                                                                                    
                                               });
                                }).error(function (msg, code) {
                                    $log.error(msg, code);
                                });
            
            return deferred.promise;
        }
    };
}]);