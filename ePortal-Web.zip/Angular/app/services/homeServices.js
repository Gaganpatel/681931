﻿//factories are defined here...

dashboardApp.factory('homeServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetHomePageDetails/')
                .success(function (data) {
                    deferred.resolve({
                    localData: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

.factory('webKeyServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
        return {
            getServices: function () {
                var deferred = $q.defer();
                $http.get('api/GetWebAppKeyvalue/')
                    .success(function (data) {
                        deferred.resolve({
                            links: eval(data)
                        });
                    }).error(function (msg, code) {
                        deferred.reject(msg);
                        $log.error(msg, code);
                    });
                return deferred.promise;
            }
        };
}])

.factory('menuServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (menuType, menuId) {
            var deferred = $q.defer();
          $http.get('api/GetMenuDetails/'  + menuType + '/' + menuId)
                .success(function (data) {
                //console.log(data);
                    deferred.resolve({
                       fullDetails: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

//admin menu service - upload documents
.factory('getAdminMenuServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function () {
            var deferred = $q.defer();
            $http.get('api/GetAdminMenuSet/')
                .success(function (data) {
                    deferred.resolve({
                        adminMenu: eval(data)
                    });
                }).error(function (msg, code) {
                    deferred.reject(msg);
                    $log.error(msg, code);
                });
            return deferred.promise;
        }
    };
}])

.factory('getHealthCheckSummaryServiceFactory', ['$q', '$http', '$log',function($q, $http, $log) {
        return {
            getServices: function() {
                var deferred = $q.defer();
                $http.get('api/GetHealthCheckSummary')
                    .success(function(data) {
                        deferred.resolve({
                            healthCheckSummary: eval(data)
                    });
                    }).error(function(msg, code) {
                            deferred.rejecte(msg, code);
                    });
            return deferred.promise;
            }
        };
}])

.factory('PostHealthCheckSummaryServiceFactory', ['$q', '$http', '$log', function ($q, $http, $log) {
    return {
        getServices: function (healthCheckSummaryObject) {
            var deferred = $q.defer();
            $http({
                method: "POST",
                url: 'api/PostHealthCheckSummary/',
                data: healthCheckSummaryObject
            }).success(function (data) {
                console.log(data);
                deferred.resolve({
                    healthCheckSummary: eval(data)
                });
            }).error(function (msg, code) {
                deferred.reject(msg);
                $log.error(msg, code);
            });
            return deferred.promise;
        }
    };
}])