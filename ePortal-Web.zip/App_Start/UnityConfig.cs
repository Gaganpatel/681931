﻿using System;
using ePortal.Dal;
using ePortal.DatabaseHelper;
using ePortal.DatabaseHelper.Sybase;
using ePortal.DomainModel;
using ePortal.EntityModel;
using ePortal.Interfaces.Dal;
using ePortal.Interfaces.DomainModel;
using ePortal.Interfaces.EntityModel;
using ePortal.Interfaces.Mapper;
using ePortal.Mapper;
using Microsoft.Practices.Unity;

namespace ePortal.Web
{
    public class UnityConfig
    {
        #region Unity Container
        private static Lazy<IUnityContainer> container = new Lazy<IUnityContainer>(() =>
        {
            var container = new UnityContainer();
            RegisterTypes(container);
            return container;
        });

        /// <summary>
        /// Gets the configured Unity container.
        /// </summary>
        public static IUnityContainer GetConfiguredContainer()
        {
            return container.Value;
        }
        #endregion

        /// <summary>Registers the type mappings with the Unity container.</summary>
        /// <param name="objUnityContainer">The unity container to configure.</param>
        /// <remarks>There is no need to register concrete types such as controllers or API controllers (unless you want to 
        /// change the defaults), as Unity allows resolving a concrete type even if it was not previously registered.</remarks>
        public static void RegisterTypes(IUnityContainer objUnityContainer)
        {

            objUnityContainer.RegisterType<IDataBaseHelper, SybaseHelper>();

            RegisterConverter(objUnityContainer);
            RegisterDal(objUnityContainer);
            RegisterEntity(objUnityContainer);
            RegisterFactory();
            RegisterServiceLayerComponents();
        }

        private static void RegisterFactory()
        {
            //objUnityContainer.RegisterType<IFactory, Factory.ObjectFactory>();
        }

        private static void RegisterEntity(IUnityContainer objUnityContainer)
        {
            objUnityContainer.RegisterType<IPageContentModel, PageContentModel>();
            objUnityContainer.RegisterType<IContent, Content>();
            objUnityContainer.RegisterType<IAdminMenu, AdminMenu>();
            objUnityContainer.RegisterType<IMenu, Menu>();
            objUnityContainer.RegisterType<IPortalStart, PortalStart>();
            objUnityContainer.RegisterType<IFaqSection, FaqSection>();
            objUnityContainer.RegisterType<IDocument, Document>();
            objUnityContainer.RegisterType<IFaqDetails, FaqDetails>();
            objUnityContainer.RegisterType<ILocation, Location>();
            objUnityContainer.RegisterType<IHealthCheckSummary, HealthCheckSummary>();
            objUnityContainer.RegisterType<IRateKnowledge, RateKnowledge>();
            objUnityContainer.RegisterType<IIncDetails, IncDetails>();
            //UNTool
            objUnityContainer.RegisterType<IUntSubscription, UntSubscription>();
            objUnityContainer.RegisterType<IUntCommunicationType, UntCommunicationType>();
            objUnityContainer.RegisterType<IUntImpact , UntImpact>();
            objUnityContainer.RegisterType<IUntIncidentId, UntIncidentId>();
            objUnityContainer.RegisterType<IUntIncident, UntIncident>();

        }

        private static void RegisterDal(IUnityContainer objUnityContainer)
        {
            objUnityContainer.RegisterType<ICommonDal<IPortalStart>, CommonDal>();
            objUnityContainer.RegisterType<IContentDal<IContent>, ContentDal>();


            //UNTool
            objUnityContainer.RegisterType<IUntIncidentDal<IUntIncident, UntIncident>, UntIncidentDal>();
            objUnityContainer.RegisterType<IUntSubscriptionDal<IUntSubscription, UntSubscription>, UntSubscriptionDal>();

        }

        private static void RegisterConverter(IUnityContainer objUnityContainer)
        {
            objUnityContainer.RegisterType<ICommonMapper<IPageContentModel>, CommonMapper>();
        }

        private static void RegisterServiceLayerComponents()
        {
            // objUnityContainer.RegisterType<ITisService, TisServices>();
        }
    }
}