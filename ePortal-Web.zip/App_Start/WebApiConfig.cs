﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Filters;
using ePortal.Common;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;

namespace ePortal.Web
{
    public static class WebApiConfig
    {
        //http://www.asp.net/web-api/overview/web-api-routing-and-actions/routing-in-aspnet-web-api
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            //config.SuppressDefaultHostAuthentication();
           // config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
               name: "DefaultApi",
               routeTemplate: "api/{controller}/{id}",
               defaults: new { id = RouteParameter.Optional }
           );

            config.Routes.MapHttpRoute(
                name: "SomeCall",
                routeTemplate: "put/{controller}/{id}/{status}",
                defaults: new { id = RouteParameter.Optional, Status = RouteParameter.Optional }
                );
        }

        public class LogExceptionFilter : ExceptionFilterAttribute
        {
            public override void OnException(HttpActionExecutedContext actionExecutedContext)
            {
                base.OnException(actionExecutedContext);
                Logger.Log(actionExecutedContext.Exception.Message, actionExecutedContext.Exception.StackTrace);

                //HttpContext.Current.Response.Redirect("Error");
            }
        }

    }
}
