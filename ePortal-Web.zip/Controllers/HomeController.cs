﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using CS.PHART.BusinessLogic;
using ePortal.Common;
//using PeopleSearch;

namespace ePortal.Web.Controllers
{
    public class HomeController : Controller
    {
        // GET: Main

        public ActionResult Index()
        {
           return View("InternalHome");
        }

        public ActionResult InternalHome()
        {
            return View("InternalHome");
        }
    }
}



                                                     