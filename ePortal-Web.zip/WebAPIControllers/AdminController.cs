﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using CS.PHART.BusinessLogic;
using ePortal.Common;
using ePortal.DomainModel;
using ePortal.EntityModel;
using ePortal.Interfaces.Dal;
using ePortal.Interfaces.DomainModel;
using ePortal.Interfaces.EntityModel;
using ePortal.Interfaces.Mapper;
using Microsoft.Ajax.Utilities;

namespace ePortal.Web.WebAPIControllers
{
    
    public class AdminController : ApiController
    {
        #region "Get Logged User Name"
        // GET api/<controller>
        [Route("api/GetLoggedUserName/")]
        public List<string> GetLoggedUserName()
        {
            var listLog= new List<string>();
            listLog.Add(Helpers.GetLoggedUserDetail);
            return listLog;
        }
        #endregion

        #region "Save Project Details"
        // PUT api/<controller>
        [Route("api/PostProject/{projectList}")]
        public int PostProject(List<string> projectList)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objServiceCaller.SaveProject(projectList);
        }
        #endregion

        #region "PostNotes"

        [Route("api/PostNotes/")]
        public int PostNotes(Notes note)
        {
            var notes = note.Note;
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();

            return objServiceCaller.PostNotes(notes);

        }

        #endregion


        #region "UpdateGridState"

        // PUT api/<controller>
        [Route("api/UpdateGridState/")]
        public int UpdateGridState(GridState gridstate)
        {
            var gridState = gridstate.GdState;
            var userId = Helpers.GetLoggedUserDetail;
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();

            return objServiceCaller.UpdateGridState(userId, gridState);
        }

        #endregion


        #region "Get Admin Menu Details"
        // GET api/<controller>
        [Route("api/GetAdminMenuSet/")]
        public IEnumerable<IAdminMenu> GetAdminMenuSet()
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            
            //perform get operation and return data
            return objServiceCaller.GetAdminMenuSet();

        }
        #endregion

        #region "Save Admin Menu Details"
        // GET api/<controller>
        [Route("api/PostSectionContent/")]
        public int Post(Content input)
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            var objData = Factory.ObjectFactory.GetInstance<IContent>();

            objData.SectionId = input.SectionId;
            objData.ContentId=input.ContentId;
            objData.ContentDescription = input.ContentDescription;
            objData.ContentFooter = input.ContentFooter;
            objData.ContentTitle = input.ContentTitle;

            
            ////perform get operation and return data
            return objServiceCaller.Save(objData);

        }
        #endregion

        #region "Save Admin Internal Menu Details"
        // GET api/<controller>
        [Route("api/PostSectionContentInternal/")]
        public int PostInternal(AdminInput input)
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            var objData = Factory.ObjectFactory.GetInstance<IContent>();

            objData.SectionId = input.SectionId;
            objData.ContentId = input.ContentId;
            objData.ContentDescription = input.ContentDescription;
            objData.ContentFooter = input.ContentFooter;
            objData.ContentTitle = input.ContentTitle;


            var link = input.ListLinks.Select(row => new Links
            {
                LinkId = row.LinkId,
                LinkDescription = row.LinkDescription,
                Link = row.Link,
                ProjectId = row.ProjectId
            }).ToList<ILink>();

            objData.ListLinks = link;
  
            ////perform get operation and return data
            return objServiceCaller.SaveInternalContent(objData);

        }
        #endregion

        #region "Get faq Section List"
        // GET api/<controller>
        [Route("api/GetFaqSectionList/")]
        public IEnumerable<IFaqSection> GetFaqSectionList()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetFaqSectionList();
        }
        #endregion

        #region "Get Project level Faq List"
        // GET api/<controller>
        [Route("api/GetFaqSectionDetailsByPrj/{prjId}")]
        public IEnumerable<IFaqResult> GetFaqSectionDetailsByPrj(int prjId)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetFaqSectionDetailsByPrj(prjId);
        }
        #endregion

        #region "Save Faq Details"
        // GET api/<controller>
        [Route("api/PostFaqDetails/")]
        public int PostFaqDetails(List<FaqDetails> faqLists)
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();

            
            var faq = faqLists.Select(row => new FaqDetails
            {
                FaqId = row.FaqId,
                FaqQuestion = row.FaqQuestion,
                FaqAnswer = row.FaqAnswer,
                ProjectId = row.ProjectId,
                FaqDelete = row.FaqDelete,
                FaqSectionId = row.FaqSectionId
            }).ToList<IFaqDetails>();

            //perform get operation and return data
            return objServiceCaller.SaveFaqDetails(faq);
        }
        #endregion

        #region "Delete Faq Details"
        // GET api/<controller>
        [Route("api/PostFaqDelete/{faqId}")]
        public int PostFaqDelete(int faqId)
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            //perform get operation and return data
            return objServiceCaller.DeleteFaqDetails(faqId);

        }
        #endregion

        #region "Delete Link Details"
        // GET api/<controller>
        [Route("api/PostLinkDelete/{linkId}")]
        public int PostLinkDelete(int linkId)
        {
            ////get the object of respective data mapper
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            //perform get operation and return data
            return objServiceCaller.DeleteLinkDetails(linkId);

        }
        #endregion

        #region GetKnowledgeSites
        [Route("api/GetKnowledgeSites/")]
        public IList<ILocation> GetKnowledgeSites()
        {
            IList<ILocation> lstDocs = new List<ILocation>();
            if (null == HttpContext.Current.Cache["ksites"])
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                lstDocs = objContentDal.GetKnowledgeSites();
                HttpContext.Current.Cache.Insert("ksites", lstDocs);
                return lstDocs;
            }
            else
            {
                return HttpContext.Current.Cache["ksites"] as IList<ILocation>;
            }
        }
        #endregion

        #region GetKeyWords
        [Route("api/GetKeyWords/")]
        public IEnumerable<string> GetKeyWords() 
        {
            if (null == HttpContext.Current.Cache["keywords"])
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                List<string> lstKeyWords = objContentDal.GetKeyWords();
                HttpContext.Current.Cache.Insert("keywords", lstKeyWords);
                return lstKeyWords;
            }
            else
            {
                return HttpContext.Current.Cache["keywords"] as List<string>;
            }
        }
        #endregion

        #region FetchDocs
        [Route("api/FetchDocs/")]
        public IList<ILocation> FetchDocs(List<string> lstKeyWords)
        {
            IList<ILocation> lstDocs = new List<ILocation>();
            if (null != lstKeyWords)
            {                 
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                lstDocs = objContentDal.FetchDocs(lstKeyWords);
            }
            return lstDocs;
        }
        #endregion

        #region AddNewLink
        [Route("api/AddNewLink/")]
        public void AddNewLink(Location objLoc)
        {
            if (null != objLoc)
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                objContentDal.AddNewLink(objLoc);
                HttpContext.Current.Cache.Remove("keywords");
            }
        }
        #endregion

        #region AddNewSite
        [Route("api/AddNewSite/")]
        public void AddNewSite(Location objLoc)
        {
            if (null != objLoc)
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                objContentDal.AddNewSite(objLoc);
                HttpContext.Current.Cache.Remove("ksites");
            }
        }
        #endregion

        #region DeleteSite
        [Route("api/DeleteSite/{LocId}")]
        public void DeleteSite(int locId)
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            objContentDal.DeleteSite(locId);
            HttpContext.Current.Cache.Remove("ksites");
        }
        #endregion

        #region DeleteKnowledge
        [Route("api/DeleteKnowledge/{LocId}")]
        public void DeleteKnowledge(int locId)
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            objContentDal.DeleteKnowledge(locId);
            HttpContext.Current.Cache.Remove("keywords");
        }
        #endregion

        #region UpdateSite
        [Route("api/UpdateSite/")]
        public void UpdateSite(Location objLoc)
        {
            if(null!=objLoc)
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                objContentDal.UpdateSite(objLoc);
                HttpContext.Current.Cache.Remove("ksites");
            }
        }
        #endregion

        #region "Get Document wise rating"
        // GET api/<controller>
        [Route("api/PostRatingForDocument/{docId}/{rate}/{ratedBy}")]
        public string PostRatingForDocument(int docId, int rate, string ratedBy)
        {
            IList<IRateKnowledge> ratedDocs = new List<IRateKnowledge>();
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            int valu = objServiceCaller.PostRatingForDocument(docId, rate, ratedBy);
            return null;
        }
        #endregion

        #region GetScoreCard
        [Route("api/GetScoreCard/")]
        public DataTable GetScoreCard()
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objContentDal.GetScoreCard();
        }
        #endregion

        #region UpdateKnowledge
        [Route("api/UpdateKnowledge/")]
        public void UpdateKnowledge(Location objLoc)
        {
            if (null != objLoc)
            {
                var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                objContentDal.UpdateKnowledge(objLoc);
                HttpContext.Current.Cache.Remove("keywords");
            }
        }
        #endregion

        #region GetUseIdStatus
        [Route("api/GetUserIdStatus/{userId}")]
        public bool GetUseIdStatus(string userId)
        {
            return Helpers.GetUserIdStatus(userId);
        }
        #endregion

        #region
        // PUT api/<controller>
        [Route("api/PostUpdateUserDetais/{userId}/{userStatus}/{createdBy}")]
        public int PostUpdateUserDetais(string userId, int userStatus, string createdBy)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objServiceCaller.PostUpdateUserDetais(userId, userStatus, createdBy);
        }
        #endregion

        #region GetUserRole
        [Route("api/GetUserRole/")]
        public DataTable GetUserRole()
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objContentDal.GetUserRole();
        }
        #endregion

        #region GetUsesrRoleDetails
        [Route("api/GetUsersRoleDetails/{userId}")]
        public DataTable GetUsesrRoleDetails(string userId)
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objContentDal.GetUsesrRoleDetails(userId);
        }
        #endregion

        #region GetAdminList
        [Route("api/GetAdminListPortal/")]
        public DataTable GetAdminListPortal()
        {
            var objContentDal = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            return objContentDal.GetAdminList();
        }
        #endregion
    }
}