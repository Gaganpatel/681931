﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.UI;
using System.Xml;
using System.Xml.Linq;
using CS.PHART.BusinessLogic;
using ePortal.Common;
using ePortal.Common;
using ePortal.EntityModel;
using ePortal.Interfaces.Dal;
using ePortal.Interfaces.DomainModel;
using ePortal.Interfaces.EntityModel;
using ePortal.Interfaces.Mapper;
using ePortal.Web.SNOWAPI;
using ePortal.Web.SNOW_Client;
using ePortal.Web.SNOW_INC;
using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;
//using PeopleSearch;
using System.Net.Http.Headers;

namespace ePortal.Web.WebAPIControllers
{
    public class HomeController : ApiController
    {
        #region "UserType(External/Intrnal)"

        [Route("api/GetIsExternal")]
        public bool GetIsExternal()
        {
            var oList = SearchResults();
            var productId = oList[0].Department;
            var arrayProdId = productId.Split(' ');
            var department = arrayProdId[0];
            var firstCharDept = arrayProdId[1].Substring(0, 1);
           // productId = productId.Substring(0, productId.IndexOf(' '));
            if (department.ToUpper().Trim() == "KGPF" && firstCharDept.Trim() == "1")
            {
                return false;
            }
            return true;
        }

        [Route("api/GetIsAdmin")]
        public bool GetIsAdmin()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();

            DataTable adminData = objServiceCaller.GetUsesrRoleDetails(Helpers.GetLoggedUserDetail);
            try
            {
                if (adminData.Rows.Count > 0)
                {
                    return true;
                }
                return false ;
            }
            catch (Exception ex )
            {
                return false;
            }
            
        }

        public List<AdUser> SearchResults()
        {
            AdSearch initialSearch = new AdSearch(System.Configuration.ConfigurationManager.AppSettings["ADSearchRoot"]);
            //get the current user PID from onePKi
            var userPid = Convert.ToString(HttpContext.Current.Request.ServerVariables["HTTP_X_CSPKI_PID"]);
            if (userPid != null)
            {
                var objList = initialSearch.SearchUsers(userPid, "cn");
                return objList;
            }
            else
            {   // in local onePki doesnt wrk so hardcoding PID - Gagan
                var objList = initialSearch.SearchUsers("G977327", "cn");
                return objList;
            }

        }
        #endregion "UserType(External/Intrnal)"

        #region "Get Menu Details"
        // GET api/<controller>
        [Route("api/GetMenuDetails/{menuType}/{menuID}")]
        public IEnumerable<IPageContentModel> GetMenuDetails(string menuType,int menuId)
        {
            //login id
            var loginId = Helpers.GetLoggedUserDetail;

            AdSearch initialSearch = new AdSearch(System.Configuration.ConfigurationManager.AppSettings["ADSearchRoot"]);
            //get the current user id
            var userPid = Convert.ToString(HttpContext.Current.Request.ServerVariables["HTTP_X_CSPKI_PID"]);
            if (userPid != null)
            {
                var objList = initialSearch.SearchUsers(userPid, "cn");
               
                ////get the object of respective data mapper
                var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
                var objData = Factory.ObjectFactory.GetInstance<IPortalStart>();

                objData.MenuType = menuType;
                objData.MenuId = menuId;
                objData.UserId = loginId;
                objData.FirstName = objList[0].FirstName;
                objData.LastName = objList[0].LastName;
                objData.EmailId = objList[0].EMail;
                objData.OeCode = objList[0].Department;

                //perform get operation and return data
                return objServiceCaller.List(objData);
            }
            else
            {
                // in local onePki doesnt wrk so hardcoding PID - Gagan
                var objList = initialSearch.SearchUsers("G977327", "cn");

                ////get the object of respective data mapper
                var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
                var objData = Factory.ObjectFactory.GetInstance<IPortalStart>();

                objData.MenuType = menuType;
                objData.MenuId = menuId;
                objData.UserId = loginId;
                objData.FirstName = objList[0].FirstName;
                objData.LastName = objList[0].LastName;
                objData.EmailId = objList[0].EMail;
                objData.OeCode = objList[0].Department;

                //perform get operation and return data
                return objServiceCaller.List(objData);
            }
        }
        #endregion

        #region "Get Employee Details"
        // GET api/<controller>
        [Route("api/GetEmpPidDetails/")]
        public List<string> GetEmpPidDetails()
        {
            AdSearch initialSearch = new AdSearch(System.Configuration.ConfigurationManager.AppSettings["ADSearchRoot"]);
            //get the current user id
            var userPid = Convert.ToString(HttpContext.Current.Request.ServerVariables["HTTP_X_CSPKI_PID"]);
            if (userPid != null)
            {
                var objList = initialSearch.SearchUsers(userPid, "cn");
                var empPid = objList[0].PID;
                var firstName = objList[0].FirstName;
                var lastName = objList[0].LastName;
                var emailId = objList[0].EMail;
                var empDetailList = new List<string>();

                empDetailList.Add(empPid);
                empDetailList.Add(firstName);
                empDetailList.Add(lastName);
                empDetailList.Add(emailId);
                return empDetailList;
            }
            else
            { 
                // in local onePki doesnt wrk so hardcoding PID - Gagan
               // var objList = initialSearch.SearchUsers("G977327", "cn");
                var empPid = "";
                var firstName = Helpers.GetLoggedUserDetail;
                var lastName = "";
                var emailId = "";
                var empDetailList = new List<string>();

                empDetailList.Add(empPid);
                empDetailList.Add(firstName);
                empDetailList.Add(lastName);
                empDetailList.Add(emailId);
                return empDetailList;
            }
        }
        #endregion

        #region "Get Project level Document List"
        // GET api/<controller>
        [Route("api/GetDocListByPrj/{prjId}")]
        public IEnumerable<IDocument> GetDocListByPrj(int prjId)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetDocListByPrj(prjId);
        }
        #endregion

        #region "Get Project level Link List"
        // GET api/<controller>
        [Route("api/GetLinkListByPrj/{prjId}")]
        public DataTable GetLinkListByPrj(int prjId)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetLinkListByPrj(prjId);
        }
        #endregion

        #region "Get Section List"
        // GET api/<controller>
        [Route("api/GetSectionList/")]
        public DataTable GetSectionList()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetSectionList();
        }
        #endregion

        #region "Get Project List"
        // GET api/<controller>
        [Route("api/GetProjectList/")]
        public DataTable GetProjectList()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetProjectList();
        }
        #endregion

        #region "GetNotes"

        // GET api/<controller>
        [Route("api/GetNotes/")]
        public string GetNotes()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetNotes();
        }

        #endregion

        #region "GetPreferences"

        // GET api/<controller>
        [Route("api/GetPreferences/")]
        public string GetPreferences()
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
            return objServiceCaller.GetPreferences(Helpers.GetLoggedUserDetail);

        }

        #endregion

        #region "Get App Setting Key Values"
        // GET api/<controller>
         [Route("api/GetWebAppKeyvalue/")]
         public List<string> GetWebAppKeyvalue()
         {
             var objKey= new List<string>();
             var eInv = ConfigurationManager.AppSettings["eInventory_Link"];
             var eAlloc = ConfigurationManager.AppSettings["eAllocation_Link"];
             var csPic = ConfigurationManager.AppSettings["CsPhotoUrl"];

             var jiraBaseUrl = ConfigurationManager.AppSettings["JIRABaseUrl"];
             var rfcBaseUrl = ConfigurationManager.AppSettings["RFCBaseUrl"];
             var incBaseUrl = ConfigurationManager.AppSettings["INCBaseUrl"];

             objKey.Add(eInv);
             objKey.Add(eAlloc);
             objKey.Add(csPic);
             objKey.Add(jiraBaseUrl);
             objKey.Add(rfcBaseUrl);
             objKey.Add(incBaseUrl);

             return objKey;
         }
        #endregion

        #region "Get RFC Details Key Values"
         [Route("api/GetTicketByGroup/")]
         public DataTable GetTicketByGroup()
         {
            var gc = new ServiceNow_GetRfcsByStatusAndGroupAndDate();
             gc.Url = "https://cssnowpta.service-now.com/GetRfcsByStatusAndGroupAndDate.do?SOAP";

             Uri proxyUri = new Uri("http://slo-proxy.eu.hedani.net:8080");
             WebProxy wProxy = new WebProxy(proxyUri);
             gc.Proxy = wProxy;

             var userCredential = new NetworkCredential();
             userCredential.UserName = "integration.wsuser";
             userCredential.Password = "integr2SNOW";

             // Get user group based on PID
             var objGetGroup = new getGroups();
             objGetGroup.client = "API_Etools";
             objGetGroup.userid = Convert.ToString(HttpContext.Current.Request.ServerVariables["HTTP_X_CSPKI_PID"]);
            // objGetGroup.userid = "G905601"; //g977327 // Raghu // Gagan

             var obj2 = new ServiceNow_GetImplementerGroupsForUser();
             obj2.Url = "https://cssnowpta.service-now.com/GetImplementerGroupsForUser.do?SOAP";

             proxyUri = new Uri("http://slo-proxy.eu.hedani.net:8080");
             wProxy = new WebProxy(proxyUri);
             obj2.Proxy = wProxy;

             userCredential = new NetworkCredential();
             userCredential.UserName = "integration.wsuser";
             userCredential.Password = "integr2SNOW";

             obj2.Credentials = userCredential;
            var xmlResultGroup = obj2.getGroups(objGetGroup);
             DataTable dtResult = new DataTable();

             if (xmlResultGroup.xmloutput != null)
             {
                 try { 
                 var docGroup = new XmlDocument();
                 docGroup.LoadXml(xmlResultGroup.xmloutput);
                 XElement xyz = XElement.Load(new XmlNodeReader(docGroup));
                 DataTable dtResultGroup = XElementToDataTable(xyz);

                     for (int iLoop = 0; iLoop < dtResultGroup.Rows.Count; iLoop++)
                     {
                         var groupId = (dtResultGroup.Rows[iLoop]["name"]).ToString();


                         gc.Credentials = userCredential;
                         var inputRfc = new getRfcs();
                         inputRfc.client = "API_Etools";
                         //inputRfc.groupid = "TRADE_FLOW_F2B_RM_GBL";
                         inputRfc.groupid = groupId;
                         inputRfc.state = "Waiting Implementation";

                         DateTime startDate = DateTime.Now.AddMonths(-2);
                         inputRfc.planned_start_date =
                             string.Format(Convert.ToString(startDate.Year) + '-' + startDate.Month + "-01 00:00:00",
                                 "yyyy-MM-dd 00:00:00");

                         DateTime endDate = DateTime.Now.AddMonths(1);
                         inputRfc.planned_end_date =
                             string.Format(Convert.ToString(endDate.Year) + '-' + endDate.Month + "-01 00:00:00",
                                 "yyyy-MM-dd 00:00:00");

                         getRfcsResponse gAll = gc.getRfcs(inputRfc);
                         if (gAll.xmloutput != null)
                         {
                             XmlDocument doc = new XmlDocument();
                             doc.LoadXml(gAll.xmloutput);
                             XElement x = XElement.Load(new XmlNodeReader(doc));
                             DataTable dt = XElementToDataTable(x);
                             try
                             {
                                 dtResult.Merge(dt);
                             }
                             catch (Exception)
                             {
                                 dtResult = dt.Copy();

                             }

                         }
                     }

                 }
                 catch (Exception)
                 {
                     return new DataTable();

                 }
             }
             return dtResult;
            
         }

        // Generic method for converting XML document into dataset
         public DataTable XElementToDataTable(XElement x)
         {
             DataTable dt = new DataTable();

             XElement setup = (from p in x.Descendants() select p).First();
             foreach (XElement xe in setup.Descendants())
                 if (!dt.Columns.Contains(xe.Name.ToString()))
                 {
                     dt.Columns.Add(new DataColumn(xe.Name.ToString(), typeof (string))); // add columns to your dt
                 }
               
             var all = from p in x.Descendants(setup.Name.ToString()) select p;
             foreach (XElement xe in all)
             {
                 DataRow dr = dt.NewRow();
                 foreach (XElement xe2 in xe.Descendants())
                     if (String.IsNullOrEmpty(dr[xe2.Name.ToString()].ToString()))
                     {
                         dr[xe2.Name.ToString()] = xe2.Value; //add in the values
                     }
                 dt.Rows.Add(dr);

             }
             return dt;
         }
         #endregion

        #region "Get Tag Cloud Details"
         // GET api/<controller>
         [Route("api/GetTagCloudDetails/")]
         public DataSet GetTagCloudDetails()
         {
             var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonMapper<IPageContentModel>>();
             return objServiceCaller.GetTagCloudDetails();
         }
         #endregion

        #region FileUpload Save
        [Route("api/PostSaveFileDetails")]
         public int PostSaveFileDetails(Document obj)
         {
             bool isfileSaved = false;
             var temp = WebConfigurationManager.AppSettings["serverUrl"];
             if (obj.FileName.Contains(temp))
             {
                 obj.FileName = obj.FileName.Replace(temp, "");
             }

             //get file save server location
             var fileSaveRootLocationTemp = HttpContext.Current.Server.MapPath("\\UploadTemp\\");

             //get file save server location
             var fileSaveRootLocation = HttpContext.Current.Server.MapPath("\\Upload\\");

             if (File.Exists(fileSaveRootLocationTemp + obj.FileName))
             {
                 //copy file with overwrite as yes
                 File.Copy(fileSaveRootLocationTemp + obj.FileName, fileSaveRootLocation + obj.FileName, true);

                 //delete file from temp
                 File.Delete(fileSaveRootLocationTemp + obj.FileName);
                 isfileSaved = true;
                 Logger.Log("bool value", isfileSaved.ToString());
             }

             Logger.Log("Information", "Deleted and copied");

             if (isfileSaved == true)
             {
                 Logger.Log("Information", "entered the loop");
                 ////get the object of respective data mapper
                 var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
                 var objData = Factory.ObjectFactory.GetInstance<IDocument>();

                 objData.SectionId = obj.SectionId;
                 Logger.Log("objData.SectionId", objData.SectionId.ToString());

                 objData.ProjectId = obj.ProjectId;
                 Logger.Log("objData.ProjectId", objData.ProjectId.ToString());

                 objData.FileDescription = obj.FileDescription;
                 Logger.Log("objData.FileDescription", objData.FileDescription);

                 objData.FileName = obj.FileName;
                 Logger.Log("objData.FileNAME", objData.FileName);
                 
                 ////perform get operation and return data
                 return objServiceCaller.SaveDocumentDetails(objData);
             }
            return 0;
            //Save to db

         }
        #endregion

        #region JIRAAuthorization

        [Route("api/GetJiraAuthorisation/{maxResults}")]
        public List<string> GetJiraAuthorisation(string maxResults)
        {
            
            var objItems = new List<string>();
            
            string loginId = Helpers.GetLoggedUserDetail;
            string url = ConfigurationManager.AppSettings["JiraURL"];
            url = url.Replace("currentUser()", loginId + "&").Replace("maxResults()", "" + maxResults + "&");
            objItems.Add(url);

            return objItems;
        }

        
        #endregion JIRAAuthorization

        #region JIRAAuthorizationReporter

        [Route("api/GetJiraAuthorisationReporter/{maxResults}")]
        public List<string> GetJiraAuthorisationReporter(string maxResults)
        {

            var objItems = new List<string>();

            string loginId = Helpers.GetLoggedUserDetail;
            string url = ConfigurationManager.AppSettings["JiraURLReporter"];
            url = url.Replace("currentUser()", loginId + "&").Replace("maxResults()", "" + maxResults + "&");
            objItems.Add(url);

            return objItems;
        }


        #endregion JIRAAuthorizationReporter

        #region INCDetails
        [Route("api/GetINCDetails/")]
        public getRecordsResponseGetRecordsResult[] GetINCDetails()
        {
            var obj2 = new SNOW_INC.ServiceNow_incident();// .getRecords();
            
            var userCredential = new NetworkCredential();
            userCredential.UserName = "integration.wsuser";
            userCredential.Password = "integr2SNOW";
            //obj2.Url = "https://cssnowpta.service-now.com/incident.do?sysparm_view=dspm&amp;SOAP";
            obj2.Url = "https://cssnowpta.service-now.com/incident.do?SOAP&sysparm_view=dspm";

            try
            {
                Uri proxyUri = new Uri("http://slo-proxy.eu.hedani.net:8080");
                WebProxy wProxy = new WebProxy(proxyUri);
                obj2.Proxy = wProxy;
                
                obj2.Credentials = userCredential;

                
                var inputIncRecord = new SNOW_INC.getRecords();
                //getRecordsResponseGetRecordsResult[] rec = obj2.getRecords(inputIncRecord);

                //inputIncRecord = new SNOW_INC.getRecords();
                inputIncRecord.sys_created_by =  Helpers.GetLoggedUserDetail;  //"integration.wsuser";
                inputIncRecord.__order_by_desc = "state";
                
                getRecordsResponseGetRecordsResult[] outputRecordsCreated = obj2.getRecords(inputIncRecord);
                

                inputIncRecord = new SNOW_INC.getRecords();
                inputIncRecord.assigned_to = Helpers.GetLoggedUserDetail;
                inputIncRecord.__order_by_desc = "state";
                //inputIncRecord.state = "1";
                getRecordsResponseGetRecordsResult[] outputRecordsAssigned = obj2.getRecords(inputIncRecord);


                int IncRecLength = outputRecordsCreated.Length + outputRecordsAssigned.Length;

                getRecordsResponseGetRecordsResult[] outputRecords = new getRecordsResponseGetRecordsResult[IncRecLength];

                outputRecordsCreated.CopyTo(outputRecords,0);
                outputRecordsAssigned.CopyTo(outputRecords, outputRecordsCreated.Length);

              

              //var  incSelDataQuery = (outputRecords.AsEnumerable().Select( outRec=>
              //     new IncDetails()
              //      {
              //          _01_INC__Number = outRec.number, _02_Short__Description = outRec.short_description
              //          ,_03_Requested__By = outRec.caller_idname , _04_Change__State=outRec.state
              //          ,_05_Priority = outRec.priority, _06_Approval= ""
              //          ,_07_Assigned__To=outRec.assigned_toname , _08_Assignment__Group=outRec.assignment_groupname
              //          ,_09_Start_Date = outRec.sys_created_on, _10_End_Date=outRec.sys_updated_on 
              //          ,_11_Requester__Group=outRec.u_owning_groupname 
              //      })).ToList();


                return outputRecords;
               // return rec;

               

            }
            catch(Exception ex)
            {
                return null;
            }
          
        }

        #endregion INCDetails

        #region "Get Health Check summary"

        [Route("api/GetHealthCheckSummary")]
        public DataTable GetHealthCheckSummary()
        {
            DataTable  initSummaries = new DataTable();
            
            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonDal<IPortalStart>>();

            initSummaries=objServiceCaller.GetHealthCheckSummary();
            
            return initSummaries;

        }
        #endregion "Get Health Check summary"

        #region "Save Health Check Summary"
        [Route("api/PostHealthCheckSummary")]
        public DataTable PostHealthCheckSummary(HealthCheckSummary inputSummary)
        {
            var objServiceCaller = Factory.ObjectFactory.GetInstance<IContentDal<IContent>>();
            var objData = Factory.ObjectFactory.GetInstance<IHealthCheckSummary>();

            objData.HealthCheckId = inputSummary.HealthCheckId ;

            objData.HealthUserId  = Helpers.GetLoggedUserDetail ;

            objData.HealthCheckDetails  = inputSummary.HealthCheckDetails;



            if (objServiceCaller.SaveHealthCheckSummary(objData))
                return GetHealthCheckSummary();
            else
                return null;

        }
        #endregion "Save Health Check Summary"
    }
}