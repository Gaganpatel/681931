﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using ePortal.Common;
using ePortal.EntityModel;
using ePortal.Interfaces.Dal;
using ePortal.Interfaces.EntityModel;


namespace ePortal.Web.WebAPIControllers
{
    public class SubscriptionApiController : ApiController
    {
        #region Search_subscription


        [Route("api/GetSubscriptions")]
        public List<object> GetSubscriptions()
        {


            string userId = Helpers.GetLoggedUserDetail;

            List<object> initObjects = new List<object>();

            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonDal<IPortalStart>>();

            var objComm = objServiceCaller.GetUntCommunicationTypes();
            if(objComm!=null)
                objComm.RemoveAt(0);

            initObjects.Add(objComm);

            var objServiceCallerSub = Factory.ObjectFactory.GetInstance<IUntSubscriptionDal<IUntSubscription, UntSubscription>>();

            initObjects.Add(objServiceCallerSub.GetUntSubscriptions(userId));

            return initObjects;
        }
        #endregion Search_subscription

        #region "Post UNT Incident"
        [Route("api/PostSubscription/{isDelete}")]
        public UntSubscription PostSubscription(UntSubscription subscriptionReq, Boolean isDelete)
        {

            var objServiceCaller = Factory.ObjectFactory.GetInstance<IUntSubscriptionDal<IUntSubscription, UntSubscription>>();
            var objData = Factory.ObjectFactory.GetInstance<IUntSubscription>();

            objData.SubscriptionId = subscriptionReq.SubscriptionId;

            objData.CommunicationTypeId = subscriptionReq.CommunicationTypeId;

            objData.CommunicationTypeDesc = subscriptionReq.CommunicationTypeDesc;
            objData.CommunicationTypeSrc = subscriptionReq.CommunicationTypeSrc;
            string userId = Helpers.GetLoggedUserDetail;

            objData.SubUserId = userId;


            objData.CommunicationTypeDesc = objData.CommunicationTypeDesc.Replace(" ", "\n");  

            return objServiceCaller.SaveUntSubscription(objData, isDelete);
            //return null;
        }
        #endregion "Post UNT Incident"

    }
}
