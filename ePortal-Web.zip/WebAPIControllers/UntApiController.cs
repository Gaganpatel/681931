﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Configuration;
using System.Web.Http;
using ePortal.Common;
//using ePortal.Common.Email;
using ePortal.Common.Email;
using ePortal.EntityModel;
using ePortal.Interfaces.Dal;
using ePortal.Interfaces.EntityModel;
using Microsoft.Lync.Model;
using Microsoft.Lync.Model.Conversation;

namespace ePortal.Web.WebAPIControllers
{
    public class UntApiController : ApiController
    {
        /// <summary>
        /// Lync Messaging
        /// </summary>
        /// Begin
        private string _uri;
        private string _message;
        private LyncClient _client;
        private Conversation _conversation;

        /// End

        private bool _done = false;
        public bool Done
        {
            get { return _done; }
        }


        #region "Initialise UNT Incident"
        [Route("api/GetUntIncident")]
        public UntIncident GetUntIncident()
        {


            return (new UntIncident());
        }
        #endregion "Initialise UNT Incident"

        #region "Init UNT Incident"
        [Route("api/GetUntIncident1")]
        public List<object> GetUntIncident1()
        {

            List<object> initObjects = new List<object>();

            initObjects.Add(new UntIncident());

            var objServiceCaller = Factory.ObjectFactory.GetInstance<ICommonDal<IPortalStart>>();

            string userId = Helpers.GetLoggedUserDetail;

            initObjects.Add(objServiceCaller.GetUntCommunicationTypes());
            //initObjects.Add(objServiceCaller.GetUntImpacts());
            

            return (initObjects);
        }


        #endregion "Init UNT Incident"

        #region "Post UNT Incident"
        [Route("api/PostUntIncident")]
        public UntIncident PostUntIncident(UntIncident untIncidentReq)
        {

            var objServiceCaller = Factory.ObjectFactory.GetInstance<IUntIncidentDal<IUntIncident, UntIncident>>();
            var objData = Factory.ObjectFactory.GetInstance<IUntIncident>();

            objData.IncidentId = untIncidentReq.IncidentId;
            
            objData.IncidentDescription = untIncidentReq.IncidentDescription;

            objData.CommunicationTypeId = untIncidentReq.CommunicationTypeId;
            objData.CommunicationTypeDesc = untIncidentReq.CommunicationTypeDesc;

            objData.Status = untIncidentReq.Status;

            objData.ImpactedAreas = untIncidentReq.ImpactedAreas ;
            objData.BusinessArea = untIncidentReq.BusinessArea;
            objData.ActionsTaken = untIncidentReq.ActionsTaken;
            objData.ResolutionETA = untIncidentReq.ResolutionETA;
            objData.NextDate = untIncidentReq.NextDate;
            objData.Comments = untIncidentReq.Comments;
            objData.IncidentManager = untIncidentReq.IncidentManager;
            objData.PTGSupportContacts = untIncidentReq.PTGSupportContacts;
            objData.Recipients = untIncidentReq.Recipients;
            objData.SendEmail = untIncidentReq.SendEmail;
            objData.SendUnt = untIncidentReq.SendUnt;

            objData.CreationDate = untIncidentReq.CreationDate;
            objData.ExpiryDate = untIncidentReq.ExpiryDate;
            objData.UpdateDate = untIncidentReq.UpdateDate;

            objData.IncidentLink = untIncidentReq.IncidentLink;
            
            objData.saveMode = untIncidentReq.saveMode;
            UntIncident incidentResponse = null;
            try
            {
                incidentResponse = objServiceCaller.SaveUntIncident(objData);
            }
            catch(Exception ex)
            { }
            if (objData.SendEmail)
                sendUntEmailToRecipients(incidentResponse);
            return incidentResponse;
            //return null;
        }

        private Boolean sendUntEmailToRecipients(UntIncident incidentResponse)
        {
            try
            {
                string smtpServer = WebConfigurationManager.AppSettings["smtpServer"];
                string frEmail = WebConfigurationManager.AppSettings["FromEmail"];
                StringBuilder emailBody=new StringBuilder();
                emailBody.Append("<html><body><div>");
                
                emailBody.Append("Hi All,<br/><br/>");
                emailBody.Append("<table style='font-color:blue;border: 1px solid #ccc;'><tr><th colspan='4' style='background-color: #5c9ccc; color: white; text-align: center '>" + incidentResponse.CommunicationTypeDesc + " Details</th></tr>");
                
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Incident Description:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.IncidentDescription + "</td></tr>");


                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Status:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.Status + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Impacted Area(s):</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.ImpactedAreas + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Business Area:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.BusinessArea + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Actions Taken:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.ActionsTaken + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>ETA for Resolution:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.ResolutionETA + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Next Updates:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.NextDate + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Comments:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.Comments + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>Incident Manager:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.IncidentManager + "</td></tr>");
                emailBody.Append("<tr><td style='border: 1px solid #000 !important;padding: 10px;background-color: #e8e8e8;'><b>PTG Support Contacts:</b></td>");
                emailBody.Append("<td style ='border: 1px solid #000 !important;  padding: 10px;'>" + incidentResponse.PTGSupportContacts + "</td></tr>");

                emailBody.Append("</table>");
                
                emailBody.Append(
                    "<br/><br/>For any questions or concerns, please drop a message to our team DL: DD IT IB TT TM Environments<br/><br/>");
                emailBody.Append("Regards,<br/>DD IT IB TT TM Environments");
                emailBody.Append("</div></body></html>");

                Boolean sendEmailSuccess = Email.SendEmail(smtpServer, frEmail, incidentResponse.Recipients, "", incidentResponse.CommunicationTypeDesc + " - " + incidentResponse.BusinessArea, emailBody.ToString(), ',', true);

                // Send Lync Notification 
                // Begin          

                string[] recipients = incidentResponse.Recipients.Split(',');

                foreach (string eachRecip in recipients)
                {
                    _uri = eachRecip;
                    _message = "Message from ePortal";
                    _client = Microsoft.Lync.Model.LyncClient.GetClient();
                    _client.ContactManager.BeginSearch(
                        _uri,
                        SearchProviders.GlobalAddressList,
                        SearchFields.EmailAddresses,
                        SearchOptions.ContactsOnly,
                        2,
                        BeginSearchCallback,
                        new object[] { _client.ContactManager, _uri }
                    );
                }

                //End

                return sendEmailSuccess;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        #region Send Lync Notification

        /// <summary>
        /// Send Lync Notification 
        /// </summary>
        /// <param name="r"></param>

        private void BeginSearchCallback(IAsyncResult r)
        {
            object[] asyncState = (object[])r.AsyncState;
            ContactManager cm = (ContactManager)asyncState[0];
            try
            {
                SearchResults results = cm.EndSearch(r);
                if (results.AllResults.Count == 0)
                {
                    // No results.
                }
                else if (results.AllResults.Count == 1)
                {
                    ContactSubscription srs = cm.CreateSubscription();
                    Contact contact = results.Contacts[0];
                    srs.AddContact(contact);
                    ContactInformationType[] contactInformationTypes = { ContactInformationType.Availability, ContactInformationType.ActivityId };
                    srs.Subscribe(ContactSubscriptionRefreshRate.High, contactInformationTypes);
                    _conversation = _client.ConversationManager.AddConversation();
                    _conversation.AddParticipant(contact);
                    Dictionary<InstantMessageContentType, String> messages = new Dictionary<InstantMessageContentType, String>();
                    messages.Add(InstantMessageContentType.PlainText, _message);
                    InstantMessageModality m = (InstantMessageModality)_conversation.Modalities[ModalityTypes.InstantMessage];
                    m.BeginSendMessage(messages, BeginSendMessageCallback, messages);
                }
                else
                {
                    // More than one result.
                }
            }
            catch (SearchException se)
            {
                // Search failed: " + se.Reason.ToString());
            }
            _client.ContactManager.EndSearch(r);
        }

        private void BeginSendMessageCallback(IAsyncResult r)
        {
            _conversation.End();
            _done = true;
        }

        # endregion
        #endregion "Post UNT Incident"

    }
}
